#!/usr/bin/env bash
set -euo pipefail
mkdir -p /root/sca
tar -xzf /root/sca-duo.tar.gz -C /root/sca
mkdir -p ~/.ssh && chmod 700 ~/.ssh
PUB='ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIJIwWMQNgRaIKf0KZlNa/pzhtHHfveLwUgx25idUlHEW mulatram88@outlook.com'
grep -qxF "$PUB" ~/.ssh/authorized_keys 2>/dev/null || echo "$PUB" >> ~/.ssh/authorized_keys
chmod 600 ~/.ssh/authorized_keys
echo "### host"; hostname; nproc; free -g | head -2; df -h /root | tail -1
echo "### gpu"; nvidia-smi -L 2>&1 | head -3
echo "### python/torch"; python -V; python -c 'import torch;print("torch",torch.__version__,"cuda",torch.cuda.is_available())'
echo "### tree"; find /root/sca -maxdepth 2 -not -path '*/__pycache__*' | sort | head -40
