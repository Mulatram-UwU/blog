#!/usr/bin/env bash
# Density frontier: fixed chunk_size, pinned code spread, distortion-only aux.
set -u
cd /root/sca
PY=/root/miniconda3/bin/python
export PYTHONPATH=/root/sca

pkill -f 'common.train' 2>/dev/null && echo "killed previous trainer" || echo "no trainer running"
sleep 3
mkdir -p result/logs
LOG=result/logs/frontier.log
: > "$LOG"

run_one () {
  local cs="$1"
  local tag="$2"
  echo "== frontier code_std=$cs (chunk 0.5) =="
  "$PY" -m common.train --model sca_duo \
    --output-dir "result/frontier_$tag" \
    --tensorboard-dir "result/tensorboard/frontier_$tag" \
    --q-latent-dim 64 --sca-latent-dim 4 --chunk-size 0.5 --code-std "$cs" \
    --aux-mode rate --aux-beta 0.0 --indexer-lr-scale 0.1 --detach-indexer \
    --tokenizer-path /root/sca/data/bpe/tokenizer.json \
    --train-tokens /root/sca/data/bpe/train.pt \
    --valid-tokens /root/sca/data/bpe/val.pt \
    --device cuda --block-size 256 --batch-size 32 --steps 7755 \
    --eval-every 50 --eval-tokens 262144 --save-every 50 --keep-checkpoints 6 \
    --emb-dim 512 --n-heads 8 --n-layer 6 --mla-latent-dim 64 --dropout 0.1 \
    --lr 3e-4 --warmup-steps 100 --weight-decay 0.1 --grad-clip 1.0 --seed 1337 --amp
}

{
  run_one 0.30 cs030
  run_one 0.50 cs050
  run_one 0.65 cs065
  echo "== frontier finished =="
} > "$LOG" 2>&1 &

echo "FRONTIER pid=$!"
sleep 45
echo "### log head"
head -n 16 "$LOG"
echo "### running"
pgrep -af 'common.train' | sed 's/--tokenizer.*//' | head -2
