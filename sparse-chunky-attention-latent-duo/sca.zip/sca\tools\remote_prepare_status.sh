#!/usr/bin/env bash
cd /root/sca
for i in $(seq 1 20); do
  if ! pgrep -f 'common.build_data' >/dev/null 2>&1; then echo "build finished"; break; fi
  sleep 20
done
echo "### log"; tail -n 12 result/logs/prepare_data.log
echo "### bpe dir"; ls -l /root/sca/data/bpe/ 2>/dev/null
PY="$(cat .python_path 2>/dev/null || echo /root/miniconda3/bin/python)"
if [ -f data/bpe/train.pt ]; then
  PYTHONPATH=/root/sca "$PY" -c "import torch;t=torch.load('data/bpe/train.pt',map_location='cpu');v=torch.load('data/bpe/val.pt',map_location='cpu');print('train tokens',len(t),t.dtype,'val tokens',len(v));print('steps/epoch at block256 batch32 =',len(t)//8192)"
fi
