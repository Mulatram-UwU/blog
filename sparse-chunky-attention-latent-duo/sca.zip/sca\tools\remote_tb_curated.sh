#!/usr/bin/env bash
# Serve only the runs that matter: the dense baseline plus the density frontier.
set -u
cd /root/sca

rm -rf result/tb_final
mkdir -p result/tb_final
ln -sfn "$PWD/result/tensorboard/baseline" result/tb_final/baseline
for d in result/tensorboard/dens_*; do
  if [ -d "$d" ]; then
    ln -sfn "$PWD/$d" "result/tb_final/$(basename "$d")"
  fi
done
echo "### curated logdir ###"
ls -l result/tb_final | tail -n +2

echo
echo "### restart on the curated logdir ###"
# Match the server only.  A bare 'tensorboard' pattern also matches every trainer,
# because their command line carries --tensorboard-dir result/tensorboard/<run>.
pkill -f 'tensorboard.main' 2>/dev/null && echo "killed old" || echo "no old process"
sleep 2
setsid nohup /root/miniconda3/bin/python -m tensorboard.main \
  --logdir result/tb_final --host 0.0.0.0 --port 6007 \
  > result/logs/tensorboard.log 2>&1 < /dev/null &
sleep 12
echo "### process"; pgrep -af 'tensorboard.main' | head -1 || echo "(failed)"
echo "### port 6007 ###"
curl -s -o /dev/null -w "status=%{http_code}\n" --max-time 8 http://127.0.0.1:6007/ || echo "curl failed"
echo "### sweep still running? ###"
pgrep -af 'common.train' | sed 's/--tokenizer.*//' | head -1 || echo "(no trainer)"
