#!/usr/bin/env bash
# Full-epoch density frontier: log-spaced code_std, separate trunk/indexer clips.
set -u
cd /root/sca
PY=/root/miniconda3/bin/python
export PYTHONPATH=/root/sca

run_one () {
  local cs="$1"
  local tag="$2"
  echo "== full epoch code_std=$cs =="
  "$PY" -m common.train --model sca_duo \
    --output-dir "result/epoch_$tag" \
    --tensorboard-dir "result/tensorboard/epoch_$tag" \
    --q-latent-dim 64 --sca-latent-dim 4 --chunk-size 0.5 --code-std "$cs" \
    --aux-mode rate --aux-beta 0.0 --indexer-lr-scale 0.1 --detach-indexer \
    --tokenizer-path /root/sca/data/bpe/tokenizer.json \
    --train-tokens /root/sca/data/bpe/train.pt \
    --valid-tokens /root/sca/data/bpe/val.pt \
    --device cuda --block-size 256 --batch-size 32 --steps 7755 \
    --eval-every 50 --eval-tokens 262144 --save-every 50 --keep-checkpoints 2 \
    --emb-dim 512 --n-heads 8 --n-layer 6 --mla-latent-dim 64 --dropout 0.1 \
    --lr 3e-4 --warmup-steps 100 --weight-decay 0.1 --grad-clip 1.0 --seed 1337 --amp
}

run_one 0.15 e015
run_one 0.25 e025
run_one 0.40 e040
run_one 0.55 e055
run_one 0.75 e075
run_one 1.00 e100
run_one 1.40 e140
run_one 2.00 e200
run_one 3.00 e300
run_one 4.50 e450
echo "== full frontier finished =="
