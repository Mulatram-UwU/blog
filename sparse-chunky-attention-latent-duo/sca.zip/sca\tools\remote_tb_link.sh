#!/usr/bin/env bash
# Make AutoDL's own TensorBoard (port 6007, logdir /root/tf-logs) serve our runs,
# and keep that board readable by archiving superseded runs out of the logdir.
# Sub-directory symlinks are deliberately avoided: the platform board uses the
# fast data loader, which does not follow them.
set -u
cd /root/sca

if [ -d /root/tf-logs ] && [ ! -L /root/tf-logs ]; then
  mv /root/tf-logs "/root/tf-logs.orig.$(date +%s)"
fi
ln -sfn /root/sca/result/tensorboard /root/tf-logs

mkdir -p result/tensorboard_archive
moved=0
for d in result/tensorboard/*/; do
  name=$(basename "$d")
  case "$name" in
    baseline|dens_*) ;;
    *) mv "$d" result/tensorboard_archive/ && { echo "archived $name"; moved=$((moved+1)); } ;;
  esac
done
echo "archived $moved run(s)"
echo
echo "### kept ###"
ls -1 result/tensorboard

sleep 25
echo
echo "### the board now sees ###"
curl -s --max-time 12 http://127.0.0.1:6007/data/runs; echo
echo "http=$(curl -s -o /dev/null -w '%{http_code}' --max-time 8 http://127.0.0.1:6007/)"
echo
echo "### trainer ###"
pgrep -af 'common.train' | sed 's/--tokenizer.*//' | head -1 || echo "(NO TRAINER)"
pgrep -af 'remote_frontier_watchdog' | head -1 || echo "(NO WATCHDOG)"
