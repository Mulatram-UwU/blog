#!/usr/bin/env bash
cd /root/sca
echo "### running"; pgrep -af 'common.train' | sed 's/--data-path.*//' | head -2
echo "### per-run first/last row"
for d in result/baseline result/sca_duo_chunk0p5 result/sca_duo_chunk1 result/sca_duo_chunk2 result/sca_duo_chunk4; do
  if [ -f "$d/metrics.csv" ]; then
    echo "--- $d rows=$(grep -c . "$d/metrics.csv")"
    sed -n '2p' "$d/metrics.csv"
    tail -1 "$d/metrics.csv"
  fi
done
echo "### log tail"; tail -n 5 result/logs/train_all.log
echo "### disk"; df -h /root | tail -1; du -sh result 2>/dev/null
