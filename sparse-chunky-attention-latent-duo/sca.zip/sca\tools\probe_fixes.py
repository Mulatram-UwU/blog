#!/usr/bin/env python3
"""Compare indexer training variants against the finished baseline at matched steps.

The baseline is never re-run: its val_loss is read out of result/baseline/metrics.csv
at the same step numbers, and the evaluation protocol here is identical
(32 x 256 tokens of the validation split, autocast fp16, no grad).

    PYTHONPATH=. python tools/probe_fixes.py --steps 600
"""

from __future__ import annotations

import argparse
import csv

import torch

from common.data import get_batch, iter_batches, load_token_tensor
from sca_duo.model import SCADuoModel

BLOCK, BATCH, EVAL_TOKENS = 256, 32, 262144

SETTINGS = [
    ("slow", False, 0.1),
    ("detach+slow", True, 0.1),
]


def build(chunk_size, detach, device):
    return SCADuoModel(vocab_size=8192, block_size=BLOCK, emb_dim=512, n_heads=8, n_layer=6,
                       dropout=0.1, q_latent_dim=64, kv_latent_dim=64, latent_dim=4,
                       chunk_size=chunk_size, detach_indexer=detach).to(device)


def make_optimizer(model, lr, weight_decay, scale):
    named = [(n, p) for n, p in model.named_parameters() if ".indexer." in n]
    ids = {id(p) for _, p in named}
    groups = [{"params": [p for p in model.parameters() if id(p) not in ids], "lr": lr, "lr_scale": 1.0}]
    if ids and scale != 1.0:
        groups.insert(0, {"params": [p for _, p in named], "lr": lr * scale, "lr_scale": scale})
    return torch.optim.AdamW(groups, lr=lr, weight_decay=weight_decay)


@torch.no_grad()
def evaluate(model, valid, device):
    model.eval()
    total = {"loss": 0.0, "density": 0.0, "cand": 0.0, "recall": 0.0}
    seen = 0
    for tokens, targets in iter_batches(valid[:EVAL_TOKENS], BLOCK, BATCH, device):
        with torch.autocast(device_type="cuda", dtype=torch.float16, enabled=True):
            _, loss, metrics = model(tokens, targets)
        n = targets.numel()
        seen += n
        total["loss"] += float(loss.detach().float()) * n
        total["density"] += float(metrics["candidate_density"]) * n
        total["cand"] += float(metrics["avg_candidates"]) * n
        total["recall"] += float(metrics["routing_recall"]) * n
    model.train()
    return {k: v / seen for k, v in total.items()}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--steps", type=int, default=600)
    parser.add_argument("--every", type=int, default=100)
    parser.add_argument("--chunk-size", type=float, default=0.5)
    parser.add_argument("--train-tokens", default="data/bpe/train.pt")
    parser.add_argument("--valid-tokens", default="data/bpe/val.pt")
    parser.add_argument("--baseline-metrics", default="result/baseline/metrics.csv")
    args = parser.parse_args()

    device = torch.device("cuda")
    train = load_token_tensor(args.train_tokens).to(device)
    valid = load_token_tensor(args.valid_tokens).to(device)
    baseline = {}
    with open(args.baseline_metrics) as handle:
        for row in csv.DictReader(handle):
            if row.get("val_loss"):
                baseline[int(row["step"])] = float(row["val_loss"])

    results = {}
    for name, detach, scale in SETTINGS:
        torch.manual_seed(1337)
        torch.cuda.manual_seed_all(1337)
        model = build(args.chunk_size, detach, device).train()
        optimizer = make_optimizer(model, 3e-4, 0.1, scale)
        scaler = torch.amp.GradScaler("cuda", enabled=True)
        generator = torch.Generator(device=device).manual_seed(1337)
        curve = {}
        for step in range(1, args.steps + 1):
            lr = 3e-4 * min(float(step) / 100.0, 1.0)
            for group in optimizer.param_groups:
                group["lr"] = lr * group.get("lr_scale", 1.0)
            tokens, targets = get_batch(train, BLOCK, BATCH, device, generator)
            optimizer.zero_grad(set_to_none=True)
            with torch.autocast(device_type="cuda", dtype=torch.float16, enabled=True):
                _, loss, metrics = model(tokens, targets)
                total = loss + metrics["aux_loss"]
            scaler.scale(total).backward()
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            scaler.step(optimizer)
            scaler.update()
            if step % args.every == 0:
                curve[step] = evaluate(model, valid, device)
                row = curve[step]
                print("%-12s step=%4d val_loss=%.4f baseline=%.4f gap=%+.4f "
                      "cand=%6.2f density=%.4f recall=%.4f" % (
                          name, step, row["loss"], baseline.get(step, float("nan")),
                          row["loss"] - baseline.get(step, float("nan")), row["cand"],
                          row["density"], row["recall"]), flush=True)
        results[name] = curve

    print()
    print("=== summary (gap to baseline at the same step) ===")
    header = "%-12s" % "setting" + "".join("%10d" % s for s in sorted(next(iter(results.values()))))
    print(header)
    for name, curve in results.items():
        print("%-12s" % name + "".join("%+10.4f" % (curve[s]["loss"] - baseline[s]) for s in sorted(curve)))


if __name__ == "__main__":
    main()
