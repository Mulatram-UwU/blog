#!/usr/bin/env bash
set -u
cd /root/sca
PY="$(cat .python_path 2>/dev/null || echo /root/miniconda3/bin/python)"

echo "### tensorboard package"
if "$PY" -c 'import tensorboard' >/dev/null 2>&1; then
  "$PY" -c 'import tensorboard;print("tensorboard", tensorboard.__version__)'
else
  echo "installing tensorboard ..."
  if [ -f /etc/network_turbo ]; then source /etc/network_turbo || true; fi
  "$PY" -m pip install -q tensorboard 2>&1 | tail -3
  "$PY" -c 'import tensorboard;print("tensorboard", tensorboard.__version__)'
fi

echo "### stop previous jobs"
pkill -f 'common.train' 2>/dev/null && echo "killed trainers" || echo "no trainer running"
pkill -f 'tensorboard' 2>/dev/null && echo "killed tensorboard" || echo "no tensorboard running"
sleep 3

mkdir -p result/logs result/tensorboard
echo "### relaunch sweep with tensorboard logging"
LOG="result/logs/train_all.log"
: > "$LOG"
nohup env PYTHON_BIN="$PY" DEVICE=cuda AMP=1 STEPS=3000 EVAL_EVERY=50 SAVE_EVERY=50 \
  KEEP_CHECKPOINTS=6 CHUNK_SIZES="0.5 1 2 4" bash scripts/train_all.sh > "$LOG" 2>&1 &
echo "SWEEP pid=$! log=/root/sca/$LOG"

sleep 25
echo "### sweep log head"
head -n 8 "$LOG"

echo "### start tensorboard on 6006"
TB_LOG="result/logs/tensorboard.log"
: > "$TB_LOG"
# AutoDL's TensorBoard proxy dials 127.0.0.1:6007, not 6006.
nohup "$PY" -m tensorboard.main --logdir /root/sca/result/tensorboard --port 6007 --host 0.0.0.0 > "$TB_LOG" 2>&1 &
echo "TENSORBOARD pid=$!"
sleep 12
tail -n 6 "$TB_LOG"
echo "### port check"
( (ss -ltn 2>/dev/null || netstat -ltn 2>/dev/null) | grep 6006 ) || echo "6006 not listening yet"
