#!/usr/bin/env bash
cd /root/sca
PY="$(cat .python_path 2>/dev/null || echo /root/miniconda3/bin/python)"
echo "### sampling GPU utilisation for ~45s while the sweep runs"
: > result/logs/gpu_util.txt
for i in $(seq 1 130); do
  nvidia-smi --query-gpu=utilization.gpu,power.draw --format=csv,noheader,nounits >> result/logs/gpu_util.txt
  sleep 0.3
done
awk -F, '{gsub(/ /,"",$1); print $1}' result/logs/gpu_util.txt | sort -n > result/logs/gpu_util_sorted.txt
n=$(wc -l < result/logs/gpu_util_sorted.txt)
echo "samples=$n min=$(sed -n 1p result/logs/gpu_util_sorted.txt) p25=$(sed -n $((n/4+1))p result/logs/gpu_util_sorted.txt) median=$(sed -n $((n/2))p result/logs/gpu_util_sorted.txt) p75=$(sed -n $((n*3/4))p result/logs/gpu_util_sorted.txt) max=$(tail -1 result/logs/gpu_util_sorted.txt)"
low=$(awk '$1 < 20' result/logs/gpu_util_sorted.txt | wc -l)
echo "samples below 20%: $low / $n"
echo "### first 30 raw samples"; head -30 result/logs/gpu_util.txt | tr '\n' ' '; echo
echo "### checkpoint write cost"
PYTHONPATH=/root/sca "$PY" tools/bench_save.py
echo "### live run progress"; tail -n 3 result/logs/train_all.log
