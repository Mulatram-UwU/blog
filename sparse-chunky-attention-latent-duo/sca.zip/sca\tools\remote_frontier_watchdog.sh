#!/usr/bin/env bash
# Keeps the frontier alive across the proxy's connection blips.  Relaunches the
# sweep whenever neither the runner nor the trainer is alive and the run is not
# finished; the sweep itself skips the configurations that already completed.
set -u
cd /root/sca
LOG=result/logs/density_frontier.log
while true; do
  if grep -q 'density frontier finished' "$LOG" 2>/dev/null; then
    echo "$(date '+%H:%M:%S') frontier complete, watchdog exiting"
    break
  fi
  if ! pgrep -f 'common.train' >/dev/null 2>&1 && ! pgrep -f 'remote_density_frontier' >/dev/null 2>&1; then
    echo "$(date '+%H:%M:%S') sweep not running, relaunching" >> "$LOG"
    setsid nohup bash tools/remote_density_frontier.sh >> "$LOG" 2>&1 < /dev/null &
  fi
  sleep 60
done
