"""Time one training step and one evaluation pass so the sweep can be sized sanely."""

from __future__ import annotations

import argparse
import time

import torch

from baseline.model import BaselineModel
from common.data import get_batch, iter_batches, load_token_tensor
from sca_duo.model import SCADuoModel


def time_steps(model, data, block, batch, device, iterations):
    optimizer = torch.optim.AdamW(model.parameters(), lr=1e-4)
    scaler = torch.amp.GradScaler("cuda", enabled=True)
    generator = torch.Generator(device=device).manual_seed(0)
    for _ in range(2):
        tokens, targets = get_batch(data, block, batch, device, generator)
        optimizer.zero_grad(set_to_none=True)
        with torch.autocast("cuda", dtype=torch.float16):
            _, loss, _ = model(tokens, targets)
        scaler.scale(loss).backward()
        scaler.step(optimizer)
        scaler.update()
    torch.cuda.synchronize()
    started = time.time()
    for _ in range(iterations):
        tokens, targets = get_batch(data, block, batch, device, generator)
        optimizer.zero_grad(set_to_none=True)
        with torch.autocast("cuda", dtype=torch.float16):
            _, loss, _ = model(tokens, targets)
        scaler.scale(loss).backward()
        scaler.step(optimizer)
        scaler.update()
    torch.cuda.synchronize()
    seconds = (time.time() - started) / iterations
    print("  %-9s block=%d batch=%-4d %.3f s/step %8.0f tok/s" % (
        model.model_name, block, batch, seconds, block * batch / seconds), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--train-tokens", required=True)
    parser.add_argument("--valid-tokens", required=True)
    parser.add_argument("--vocab", type=int, default=8192)
    parser.add_argument("--block", type=int, default=256)
    parser.add_argument("--batches", type=int, nargs="+", default=[32, 64, 128])
    parser.add_argument("--iterations", type=int, default=6)
    args = parser.parse_args()

    device = torch.device("cuda")
    train = load_token_tensor(args.train_tokens).to(device)
    valid = load_token_tensor(args.valid_tokens).to(device)
    print("train tokens %d, valid tokens %d" % (len(train), len(valid)), flush=True)

    for batch in args.batches:
        model = BaselineModel(args.vocab, args.block, 512, 8, 6, 0.0, 64, 64).to(device)
        time_steps(model, train, args.block, batch, device, args.iterations)
        del model
    for batch in args.batches:
        model = SCADuoModel(args.vocab, args.block, 512, 8, 6, 0.0, 64, 64, 4, 1.0).to(device)
        time_steps(model, train, args.block, batch, device, args.iterations)
        del model

    model = BaselineModel(args.vocab, args.block, 512, 8, 6, 0.0, 64, 64).to(device)
    model.eval()
    started = time.time()
    batches = 0
    with torch.no_grad():
        for tokens, targets in iter_batches(valid, args.block, 32, device):
            with torch.autocast("cuda", dtype=torch.float16):
                model(tokens, targets)
            batches += 1
    torch.cuda.synchronize()
    print("  eval over %d tokens -> %d batches, %.2f s" % (len(valid), batches, time.time() - started), flush=True)


if __name__ == "__main__":
    main()
