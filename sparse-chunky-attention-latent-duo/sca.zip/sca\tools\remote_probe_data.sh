#!/usr/bin/env bash
cd /root/sca
PY="$(cat .python_path 2>/dev/null || echo /root/miniconda3/bin/python)"
echo "### stop the Tiny Shakespeare sweep"
pkill -f 'common.train' 2>/dev/null && echo "killed trainers" || echo "no trainer running"
sleep 2
pgrep -af 'common.train' | head -2 || echo "(confirmed none)"
echo "### tokenizer-related packages"
"$PY" -m pip list 2>/dev/null | grep -iE '^(tokenizers|transformers|tiktoken|datasets|sentencepiece|numpy|torch|tensorboard) '
echo "### huggingface reachability"
if [ -f /etc/network_turbo ]; then source /etc/network_turbo >/dev/null 2>&1 || true; echo "(network_turbo sourced)"; fi
timeout 30 curl -sIL -o /dev/null -w "valid.txt -> %{http_code}\n" https://huggingface.co/datasets/roneneldan/TinyStories/resolve/main/TinyStoriesV2-GPT4-valid.txt || echo "valid.txt unreachable"
timeout 30 curl -sIL https://huggingface.co/datasets/roneneldan/TinyStories/resolve/main/TinyStoriesV2-GPT4-train.txt 2>/dev/null | grep -iE '^HTTP/|content-length' | tail -4 || echo "train.txt unreachable"
echo "### disk"
df -h /root /root/autodl-tmp | tail -2
