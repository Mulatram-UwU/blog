#!/usr/bin/env python3
"""A/B the auxiliary objective: KL distillation vs budgeted recall.

Everything else is held at the current best configuration (indexer detached from
the trunk, indexer learning rate scaled to 0.1).  val_loss is compared against the
finished baseline at the same step numbers, read out of result/baseline/metrics.csv.

    PYTHONPATH=. python tools/probe_aux.py --steps 600
"""

from __future__ import annotations

import argparse
import csv

import torch

from common.train import build_model
from common.data import get_batch, iter_batches, load_token_tensor
from sca_duo.model import SCADuoModel

BLOCK, BATCH, EVAL_TOKENS = 256, 32, 262144

SETTINGS = [
    ("kl", "kl", 1.0, False),
    ("rate b=0.3", "rate", 0.3, False),
    ("rate b=1", "rate", 1.0, False),
    ("rate b=3", "rate", 3.0, False),
    ("rate b=10", "rate", 10.0, False),
]


def build(detach, aux_mode, aux_beta, ste_mask, device):
    return SCADuoModel(vocab_size=8192, block_size=BLOCK, emb_dim=512, n_heads=8, n_layer=6,
                       dropout=0.1, q_latent_dim=64, kv_latent_dim=64, latent_dim=4,
                       chunk_size=0.5, detach_indexer=detach, aux_mode=aux_mode,
                       aux_beta=aux_beta, ste_mask=ste_mask).to(device)


def make_optimizer(model, lr, weight_decay, scale):
    named = [(n, p) for n, p in model.named_parameters() if ".indexer." in n]
    ids = {id(p) for _, p in named}
    groups = [{"params": [p for p in model.parameters() if id(p) not in ids], "lr": lr, "lr_scale": 1.0}]
    if ids and scale != 1.0:
        groups.insert(0, {"params": [p for _, p in named], "lr": lr * scale, "lr_scale": scale})
    return torch.optim.AdamW(groups, lr=lr, weight_decay=weight_decay)


@torch.no_grad()
def evaluate(model, valid, device):
    model.eval()
    total = {"loss": 0.0, "density": 0.0, "cand": 0.0, "recall": 0.0, "aux": 0.0}
    seen = 0
    for tokens, targets in iter_batches(valid[:EVAL_TOKENS], BLOCK, BATCH, device):
        with torch.autocast(device_type="cuda", dtype=torch.float16, enabled=True):
            _, loss, metrics = model(tokens, targets)
        n = targets.numel()
        seen += n
        total["loss"] += float(loss.detach().float()) * n
        total["aux"] += float(metrics["aux_loss"].detach().float()) * n
        total["density"] += float(metrics["candidate_density"]) * n
        total["cand"] += float(metrics["avg_candidates"]) * n
        total["recall"] += float(metrics["routing_recall"]) * n
    model.train()
    return {k: v / seen for k, v in total.items()}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--steps", type=int, default=600)
    parser.add_argument("--every", type=int, default=150)
    parser.add_argument("--chunk-size", type=float, default=0.5)
    parser.add_argument("--indexer-lr-scale", type=float, default=0.1)
    parser.add_argument("--train-tokens", default="data/bpe/train.pt")
    parser.add_argument("--valid-tokens", default="data/bpe/val.pt")
    parser.add_argument("--baseline-metrics", default="result/baseline/metrics.csv")
    args = parser.parse_args()

    device = torch.device("cuda")
    train = load_token_tensor(args.train_tokens).to(device)
    valid = load_token_tensor(args.valid_tokens).to(device)
    baseline = {}
    with open(args.baseline_metrics) as handle:
        for row in csv.DictReader(handle):
            if row.get("val_loss"):
                baseline[int(row["step"])] = float(row["val_loss"])

    curves = {}
    for name, aux_mode, aux_beta, ste_mask in SETTINGS:
        torch.manual_seed(1337)
        torch.cuda.manual_seed_all(1337)
        model = build(True, aux_mode, aux_beta, ste_mask, device).train()
        optimizer = make_optimizer(model, 3e-4, 0.1, args.indexer_lr_scale)
        scaler = torch.amp.GradScaler("cuda", enabled=True)
        generator = torch.Generator(device=device).manual_seed(1337)
        curve = {}
        for step in range(1, args.steps + 1):
            lr = 3e-4 * min(float(step) / 100.0, 1.0)
            for group in optimizer.param_groups:
                group["lr"] = lr * group.get("lr_scale", 1.0)
            tokens, targets = get_batch(train, BLOCK, BATCH, device, generator)
            optimizer.zero_grad(set_to_none=True)
            with torch.autocast(device_type="cuda", dtype=torch.float16, enabled=True):
                _, loss, metrics = model(tokens, targets)
                total = loss + metrics["aux_loss"]
            scaler.scale(total).backward()
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            scaler.step(optimizer)
            scaler.update()
            if step % args.every == 0:
                row = evaluate(model, valid, device)
                curve[step] = row
                print("%-14s step=%4d val_loss=%.4f gap=%+.4f cand=%7.2f density=%.4f "
                      "recall=%.4f aux=%.4f" % (
                          name, step, row["loss"], row["loss"] - baseline[step], row["cand"],
                          row["density"], row["recall"], row["aux"]), flush=True)
        curves[name] = curve

    steps = sorted(next(iter(curves.values())))
    print()
    print("=== gap to baseline ===")
    print("%-14s" % "aux" + "".join("%10d" % s for s in steps))
    for name, curve in curves.items():
        print("%-14s" % name + "".join("%+10.4f" % (curve[s]["loss"] - baseline[s]) for s in steps))
    print()
    print("=== density ===")
    print("%-14s" % "aux" + "".join("%10d" % s for s in steps))
    for name, curve in curves.items():
        print("%-14s" % name + "".join("%10.4f" % curve[s]["density"] for s in steps))
    print()
    print("=== routing recall ===")
    print("%-14s" % "aux" + "".join("%10d" % s for s in steps))
    for name, curve in curves.items():
        print("%-14s" % name + "".join("%10.4f" % curve[s]["recall"] for s in steps))


if __name__ == "__main__":
    main()
