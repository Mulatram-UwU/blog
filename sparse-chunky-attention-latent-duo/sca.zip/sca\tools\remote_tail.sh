#!/usr/bin/env bash
cd /root/sca
sleep 60
echo "### processes"; pgrep -af common.train | head -3 || echo "(none - finished)"
echo "### log tail"; tail -n 12 result/logs/smoke.log
echo "### sca_duo csv (all rows)"
cat result/smoke/sca_duo/metrics.csv
echo "### baseline csv (eval rows)"
awk -F, 'NR==1 || $5 != ""' result/smoke/baseline/metrics.csv
