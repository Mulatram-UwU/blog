"""SCA-L latent indexer.

The indexer attaches to the compressed MLA latents rather than to the raw
embedding: the key side reads the tensor that is actually kept in the KV cache
(c_kv, produced by W_kv_down) and the query side reads the query latent (c_q).
Both are projected into a sca_latent_dim-dimensional space, the chunk
coordinate is floor(z / chunk_size), and a query visits every cell within
Chebyshev distance one, i.e. the full {-1, 0, +1} ** latent_dim neighbourhood
(3 ** latent_dim cells, including the query's own cell).

The indexer never scores anything: the attention logits still come from MLA.
Its projection is trained by a distillation term computed in the model.
"""

from __future__ import annotations

import math

import torch
from torch import Tensor, nn


class SparseChunkyIndexer(nn.Module):
    def __init__(self, q_latent_dim: int, kv_latent_dim: int, latent_dim: int = 4, chunk_size: float = 1.0,
                 code_std: float = 0.0):
        super().__init__()
        if q_latent_dim <= 0 or kv_latent_dim <= 0:
            raise ValueError("latent dimensions must be positive")
        if latent_dim <= 0:
            raise ValueError("latent_dim must be positive")
        if chunk_size <= 0:
            raise ValueError("chunk_size must be positive")
        self.latent_dim = latent_dim
        self.chunk_size = float(chunk_size)
        # When positive the code spread is pinned to this standard deviation, with
        # the scale detached so no loss can shrink it.  Sparsity cannot come from
        # the objective -- every term prefers a dense partition -- so it has to be
        # a constraint, and this is that constraint.
        self.code_std = float(code_std)
        self.min_code_scale = 0.02
        self.scale = 1.0 / math.sqrt(latent_dim)
        # Effective cell width = chunk_size * density_gain.  code_std only pins the
        # code's spread, and the spread is not what sets the candidate count: the
        # density is an attractor at 1 because every loss term prefers a dense
        # partition, so a fixed code_std merely buys time before the routing
        # collapses.  density_gain is driven by a feedback controller on the
        # measured density instead, and freezes to a constant at inference.
        self.register_buffer("density_gain", torch.ones(()))
        self.register_buffer("density_ema", torch.ones(()))
        self.q_index = nn.Linear(q_latent_dim, latent_dim, bias=False)
        self.k_index = nn.Linear(kv_latent_dim, latent_dim, bias=False)

    def neighbourhood_size(self) -> int:
        return 3 ** self.latent_dim

    def cell_count(self) -> int:
        """How many cells the bounded code space holds (the 'expert count').

        tanh confines every code coordinate to [-1, 1], so chunk_size splits it
        into a fixed number of cells.  Fixing that count is what makes the routing
        density well defined instead of an unbounded side effect of ||z||.
        """

        return max(1, int(round((2.0 / self.chunk_size) ** self.latent_dim)))

    def encode(self, c_q: Tensor, c_kv: Tensor):
        return self.q_index(c_q), self.k_index(c_kv)

    def cell_coordinates(self, z: Tensor) -> Tensor:
        """Continuous cell coordinate in a bounded box.

        tanh confines the code to [-1, 1] ** latent_dim before chunk_size turns it
        into a cell index, so the number of cells is fixed by cell_count().  An
        unbounded code let the KL term grow ||z|| until every token sat alone in
        its own cell and the neighbourhood collapsed to self-attention; a bounded
        box makes that impossible, and restores the magnitude as a usable lever.
        Stays continuous so the auxiliary losses can reach back through it;
        chunk_coordinates() applies the floor.
        """

        code = torch.tanh(z)
        if self.code_std > 0.0:
            # Floor the scale: without it a collapsing code makes code / std explode,
            # which overflows the half-precision backward and skips whole steps.  The
            # floor only engages once the code has already collapsed, where a denser
            # partition is the safe direction anyway.
            scale = code.detach().std().clamp_min(self.min_code_scale)
            code = code / scale * self.code_std
        return code / (self.chunk_size * self.density_gain)

    def chunk_coordinates(self, z: Tensor) -> Tensor:
        """The hard cell index that actually defines the partition."""

        return torch.floor(self.cell_coordinates(z))

    def soft_neighbourhood(self, z_q: Tensor, z_k: Tensor, tau: float = 0.5) -> Tensor:
        """[B, T, T] differentiable surrogate for the Chebyshev <= 1 indicator.

        Product form: every axis contributes sigmoid((1 - |du|) / tau), which is
        near one while all axes stay within one cell and decays once any axis
        leaves.  Used only to give the auxiliary loss a gradient path; the model
        itself still reads the hard mask.
        """

        u_q = self.cell_coordinates(z_q)
        u_k = self.cell_coordinates(z_k)
        soft = None
        for axis in range(self.latent_dim):
            delta = (u_q[..., axis].unsqueeze(2) - u_k[..., axis].unsqueeze(1)).abs()
            term = torch.sigmoid((1.0 - delta) / tau)
            soft = term if soft is None else soft * term
        return soft

    def candidate_mask(self, z_q: Tensor, z_k: Tensor, causal: Tensor) -> Tensor:
        """[B, T, T] boolean: key is in a neighbouring chunk cell and not in the future.

        Chebyshev distance <= 1 per axis is exactly the 3 ** latent_dim block of
        cells around the query cell.  The axes are folded one at a time so that
        the intermediate tensor stays [B, T, T] instead of [B, T, T, latent_dim].

        The diagonal is forced on.  z_q and z_k are produced by two different
        projections, so a token's own key does not in general fall in the same
        cell as its own query; without this the query can route away every
        causal key, and softmax over an all -inf row returns NaN.
        """

        q_cell = self.chunk_coordinates(z_q)
        k_cell = self.chunk_coordinates(z_k)
        within = None
        for axis in range(self.latent_dim):
            near = (q_cell[..., axis].unsqueeze(2) - k_cell[..., axis].unsqueeze(1)).abs() <= 1
            within = near if within is None else (within & near)
        # causal_mask is True for FUTURE positions, so keep the logical negation.
        allowed = within & causal.logical_not()
        diagonal = torch.eye(allowed.shape[-2], dtype=torch.bool, device=allowed.device)
        return allowed | diagonal

    def logits(self, z_q: Tensor, z_k: Tensor, causal: Tensor) -> Tensor:
        scores = (z_q @ z_k.transpose(-2, -1)) * self.scale
        return scores.masked_fill(causal, float("-inf"))
