#!/usr/bin/env python3
"""Does the density setpoint controller actually hold the density?

Pinning the code spread turned out to only set how fast the routing relaxes to
fully dense, so the constraint now sits on the measured density itself, driven by
slow integral control on the effective cell width.

    PYTHONPATH=. python tools/probe_density_ctrl.py
"""

from __future__ import annotations

import csv

import torch

from common.data import get_batch, iter_batches, load_token_tensor
from sca_duo.model import SCADuoModel

BLOCK, BATCH, CHUNK, CODE_STD = 256, 32, 0.5, 0.30
EVAL_TOKENS, STEPS, CTRL_RATE = 262144, 1200, 0.02
TARGETS = (0.10, 0.30, 0.60)


def build(target, device):
    return SCADuoModel(vocab_size=8192, block_size=BLOCK, emb_dim=512, n_heads=8, n_layer=6,
                       dropout=0.1, q_latent_dim=64, kv_latent_dim=64, latent_dim=4,
                       chunk_size=CHUNK, detach_indexer=True, aux_mode="rate", aux_beta=0.0,
                       code_std=CODE_STD, target_density=target,
                       density_ctrl_rate=CTRL_RATE).to(device)


def gains(model):
    return [float(b.attention.indexer.density_gain) for b in model.blocks]


def main():
    device = torch.device("cuda")
    train = load_token_tensor("data/bpe/train.pt").to(device)
    valid = load_token_tensor("data/bpe/val.pt").to(device)
    baseline = {}
    with open("result/baseline/metrics.csv") as handle:
        for row in csv.DictReader(handle):
            if row.get("val_loss"):
                baseline[int(row["step"])] = float(row["val_loss"])

    for target in TARGETS:
        torch.manual_seed(1337)
        torch.cuda.manual_seed_all(1337)
        model = build(target, device).train()
        named = [(n, p) for n, p in model.named_parameters() if ".indexer." in n]
        ids = {id(p) for _, p in named}
        optimizer = torch.optim.AdamW(
            [{"params": [p for p in model.parameters() if id(p) not in ids],
              "lr": 3e-4, "lr_scale": 1.0},
             {"params": [p for _, p in named], "lr": 3e-5, "lr_scale": 0.1}],
            lr=3e-4, weight_decay=0.1)
        scaler = torch.amp.GradScaler("cuda", enabled=True)
        generator = torch.Generator(device=device).manual_seed(1337)
        print("=== target density %.2f (ctrl rate %g, code_std %g) ===" % (
            target, CTRL_RATE, CODE_STD))
        print("%6s %10s %9s %9s %9s %9s %8s" % (
            "step", "train_loss", "val_loss", "gap", "density", "avg_cand", "gain"))
        for step in range(1, STEPS + 1):
            lr = 3e-4 * min(float(step) / 100.0, 1.0)
            for group in optimizer.param_groups:
                group["lr"] = lr * group.get("lr_scale", 1.0)
            tokens, targets = get_batch(train, BLOCK, BATCH, device, generator)
            optimizer.zero_grad(set_to_none=True)
            with torch.autocast(device_type="cuda", dtype=torch.float16, enabled=True):
                _, loss, metrics = model(tokens, targets)
                total = loss + metrics["aux_loss"]
            scaler.scale(total).backward()
            scaler.unscale_(optimizer)
            trunk = [p for p in model.parameters() if id(p) not in ids]
            torch.nn.utils.clip_grad_norm_(trunk, 1.0)
            torch.nn.utils.clip_grad_norm_([p for _, p in named], 1.0)
            scaler.step(optimizer)
            scaler.update()
            if step % 200 == 0:
                model.eval()
                tot, seen = 0.0, 0
                dens, cand = 0.0, 0.0
                with torch.no_grad():
                    for vt, vg in iter_batches(valid[:EVAL_TOKENS], BLOCK, BATCH, device):
                        _, vl, vm = model(vt, vg)
                        n = vg.numel()
                        tot += float(vl.detach().float()) * n
                        dens += float(vm["candidate_density"]) * n
                        cand += float(vm["avg_candidates"]) * n
                        seen += n
                model.train()
                g = gains(model)
                print("%6d %10.4f %9.4f %+9.4f %9.4f %9.2f %8.3f" % (
                    step, float(loss.detach().float()), tot / seen,
                    tot / seen - baseline.get(step, float("nan")), dens / seen, cand / seen,
                    sum(g) / len(g)))
        print()


if __name__ == "__main__":
    main()
