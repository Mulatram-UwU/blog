#!/usr/bin/env bash
# Waits for the chunk sweep to finish, then runs code_std=0.30 at chunk 0.5 for a
# full epoch.  It fills the density gap between the chunk 1.0 and chunk 0.5 points
# on the sparsity frontier.
set -u
cd /root/sca
PY=/root/miniconda3/bin/python
export PYTHONPATH=/root/sca

echo "waiting for the chunk sweep to finish..."
while pgrep -f 'remote_chunk_sweep.sh' >/dev/null 2>&1; do sleep 20; done
sleep 5
echo "chunk sweep done, starting cs030"

"$PY" -m common.train --model sca_duo \
  --output-dir result/final_cs030 \
  --tensorboard-dir result/tensorboard/final_cs030 \
  --q-latent-dim 64 --sca-latent-dim 4 --chunk-size 0.5 --code-std 0.30 \
  --aux-mode rate --aux-beta 0.0 --indexer-lr-scale 0.1 --detach-indexer \
  --tokenizer-path /root/sca/data/bpe/tokenizer.json \
  --train-tokens /root/sca/data/bpe/train.pt \
  --valid-tokens /root/sca/data/bpe/val.pt \
  --device cuda --block-size 256 --batch-size 32 --steps 7755 \
  --eval-every 50 --eval-tokens 262144 --save-every 50 --keep-checkpoints 6 \
  --emb-dim 512 --n-heads 8 --n-layer 6 --mla-latent-dim 64 --dropout 0.1 \
  --lr 3e-4 --warmup-steps 100 --weight-decay 0.1 --grad-clip 1.0 --seed 1337 --amp
echo "== cs030 finished =="
