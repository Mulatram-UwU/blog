#!/usr/bin/env bash
# Waits for screen C to finish, then runs screen D.
set -u
cd /root/sca
echo "waiting for screen C..."
while pgrep -f 'remote_screen_c.sh' >/dev/null 2>&1; do sleep 15; done
sleep 5
echo "screen C done, starting screen D"
LOG=result/logs/screen_d.log
: > "$LOG"
bash tools/remote_screen_d.sh > "$LOG" 2>&1
echo "== queue done =="
