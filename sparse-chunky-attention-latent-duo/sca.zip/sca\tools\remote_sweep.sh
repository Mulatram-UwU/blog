#!/usr/bin/env bash
set -u
cd /root/sca
PY="$(cat .python_path 2>/dev/null || echo /root/miniconda3/bin/python)"

echo "### stop anything already running (this was missing before)"
pkill -f 'common.train' 2>/dev/null && echo "killed existing trainers" || echo "no trainer running"
sleep 3
if pgrep -f 'common.train' >/dev/null 2>&1; then echo "WARNING: trainers still alive"; pgrep -af 'common.train' | head -3; else echo "confirmed: no trainer running"; fi

mkdir -p result/logs
echo "### clearing previous runs"
for d in result/baseline result/sca_duo_chunk0p5 result/sca_duo_chunk1 result/sca_duo_chunk2 result/sca_duo_chunk4 result/tensorboard result/smoke; do
  if [ -e "$d" ]; then rm -rf "$d"; echo "removed /root/sca/$d"; fi
done

LOG=result/logs/train_all.log
: > "$LOG"
nohup env PYTHON_BIN="$PY" DEVICE=cuda AMP=1 STEPS=7755 EVAL_EVERY=50 SAVE_EVERY=50 \
  KEEP_CHECKPOINTS=6 CHUNK_SIZES="0.5 1 2 4" EVAL_TOKENS=262144 \
  TOKENIZER_PATH=/root/sca/data/bpe/tokenizer.json \
  TRAIN_TOKENS=/root/sca/data/bpe/train.pt \
  VALID_TOKENS=/root/sca/data/bpe/val.pt \
  bash scripts/train_all.sh > "$LOG" 2>&1 &
echo "SWEEP pid=$! log=/root/sca/$LOG"
sleep 30
echo "### log head"; head -n 8 "$LOG"
echo "### running"; pgrep -af 'common.train' | sed 's/--data-path.*//' | head -3
