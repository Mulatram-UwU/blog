#!/usr/bin/env python3
"""Is the global gradient clip starving the trunk?

clip_grad_norm_ scales every parameter by the same factor, so if the indexer's
auxiliary gradient dominates the total norm the trunk's effective step shrinks
with it.  Reports the two norms separately and the resulting clip factor.

    PYTHONPATH=. python tools/diag_clip.py
"""

from __future__ import annotations

import torch

from common.data import get_batch, load_token_tensor
from sca_duo.model import SCADuoModel

BLOCK, BATCH, CHUNK, STEPS, CLIP = 256, 32, 0.5, 25, 1.0
CASES = [("code_std=0.30", 0.30), ("code_std=1.00", 1.00)]


def build(code_std, device):
    return SCADuoModel(vocab_size=8192, block_size=BLOCK, emb_dim=512, n_heads=8, n_layer=6,
                       dropout=0.1, q_latent_dim=64, kv_latent_dim=64, latent_dim=4,
                       chunk_size=CHUNK, detach_indexer=True, aux_mode="rate", aux_beta=0.0,
                       code_std=code_std).to(device)


def main():
    device = torch.device("cuda")
    train = load_token_tensor("data/bpe/train.pt").to(device)
    for name, code_std in CASES:
        torch.manual_seed(1337)
        torch.cuda.manual_seed_all(1337)
        model = build(code_std, device).train()
        named = [(n, p) for n, p in model.named_parameters() if ".indexer." in n]
        ids = {id(p) for _, p in named}
        trunk = [p for p in model.parameters() if id(p) not in ids]
        optimizer = torch.optim.AdamW(model.parameters(), lr=3e-4, weight_decay=0.1)
        scaler = torch.amp.GradScaler("cuda", enabled=True)
        generator = torch.Generator(device=device).manual_seed(1337)
        print("=== %s ===" % name)
        print("%6s %14s %14s %14s %11s %12s" % (
            "step", "trunk_norm", "indexer_norm", "total_norm", "clip_factor", "trunk_kept"))
        for step in range(1, STEPS + 1):
            tokens, targets = get_batch(train, BLOCK, BATCH, device, generator)
            optimizer.zero_grad(set_to_none=True)
            with torch.autocast(device_type="cuda", dtype=torch.float16, enabled=True):
                _, loss, metrics = model(tokens, targets)
                total = loss + metrics["aux_loss"]
            scaler.scale(total).backward()
            scaler.unscale_(optimizer)
            tn = float(sum(float(p.grad.norm()) ** 2 for p in trunk if p.grad is not None)) ** 0.5
            inn = float(sum(float(p.grad.norm()) ** 2 for p in named_param(p)
                            for p in [p[1]] if p.grad is not None)) ** 0.5 if False else \
                float(sum(float(p.grad.norm()) ** 2 for _, p in named if p.grad is not None)) ** 0.5
            tot = (tn ** 2 + inn ** 2) ** 0.5
            factor = min(1.0, CLIP / tot) if tot > 0 else 1.0
            if step <= 3 or step % 8 == 0:
                print("%6d %14.4f %14.4f %14.4f %11.4f %12.4f" % (
                    step, tn, inn, tot, factor, factor))
            torch.nn.utils.clip_grad_norm_(model.parameters(), CLIP)
            scaler.step(optimizer)
            scaler.update()
        print()


if __name__ == "__main__":
    main()
