#!/usr/bin/env bash
set -u
cd /root/sca
rm -rf result/smoke result/logs/smoke.log
mkdir -p result/logs
PY="$(cat .python_path 2>/dev/null || echo /root/miniconda3/bin/python)"
nohup env PYTHON_BIN="$PY" DEVICE=cuda OUT=result/smoke bash scripts/smoke_cpu.sh > result/logs/smoke.log 2>&1 &
echo "LAUNCHED pid=$! log=/root/sca/result/logs/smoke.log"
