#!/usr/bin/env python3
"""Calibrate the pinned code spread, then train the calibrated configuration.

Sparsity has to be a constraint: every loss term we tried prefers a dense
partition, so the code spread is pinned (with a detached scale) and chunk_size
plus code_std then determine the density.  This finds the code_std whose static
density is closest to a target, then trains it with the distortion term only.

    PYTHONPATH=. python tools/probe_code_std.py
"""

from __future__ import annotations

import csv

import torch

from common.data import get_batch, iter_batches, load_token_tensor
from sca_duo.model import SCADuoModel

BLOCK, BATCH, CHUNK = 256, 32, 0.5
EVAL_TOKENS, TARGET_DENSITY, STEPS = 262144, 0.30, 400
CODE_STDS = (0.2, 0.3, 0.4, 0.5, 0.65, 0.8, 1.0)


def build(code_std, device, dropout=0.0):
    return SCADuoModel(vocab_size=8192, block_size=BLOCK, emb_dim=512, n_heads=8, n_layer=6,
                       dropout=dropout, q_latent_dim=64, kv_latent_dim=64, latent_dim=4,
                       chunk_size=CHUNK, detach_indexer=True, aux_mode="rate", aux_beta=0.0,
                       code_std=code_std).to(device)


def probe(model, tokens, targets):
    _, _, metrics = model(tokens, targets)
    indexer = model.blocks[0].attention.indexer
    hidden = model.blocks[0].ln1(model.embed(tokens))
    z_q, z_k = indexer.encode(model.blocks[0].attention.q_down(hidden),
                              model.blocks[0].attention.kv_down(hidden))
    occupied = torch.unique(indexer.chunk_coordinates(z_k).reshape(-1, indexer.latent_dim), dim=0)
    return (int(occupied.shape[0]), float(metrics["avg_candidates"]),
            float(metrics["candidate_density"]), float(metrics["routing_recall"]),
            float(indexer.cell_coordinates(z_k).std()))


def main():
    device = torch.device("cuda")
    valid = load_token_tensor("data/bpe/val.pt").to(device)
    tokens, targets = get_batch(valid, BLOCK, BATCH, device,
                                torch.Generator(device=device).manual_seed(7))

    print("=== static: chunk=%g, cells(C)=%d ===" % (CHUNK, (2.0 / CHUNK) ** 4))
    print("%9s %9s %9s %9s %9s %10s" % ("code_std", "occupied", "avg_cand", "density", "recall", "u_std"))
    best, best_gap = CODE_STDS[0], 1e9
    for code_std in CODE_STDS:
        model = build(code_std, device).eval()
        with torch.no_grad():
            occ, cand, dens, rec, ustd = probe(model, tokens, targets)
        print("%9.2f %9d %9.2f %9.4f %9.4f %10.3f" % (code_std, occ, cand, dens, rec, ustd))
        if abs(dens - TARGET_DENSITY) < best_gap:
            best, best_gap = code_std, abs(dens - TARGET_DENSITY)
    print()
    print("closest to density %.2f: code_std=%.2f (got %.4f)" % (TARGET_DENSITY, best, best_gap))

    baseline = {}
    with open("result/baseline/metrics.csv") as handle:
        for row in csv.DictReader(handle):
            if row.get("val_loss"):
                baseline[int(row["step"])] = float(row["val_loss"])

    print()
    print("=== training code_std=%.2f for %d steps (distortion only) ===" % (best, STEPS))
    train = load_token_tensor("data/bpe/train.pt").to(device)
    torch.manual_seed(1337)
    torch.cuda.manual_seed_all(1337)
    model = build(best, device, dropout=0.1).train()
    named = [(n, p) for n, p in model.named_parameters() if ".indexer." in n]
    ids = {id(p) for _, p in named}
    optimizer = torch.optim.AdamW(
        [{"params": [p for p in model.parameters() if id(p) not in ids], "lr": 3e-4, "lr_scale": 1.0},
         {"params": [p for _, p in named], "lr": 3e-5, "lr_scale": 0.1}], lr=3e-4, weight_decay=0.1)
    scaler = torch.amp.GradScaler("cuda", enabled=True)
    generator = torch.Generator(device=device).manual_seed(1337)
    print("%7s %10s %10s %9s %9s %9s %9s" % (
        "step", "train_loss", "val_loss", "gap", "occupied", "avg_cand", "density"))
    for step in range(1, STEPS + 1):
        lr = 3e-4 * min(float(step) / 100.0, 1.0)
        for group in optimizer.param_groups:
            group["lr"] = lr * group.get("lr_scale", 1.0)
        batch_tokens, batch_targets = get_batch(train, BLOCK, BATCH, device, generator)
        optimizer.zero_grad(set_to_none=True)
        with torch.autocast(device_type="cuda", dtype=torch.float16, enabled=True):
            _, loss, metrics = model(batch_tokens, batch_targets)
            total = loss + metrics["aux_loss"]
        scaler.scale(total).backward()
        scaler.unscale_(optimizer)
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        scaler.step(optimizer)
        scaler.update()
        if step % 50 == 0 or step == 1:
            model.eval()
            total_val, seen = 0.0, 0
            with torch.no_grad():
                for vt, vg in iter_batches(valid[:EVAL_TOKENS], BLOCK, BATCH, device):
                    _, vloss, _ = model(vt, vg)
                    total_val += float(vloss.detach().float()) * vg.numel()
                    seen += vg.numel()
            occ, cand, dens, rec, ustd = probe(model, tokens, targets)
            model.train()
            print("%7d %10.4f %10.4f %9.4f %9d %9.2f %9.4f" % (
                step, float(loss.detach().float()), total_val / seen,
                total_val / seen - baseline.get(step, float("nan")), occ, cand, dens))


if __name__ == "__main__":
    main()
