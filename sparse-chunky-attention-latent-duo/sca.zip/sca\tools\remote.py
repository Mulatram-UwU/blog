#!/usr/bin/env python3
"""SSH / SFTP helper for the remote AutoDL experiment box.

The password is never stored in the repository: it is read from the
SCA_SSH_PASSWORD environment variable, and only used when public-key auth
is not available.

Examples:
    python tools/remote.py run "nvidia-smi -L"
    python tools/remote.py run-script tools/probe.sh
    python tools/remote.py put src/sca_l/train.py /root/sca/src/sca_l/train.py
    python tools/remote.py get /root/sca/result/baseline/baseline.csv result/
"""

from __future__ import annotations

import argparse
import os
import pathlib
import sys

import paramiko

DEFAULT_HOST = "connect.westc.seetacloud.com"
DEFAULT_PORT = 16416
DEFAULT_USER = "root"


def connect() -> paramiko.SSHClient:
    host = os.environ.get("SCA_SSH_HOST", DEFAULT_HOST)
    port = int(os.environ.get("SCA_SSH_PORT", str(DEFAULT_PORT)))
    user = os.environ.get("SCA_SSH_USER", DEFAULT_USER)
    password = os.environ.get("SCA_SSH_PASSWORD")
    key_path = os.environ.get("SCA_SSH_KEY")

    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    common = dict(
        hostname=host,
        port=port,
        username=user,
        timeout=30,
        banner_timeout=30,
        auth_timeout=30,
        allow_agent=False,
    )
    errors = []
    if key_path:
        try:
            client.connect(key_filename=key_path, look_for_keys=False, **common)
            return client
        except Exception as exc:  # noqa: BLE001 - fall back to the password
            errors.append("key: " + str(exc))
    try:
        client.connect(password=password, look_for_keys=False, **common)
    except Exception as exc:  # noqa: BLE001 - report both attempts
        errors.append("password: " + str(exc))
        raise SystemExit("SSH connection failed -> " + " | ".join(errors))
    return client


def _drain(stdout, stderr) -> int:
    out = stdout.read().decode("utf-8", "replace")
    err = stderr.read().decode("utf-8", "replace")
    status = stdout.channel.recv_exit_status()
    if out:
        sys.stdout.write(out)
    if err:
        sys.stderr.write(err)
    return status


def run_command(client: paramiko.SSHClient, command: str, timeout: float) -> int:
    _, stdout, stderr = client.exec_command(command, timeout=timeout)
    return _drain(stdout, stderr)


def run_script(client: paramiko.SSHClient, path: str, timeout: float) -> int:
    payload = pathlib.Path(path).read_bytes()
    stdin, stdout, stderr = client.exec_command("bash -s", timeout=timeout)
    stdin.write(payload)
    stdin.flush()
    stdin.channel.shutdown_write()
    return _drain(stdout, stderr)


def ensure_remote_dir(sftp: paramiko.SFTPClient, directory: str) -> None:
    parts = pathlib.PurePosixPath(directory).parts
    current = "/" if directory.startswith("/") else ""
    for part in parts:
        if part in ("", "/"):
            continue
        current = current.rstrip("/") + "/" + part if current else part
        try:
            sftp.stat(current)
        except OSError:
            sftp.mkdir(current)


def main() -> int:
    parser = argparse.ArgumentParser(description="remote SSH/SFTP helper")
    parser.add_argument("--timeout", type=float, default=1800.0, help="command timeout in seconds")
    sub = parser.add_subparsers(dest="action", required=True)

    p_run = sub.add_parser("run", help="run one shell command")
    p_run.add_argument("command")

    p_script = sub.add_parser("run-script", help="pipe a local shell script into bash -s")
    p_script.add_argument("path")

    p_put = sub.add_parser("put", help="upload one file")
    p_put.add_argument("local")
    p_put.add_argument("remote")

    p_get = sub.add_parser("get", help="download one file")
    p_get.add_argument("remote")
    p_get.add_argument("local")

    args = parser.parse_args()
    client = connect()
    try:
        if args.action == "run":
            return run_command(client, args.command, args.timeout)
        if args.action == "run-script":
            return run_script(client, args.path, args.timeout)
        sftp = client.open_sftp()
        try:
            if args.action == "put":
                parent = str(pathlib.PurePosixPath(args.remote).parent)
                if parent and parent != ".":
                    ensure_remote_dir(sftp, parent)
                sftp.put(args.local, args.remote)
            else:
                parent = str(pathlib.PurePath(args.local).parent)
                if parent and parent != ".":
                    pathlib.Path(parent).mkdir(parents=True, exist_ok=True)
                sftp.get(args.remote, args.local)
        finally:
            sftp.close()
        return 0
    finally:
        client.close()


if __name__ == "__main__":
    raise SystemExit(main())
