#!/usr/bin/env bash
# Report the box, pick the interpreter that has torch, and make sure the dataset exists.
set -u
cd /root/sca

PY=""
for candidate in /root/miniconda3/bin/python /usr/bin/python3 /usr/bin/python python3 python; do
  if command -v "$candidate" >/dev/null 2>&1 && "$candidate" -c 'import torch' >/dev/null 2>&1; then
    PY="$candidate"; break
  fi
done
if [ -z "$PY" ]; then
  echo "FATAL: no interpreter with torch"
  for candidate in python3 python /root/miniconda3/bin/python; do
    command -v "$candidate" >/dev/null 2>&1 && { echo "--- $candidate"; "$candidate" -V; }
  done
  exit 1
fi
echo "PYTHON_BIN=$PY"
"$PY" -V
"$PY" -c 'import torch;print("torch",torch.__version__,"cuda",torch.cuda.is_available(),"cuda_ver",torch.version.cuda)'
"$PY" -c 'import matplotlib;print("matplotlib",matplotlib.__version__)' 2>&1 | tail -1

echo "### gpu"
nvidia-smi --query-gpu=name,memory.total,memory.used --format=csv,noheader
echo "### disk"
df -h / /root/autodl-tmp 2>/dev/null | tail -3

mkdir -p result/logs data
if [ ! -s data/tinyshakespeare.txt ]; then
  if [ -f /etc/network_turbo ]; then source /etc/network_turbo || true; fi
  if timeout 90 curl -fsSL -o data/tinyshakespeare.txt https://raw.githubusercontent.com/karpathy/char-rnn/master/data/tinyshakespeare/input.txt; then
    echo "dataset ok: $(wc -c < data/tinyshakespeare.txt) bytes"
  else
    echo "dataset download FAILED"
  fi
else
  echo "dataset already present: $(wc -c < data/tinyshakespeare.txt) bytes"
fi

echo "$PY" > .python_path
echo "### tree"
find /root/sca -maxdepth 2 -name '*.py' -o -maxdepth 2 -name '*.sh' | sort
