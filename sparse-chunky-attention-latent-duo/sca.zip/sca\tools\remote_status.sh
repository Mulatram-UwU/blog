#!/usr/bin/env bash
cd /root/sca
echo "### trainers"; pgrep -af 'common.train' | sed 's/--data-path.*//' | head -3 || echo "(none)"
echo "### tensorboard"; pgrep -af 'tensorboard' | head -2 || echo "(none)"
echo "### sweep log"; tail -n 12 result/logs/train_all.log
echo "### tensorboard log"; tail -n 3 result/logs/tensorboard.log
echo "### tb event dirs"; find result/tensorboard -maxdepth 2 -name 'events*' 2>/dev/null | head
echo "### rows"; for d in result/baseline result/sca_duo_chunk*; do [ -d "$d" ] && echo "$d rows=$(grep -c . "$d/metrics.csv" 2>/dev/null)"; done
