#!/usr/bin/env python3
"""Diagnose the auxiliary loss: does it actually produce a gradient?

Prints, at initialisation, the coordinate spread in cell units, the soft
neighbourhood surrogate's magnitude, and the gradient norm it delivers to the
indexer projection, for a range of temperatures and for the KL objective.

    PYTHONPATH=. python tools/diag_aux.py
"""

from __future__ import annotations

import types

import torch

from common.data import get_batch, load_token_tensor
from sca_duo.indexer import SparseChunkyIndexer
from sca_duo.model import SCADuoModel

BLOCK, BATCH, CHUNK = 256, 32, 0.5


def make_soft(tau):
    def soft(self, z_q, z_k):
        return SparseChunkyIndexer.soft_neighbourhood(self, z_q, z_k, tau)
    return soft


def main():
    device = torch.device("cuda")
    torch.manual_seed(1337)
    torch.cuda.manual_seed_all(1337)
    train = load_token_tensor("data/bpe/train.pt").to(device)
    tokens, targets = get_batch(train, BLOCK, BATCH, device,
                                torch.Generator(device=device).manual_seed(1337))

    model = SCADuoModel(vocab_size=8192, block_size=BLOCK, emb_dim=512, n_heads=8, n_layer=6,
                        dropout=0.0, q_latent_dim=64, kv_latent_dim=64, latent_dim=4,
                        chunk_size=CHUNK, detach_indexer=True, aux_mode="recall").to(device).train()

    indexer = model.blocks[0].attention.indexer
    hidden = model.blocks[0].ln1(model.embed(tokens))
    c_q = model.blocks[0].attention.q_down(hidden)
    c_kv = model.blocks[0].attention.kv_down(hidden)
    with torch.no_grad():
        z_q, z_k = indexer.encode(c_q, c_kv)
        u = indexer.cell_coordinates(z_k)
        du = (indexer.cell_coordinates(z_q)[:, :, None, :]
              - indexer.cell_coordinates(z_k)[:, None, :, :]).abs()
    print("cell coordinate std per axis : %.3f" % float(u.std()))
    print("typical |du| per axis        : mean %.3f  median %.3f  p90 %.3f" % (
        float(du.mean()), float(du.median()), float(du.flatten().quantile(0.9))))
    print("fraction of pairs with all axes within 1 (hard density): %.4f"
          % float((du.amax(dim=-1) <= 1).float().mean()))
    print()

    def grad_norm():
        total = 0.0
        for block in model.blocks:
            for name in ("q_index", "k_index"):
                weight = getattr(block.attention.indexer, name).weight.grad
                if weight is not None:
                    total += float(weight.norm()) ** 2
        return total ** 0.5

    print("%-10s %10s %10s %12s %12s %14s" % (
        "mode", "soft_mean", "soft>0.01", "recall", "aux", "grad_norm"))
    for tau in (0.25, 0.5, 1.0, 2.0, 3.0, 6.0):
        for block in model.blocks:
            block.attention.indexer.soft_neighbourhood = types.MethodType(
                make_soft(tau), block.attention.indexer)
        model.zero_grad(set_to_none=True)
        with torch.autocast(device_type="cuda", dtype=torch.float16, enabled=True):
            _, _, metrics = model(tokens, targets)
        aux = metrics["aux_loss"]
        soft = model.blocks[0].attention.indexer.soft_neighbourhood(
            model.blocks[0].attention.indexer.encode(c_q, c_kv)[0].detach(),
            model.blocks[0].attention.indexer.encode(c_q, c_kv)[1].detach())
        aux.float().backward()
        print("recall t=%-3.2f %10.5f %10.5f %12.5f %12.5f %14.3e" % (
            tau, float(soft.mean()), float((soft > 0.01).float().mean()),
            float(metrics["routing_recall"]), float(aux.detach()), grad_norm()))

    for block in model.blocks:
        block.attention.aux_mode = "kl"
    model.zero_grad(set_to_none=True)
    with torch.autocast(device_type="cuda", dtype=torch.float16, enabled=True):
        _, _, metrics = model(tokens, targets)
    metrics["aux_loss"].float().backward()
    print("%-10s %10s %10s %12s %12.5f %14.3e" % (
        "kl", "-", "-", float(metrics["routing_recall"]), float(metrics["aux_loss"].detach()),
        grad_norm()))


if __name__ == "__main__":
    main()
