#!/usr/bin/env bash
# Full-epoch runs across the density frontier, with the separate gradient clips.
set -u
cd /root/sca
PY=/root/miniconda3/bin/python
export PYTHONPATH=/root/sca

run_one () {
  local cs="$1"
  local tag="$2"
  echo "== full epoch code_std=$cs =="
  "$PY" -m common.train --model sca_duo \
    --output-dir "result/epoch_$tag" \
    --tensorboard-dir "result/tensorboard/epoch_$tag" \
    --q-latent-dim 64 --sca-latent-dim 4 --chunk-size 0.5 --code-std "$cs" \
    --aux-mode rate --aux-beta 0.0 --indexer-lr-scale 0.1 --detach-indexer \
    --tokenizer-path /root/sca/data/bpe/tokenizer.json \
    --train-tokens /root/sca/data/bpe/train.pt \
    --valid-tokens /root/sca/data/bpe/val.pt \
    --device cuda --block-size 256 --batch-size 32 --steps 7755 \
    --eval-every 50 --eval-tokens 262144 --save-every 50 --keep-checkpoints 6 \
    --emb-dim 512 --n-heads 8 --n-layer 6 --mla-latent-dim 64 --dropout 0.1 \
    --lr 3e-4 --warmup-steps 100 --weight-decay 0.1 --grad-clip 1.0 --seed 1337 --amp
}

run_one 0.30 e030
run_one 0.65 e065
run_one 0.90 e090
run_one 1.40 e140
echo "== full epoch runs finished =="
