"""Measure how long one checkpoint write costs, weights-only vs with optimizer."""

from __future__ import annotations

import sys
import time

import torch

sys.path.insert(0, "/root/sca")
from baseline.model import BaselineModel

model = BaselineModel(8192, 256, 512, 8, 6, 0.0, 64, 64).cuda()
base = {"model": model.state_dict(), "step": 1, "config": model.config(), "vocab_meta": {}, "args": {}}
optimizer = torch.optim.AdamW(model.parameters())
full = dict(base)
full["optimizer"] = optimizer.state_dict()

for label, payload, path in (
    ("weights only", base, "/root/sca/result/logs/_probe_w.pt"),
    ("with optimizer", full, "/root/sca/result/logs/_probe_f.pt"),
):
    times = []
    for _ in range(3):
        started = time.time()
        torch.save(payload, path)
        times.append(time.time() - started)
    print("%-15s %.3f s  (%.0f MB)" % (label, min(times), 0), flush=True)

import os
print("weights file %.0f MB, full file %.0f MB" % (
    os.path.getsize("/root/sca/result/logs/_probe_w.pt") / 1e6,
    os.path.getsize("/root/sca/result/logs/_probe_f.pt") / 1e6), flush=True)
