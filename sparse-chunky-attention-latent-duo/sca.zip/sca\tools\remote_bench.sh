#!/usr/bin/env bash
set -u
cd /root/sca
pkill -f 'common.train' 2>/dev/null && echo "killed sweep" || echo "no sweep"
sleep 2
PY="$(cat .python_path)"
PYTHONPATH=/root/sca nohup "$PY" tools/bench_step.py \
  --train-tokens /root/sca/data/bpe/train.pt --valid-tokens /root/sca/data/bpe/val.pt \
  --vocab 8192 --block 256 --batches 32 64 128 --iterations 6 > result/logs/bench.log 2>&1 &
echo "BENCH pid=$! log=/root/sca/result/logs/bench.log"
sleep 60
tail -n 12 result/logs/bench.log
