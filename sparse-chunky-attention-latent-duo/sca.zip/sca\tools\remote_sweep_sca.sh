#!/usr/bin/env bash
# Full-epoch SCA-L Duo sweep: locked design, indexer lr scaled to 0.1 and the
# distillation detached from the MLA trunk so the only difference from the
# baseline is the routing itself.
set -u
cd /root/sca
PY="$(cat .python_path 2>/dev/null || echo /root/miniconda3/bin/python)"

echo "### stop anything already running"
pkill -f 'common.train' 2>/dev/null && echo "killed existing trainers" || echo "no trainer running"
sleep 3
pgrep -f 'common.train' >/dev/null 2>&1 && { echo "WARNING: trainers still alive"; exit 1; }
echo "confirmed: no trainer running"

export PYTHONPATH=/root/sca
echo "### regression tests"
"$PY" tests/test_indexer_mask.py || exit 1

echo "### archiving any pre-fix metrics"
mkdir -p result/diagnosis
for r in sca_duo_chunk0p5 sca_duo_chunk1 sca_duo_chunk2 sca_duo_chunk4; do
  if [ -f "result/$r/metrics.csv" ] && [ ! -f "result/diagnosis/drift_collapse_$r.csv" ]; then
    cp "result/$r/metrics.csv" "result/diagnosis/drift_collapse_$r.csv" && echo "archived drift_collapse_$r.csv"
  fi
done

echo "### clearing previous sca_duo runs (baseline is kept)"
for d in result/sca_duo_chunk0p5 result/sca_duo_chunk1 result/sca_duo_chunk2 result/sca_duo_chunk4; do
  [ -e "$d" ] && rm -rf "$d" && echo "removed /root/sca/$d"
done
for d in result/tensorboard/sca_duo_chunk0p5 result/tensorboard/sca_duo_chunk1 result/tensorboard/sca_duo_chunk2 result/tensorboard/sca_duo_chunk4; do
  [ -e "$d" ] && rm -rf "$d" && echo "removed /root/sca/$d"
done
echo "### baseline kept:"; ls result/baseline

LOG=result/logs/train_all.log
: > "$LOG"
nohup env PYTHON_BIN="$PY" DEVICE=cuda AMP=1 STEPS=7755 EVAL_EVERY=50 SAVE_EVERY=50 \
  KEEP_CHECKPOINTS=6 CHUNK_SIZES="0.5 1 2 4" EVAL_TOKENS=262144 RUN_BASELINE=0 \
  INDEXER_LR_SCALE=0.1 DETACH_INDEXER=1 \
  TOKENIZER_PATH=/root/sca/data/bpe/tokenizer.json \
  TRAIN_TOKENS=/root/sca/data/bpe/train.pt \
  VALID_TOKENS=/root/sca/data/bpe/val.pt \
  bash scripts/train_all.sh > "$LOG" 2>&1 &
echo "SWEEP pid=$! log=/root/sca/$LOG"
sleep 40
echo "### log head"; head -n 20 "$LOG"
echo "### running"; pgrep -af 'common.train' | sed 's/--tokenizer.*//' | head -2
