#!/usr/bin/env bash
cd /root/sca
for i in $(seq 1 600); do
  if ! pgrep -f 'common.train' >/dev/null 2>&1; then
    echo "FINISHED after $((i * 30)) seconds"
    break
  fi
  if [ $((i % 10)) -eq 0 ]; then
    cur=$(pgrep -af 'common.train' | head -1 | sed 's/.*--output-dir \([^ ]*\).*/\1/')
    rows=$(grep -c . result/baseline/metrics.csv 2>/dev/null)
    echo "t=$((i * 30))s current=$cur baseline_rows=$rows"
  fi
  sleep 30
done
echo "### still running?"; pgrep -af 'common.train' | head -3 || echo "(none)"
echo "### log tail"; tail -n 25 result/logs/train_all.log
echo "### per-run rows"
for d in result/baseline result/sca_duo_chunk*; do
  [ -d "$d" ] && echo "$d rows=$(grep -c . "$d/metrics.csv" 2>/dev/null)"
done
echo "### disk"; df -h /root | tail -1; du -sh result 2>/dev/null
