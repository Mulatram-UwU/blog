#!/usr/bin/env python3
"""Reproduce and localise the SCA-L Duo NaN with stage-by-stage finiteness checks.

Run on the GPU box:
    python tools/diag_nan.py --steps 200 --chunk-size 0.5
"""

from __future__ import annotations

import argparse

import torch
from torch.nn import functional as F

from common.data import get_batch, load_token_tensor
from sca_duo.model import SCADuoAttention, SCADuoModel

DEBUG = {"step": 0, "active": False, "events": []}


def note(msg):
    DEBUG["events"].append(msg)
    print(msg, flush=True)


def check(name, tensor):
    """-inf is the intended mask, so only NaN and +inf count as failures."""
    nan = int(torch.isnan(tensor).sum())
    posinf = int((tensor == float("inf")).sum())
    if not nan and not posinf:
        return True
    bad = torch.isnan(tensor) | (tensor == float("inf"))
    note("  BROKEN %-20s shape=%s nan=%d +inf=%d first=%s"
         % (name, tuple(tensor.shape), nan, posinf, bad.nonzero()[:5].tolist()))
    return False


def debug_forward(self, x, collect_stats=False):
    step = DEBUG["step"]
    report = DEBUG["active"]

    def chk(name, tensor):
        if report:
            check("step%d %s" % (step, name), tensor)
        return tensor

    q, k, v, c_q, c_kv = self.project(x)
    chk("c_q", c_q)
    chk("c_kv", c_kv)
    batch, _, sequence, _ = q.shape
    causal = self.causal(sequence, x.device)

    z_q, z_k = self.indexer.encode(c_q, c_kv)
    chk("z_q", z_q)
    chk("z_k", z_k)
    candidate = self.indexer.candidate_mask(z_q, z_k, causal)

    counts = candidate.sum(dim=-1)
    if report and int((counts == 0).sum()) > 0:
        pos = (counts == 0).nonzero()[:3].tolist()
        note("  step%d EMPTY CANDIDATE ROWS=%d min=%d at %s"
             % (step, int((counts == 0).sum()), int(counts.min()), pos))
        b0, t0 = pos[0]
        note("    z_q=%s" % z_q[b0, t0].detach().tolist())
        note("    z_k[:8]=%s" % z_k[b0, :8].detach().tolist())
        note("    c_q=%s" % c_q[b0, t0].detach().tolist())

    dense_weights = F.softmax(self.masked_scores(q, k), dim=-1)
    chk("dense_weights", dense_weights)
    teacher = dense_weights.detach().mean(dim=1)
    chk("teacher", teacher)

    index_logits = self.indexer.logits(z_q, z_k, causal)
    chk("index_logits", index_logits)
    log_index = F.log_softmax(index_logits, dim=-1).clamp_min(-1e30)
    chk("log_index", log_index)
    aux_loss = (teacher * (teacher.clamp_min(1e-12).log() - log_index)).sum(dim=-1).mean()
    chk("aux_loss", aux_loss)

    scores = self.masked_scores(q, k, candidate)
    chk("sparse_scores", scores)
    sparse_weights = F.softmax(scores, dim=-1)
    chk("sparse_weights", sparse_weights)
    sparse_weights = F.dropout(sparse_weights, p=self.dropout_p, training=self.training)
    attended = (sparse_weights @ v).transpose(1, 2).contiguous().view(batch, sequence, self.emb_dim)
    output = self.resid_dropout(self.out_proj(attended))
    chk("output", output)

    finite_logits = index_logits.detach().float()
    finite_logits = finite_logits[torch.isfinite(finite_logits)]
    finite_scores = scores.detach().float()
    finite_scores = finite_scores[torch.isfinite(finite_scores)]
    DEBUG["probe"] = {
        "max_index_logit": float(finite_logits.abs().max()) if finite_logits.numel() else float("nan"),
        "max_sparse_score": float(finite_scores.abs().max()) if finite_scores.numel() else float("nan"),
        "latent_norm": float(z_q.detach().float().norm(dim=-1).mean()),
        "min_candidates": int(counts.min()),
    }

    stats = {}
    if collect_stats:
        visible = causal.logical_not().sum(dim=-1).clamp_min(1).to(torch.float32)
        cfloat = counts.to(torch.float32)
        stats = {
            "avg_candidates": cfloat.mean(),
            "candidate_density": (cfloat / visible).mean(),
            "routing_recall": (teacher * candidate).sum(dim=-1).mean(),
            "indexer_latent_norm": z_q.detach().norm(dim=-1).mean(),
        }
    return output, aux_loss, stats


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--steps", type=int, default=200)
    parser.add_argument("--chunk-size", type=float, default=0.5)
    parser.add_argument("--train-tokens", default="data/bpe/train.pt")
    parser.add_argument("--block-size", type=int, default=256)
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--seed", type=int, default=1337)
    parser.add_argument("--watched", type=int, default=120, help="start detailed reporting at this step")
    return parser.parse_args()


def main():
    args = parse_args()
    SCADuoAttention.forward = debug_forward

    device = torch.device("cuda")
    torch.manual_seed(args.seed)
    torch.cuda.manual_seed_all(args.seed)
    torch.set_float32_matmul_precision("high")

    train_data = load_token_tensor(args.train_tokens).to(device)
    model = SCADuoModel(vocab_size=8192, block_size=args.block_size, emb_dim=512, n_heads=8,
                        n_layer=6, dropout=0.1, q_latent_dim=64, kv_latent_dim=64,
                        latent_dim=4, chunk_size=args.chunk_size).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=3e-4, weight_decay=0.1)
    scaler = torch.amp.GradScaler("cuda", enabled=True)
    generator = torch.Generator(device=device).manual_seed(args.seed)
    model.train()

    for step in range(1, args.steps + 1):
        DEBUG["step"] = step
        DEBUG["active"] = step >= args.watched
        lr = 3e-4 * min(float(step) / 100.0, 1.0)
        for group in optimizer.param_groups:
            group["lr"] = lr
        tokens, targets = get_batch(train_data, args.block_size, args.batch_size, device, generator)
        optimizer.zero_grad(set_to_none=True)
        with torch.autocast(device_type="cuda", dtype=torch.float16, enabled=True):
            _, loss, metrics = model(tokens, targets)
            total_loss = loss + metrics["aux_loss"]
        scaler.scale(total_loss).backward()
        scaler.unscale_(optimizer)
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        grad_bad = sum(int((~torch.isfinite(p.grad)).sum()) for p in model.parameters() if p.grad is not None)
        scaler.step(optimizer)
        scaler.update()
        weight_bad = sum(int((~torch.isfinite(p)).sum()) for p in model.parameters())
        probe = DEBUG.get("probe", {})
        if DEBUG["active"] or grad_bad or not torch.isfinite(total_loss):
            note("step=%d loss=%.6f aux=%.6g grad_bad=%d weight_bad=%d scale=%.1f "
                 "max_index_logit=%.4g max_score=%.4g latent_norm=%.4g min_cand=%s"
                 % (step, float(loss.detach().float()), float(metrics["aux_loss"].detach().float()),
                    grad_bad, weight_bad, scaler.get_scale(),
                    probe.get("max_index_logit", -1), probe.get("max_sparse_score", -1),
                    probe.get("latent_norm", -1), probe.get("min_candidates", -1)))
        if not torch.isfinite(total_loss):
            note(">>> FIRST NON-FINITE LOSS AT STEP %d" % step)
            break

    print("=== events ===")
    for line in DEBUG["events"][:40]:
        print(line)


if __name__ == "__main__":
    main()
