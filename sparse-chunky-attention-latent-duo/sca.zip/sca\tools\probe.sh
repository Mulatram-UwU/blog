#!/usr/bin/env bash
# Read-only reconnaissance of the AutoDL experiment box.
echo "### host"
hostname; whoami; uptime | tr -s ' '
echo "### gpu"
nvidia-smi --query-gpu=name,memory.total,memory.used,driver_version --format=csv,noheader 2>&1
nvidia-smi 2>/dev/null | grep -i "CUDA Version"
echo "### cpu / memory / disk"
nproc
free -g | head -2
df -h /root /root/autodl-tmp 2>/dev/null | tail -4
echo "### python"
which python python3
python -V
python -m pip -V
echo "### torch"
python -c 'import torch; print("torch", torch.__version__, "cuda_available", torch.cuda.is_available(), "cuda", torch.version.cuda)' 2>&1 | tail -3
echo "### triton"
python -c 'import triton; print("triton", triton.__version__)' 2>&1 | tail -3
echo "### packages"
python -m pip list 2>/dev/null | grep -iE '^(torch|triton|numpy|matplotlib|pandas|scipy) '
echo "### filesystem"
ls -la /root | head -25
echo "--- autodl-tmp"
ls -la /root/autodl-tmp 2>/dev/null | head -15
echo "### network"
timeout 25 curl -s -o /dev/null -w "raw.githubusercontent.com:%{http_code}\n" https://raw.githubusercontent.com/karpathy/char-rnn/master/data/tinyshakespeare/input.txt || echo "curl failed"
timeout 25 curl -s -o /dev/null -w "pypi.org:%{http_code}\n" https://pypi.org/simple/ || echo "pypi curl failed"
echo "### install local public key (idempotent)"
mkdir -p ~/.ssh && chmod 700 ~/.ssh
grep -qxF 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIJIwWMQNgRaIKf0KZlNa/pzhtHHfveLwUgx25idUlHEW mulatram88@outlook.com' ~/.ssh/authorized_keys 2>/dev/null || echo 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIJIwWMQNgRaIKf0KZlNa/pzhtHHfveLwUgx25idUlHEW mulatram88@outlook.com' >> ~/.ssh/authorized_keys
chmod 600 ~/.ssh/authorized_keys
echo "authorized_keys lines: $(wc -l < ~/.ssh/authorized_keys)"
echo "### done"
