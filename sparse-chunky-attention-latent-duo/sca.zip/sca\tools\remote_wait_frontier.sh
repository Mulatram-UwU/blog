#!/usr/bin/env bash
# Wait for the frontier's own completion marker rather than for the trainer to
# disappear, because the watchdog restarts the sweep across network blips.
cd /root/sca
for i in $(seq 1 480); do
  if grep -q 'density frontier finished' result/logs/density_frontier.log 2>/dev/null; then
    echo "FRONTIER FINISHED after $((i)) minutes"
    break
  fi
  sleep 60
done
echo "### per-run rows ###"
for t in t010 t020 t035 t050 t070 t090; do
  f="result/dens_$t/metrics.csv"
  if [ -f "$f" ]; then echo "dens_$t rows=$(grep -c . "$f") last=$(tail -1 "$f" | cut -d, -f1)"; else echo "dens_$t (none)"; fi
done
echo "### log tail ###"
tail -n 6 result/logs/density_frontier.log
echo "### watchdog ###"
pgrep -af 'remote_frontier_watchdog' | head -1 || echo "(watchdog gone)"
