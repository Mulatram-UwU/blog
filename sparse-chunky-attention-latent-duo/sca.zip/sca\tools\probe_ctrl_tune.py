#!/usr/bin/env python3
"""Verify the EMA smoothing actually damps the controller's limit cycle.

Compares control rates with the smoothed measurement, reporting the settled
density spread and the lag-1 autocorrelation (negative => period-two oscillation).

    PYTHONPATH=. python tools/probe_ctrl_tune.py
"""

from __future__ import annotations

import statistics

import torch

from common.data import get_batch, iter_batches, load_token_tensor
from sca_duo.model import SCADuoModel

BLOCK, BATCH, CHUNK, CODE_STD = 256, 32, 0.5, 0.30
EVAL_TOKENS, STEPS, TARGET = 262144, 700, 0.20
RATES = (0.05, 0.02)


def build(rate, device):
    return SCADuoModel(vocab_size=8192, block_size=BLOCK, emb_dim=512, n_heads=8, n_layer=6,
                       dropout=0.1, q_latent_dim=64, kv_latent_dim=64, latent_dim=4,
                       chunk_size=CHUNK, detach_indexer=True, aux_mode="rate", aux_beta=0.0,
                       code_std=CODE_STD, target_density=TARGET,
                       density_ctrl_rate=rate).to(device)


def stats(series):
    mean = statistics.mean(series)
    sd = statistics.pstdev(series)
    dev = [v - mean for v in series]
    denom = sum(d * d for d in dev) or 1.0
    ac1 = sum(dev[i] * dev[i + 1] for i in range(len(dev) - 1)) / denom
    return mean, sd, min(series), max(series), ac1


def main():
    device = torch.device("cuda")
    train = load_token_tensor("data/bpe/train.pt").to(device)
    valid = load_token_tensor("data/bpe/val.pt").to(device)

    print("%9s %10s %9s %9s %9s %11s" % ("rate", "window", "mean", "sd", "band", "lag1_ac"))
    for rate in RATES:
        torch.manual_seed(1337)
        torch.cuda.manual_seed_all(1337)
        model = build(rate, device).train()
        named = [(n, p) for n, p in model.named_parameters() if ".indexer." in n]
        ids = {id(p) for _, p in named}
        trunk = [p for p in model.parameters() if id(p) not in ids]
        optimizer = torch.optim.AdamW(
            [{"params": trunk, "lr": 3e-4, "lr_scale": 1.0},
             {"params": [p for _, p in named], "lr": 3e-5, "lr_scale": 0.1}],
            lr=3e-4, weight_decay=0.1)
        scaler = torch.amp.GradScaler("cuda", enabled=True)
        generator = torch.Generator(device=device).manual_seed(1337)
        series = []
        for step in range(1, STEPS + 1):
            lr = 3e-4 * min(float(step) / 100.0, 1.0)
            for group in optimizer.param_groups:
                group["lr"] = lr * group.get("lr_scale", 1.0)
            tokens, targets = get_batch(train, BLOCK, BATCH, device, generator)
            optimizer.zero_grad(set_to_none=True)
            with torch.autocast(device_type="cuda", dtype=torch.float16, enabled=True):
                _, loss, metrics = model(tokens, targets)
                total = loss + metrics["aux_loss"]
            scaler.scale(total).backward()
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(trunk, 1.0)
            torch.nn.utils.clip_grad_norm_([p for _, p in named], 1.0)
            scaler.step(optimizer)
            scaler.update()
            if step % 25 == 0:
                model.eval()
                tot, seen, dens = 0.0, 0, 0.0
                with torch.no_grad():
                    for vt, vg in iter_batches(valid[:EVAL_TOKENS], BLOCK, BATCH, device):
                        _, vl, vm = model(vt, vg)
                        n = vg.numel()
                        tot += float(vl.detach().float()) * n
                        dens += float(vm["candidate_density"]) * n
                        seen += n
                model.train()
                series.append(dens / seen)
        for label, window in (("all", series), ("settled(last half)", series[len(series)//2:])):
            mean, sd, lo, hi, ac1 = stats(window)
            print("%9.3f %10s %9.4f %9.4f %8.0f%% %11.3f" % (
                rate, label, mean, sd, 100 * sd / mean, ac1))


if __name__ == "__main__":
    main()
