#!/usr/bin/env python3
"""Does the main-task gradient actually reach the indexer?

Trains a short run per objective and reports how far the indexer projection moved
from its initialisation, plus the gradient norm it received.

    PYTHONPATH=. python tools/diag_ste.py
"""

from __future__ import annotations

import torch

from common.data import get_batch, iter_batches, load_token_tensor
from sca_duo.model import SCADuoModel

BLOCK, BATCH, CHUNK, STEPS, SCALE = 256, 32, 0.5, 150, 0.1
EVAL_TOKENS = 262144

SETTINGS = [
    ("frozen (no aux, no ste)", "none", False),
    ("ste only", "none", True),
    ("kl", "kl", False),
]


def indexer_params(model):
    return [p for n, p in model.named_parameters() if ".indexer." in n]


def build(aux_mode, ste_mask, device):
    return SCADuoModel(vocab_size=8192, block_size=BLOCK, emb_dim=512, n_heads=8, n_layer=6,
                       dropout=0.1, q_latent_dim=64, kv_latent_dim=64, latent_dim=4,
                       chunk_size=CHUNK, detach_indexer=True, aux_mode=aux_mode,
                       ste_mask=ste_mask).to(device)


@torch.no_grad()
def density(model, valid, device):
    model.eval()
    hit = 0.0
    seen = 0
    for tokens, targets in iter_batches(valid[:EVAL_TOKENS], BLOCK, BATCH, device):
        _, _, metrics = model(tokens, targets)
        n = targets.numel()
        seen += n
        hit += float(metrics["candidate_density"]) * n
    model.train()
    return hit / seen


def main():
    device = torch.device("cuda")
    train = load_token_tensor("data/bpe/train.pt").to(device)
    valid = load_token_tensor("data/bpe/val.pt").to(device)

    print("%-24s %12s %12s %12s %12s" % (
        "objective", "grad_norm", "rel_move", "density", "recall"))
    for name, aux_mode, ste_mask in SETTINGS:
        torch.manual_seed(1337)
        torch.cuda.manual_seed_all(1337)
        model = build(aux_mode, ste_mask, device).train()
        named = [(n, p) for n, p in model.named_parameters() if ".indexer." in n]
        ids = {id(p) for _, p in named}
        groups = [{"params": [p for p in model.parameters() if id(p) not in ids],
                   "lr": 3e-4, "lr_scale": 1.0},
                  {"params": [p for _, p in named], "lr": 3e-4 * SCALE, "lr_scale": SCALE}]
        optimizer = torch.optim.AdamW(groups, lr=3e-4, weight_decay=0.1)
        scaler = torch.amp.GradScaler("cuda", enabled=True)
        generator = torch.Generator(device=device).manual_seed(1337)
        before = [p.detach().clone() for p in indexer_params(model)]
        norms = []
        for step in range(1, STEPS + 1):
            lr = 3e-4 * min(float(step) / 100.0, 1.0)
            for group in optimizer.param_groups:
                group["lr"] = lr * group.get("lr_scale", 1.0)
            tokens, targets = get_batch(train, BLOCK, BATCH, device, generator)
            optimizer.zero_grad(set_to_none=True)
            with torch.autocast(device_type="cuda", dtype=torch.float16, enabled=True):
                _, loss, metrics = model(tokens, targets)
                total = loss + metrics["aux_loss"]
            scaler.scale(total).backward()
            scaler.unscale_(optimizer)
            norms.append(float(sum(float(p.grad.norm()) ** 2 for p in indexer_params(model)
                                   if p.grad is not None) ** 0.5))
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            scaler.step(optimizer)
            scaler.update()
        moved = sum(float((p - b).norm()) ** 2 for p, b in zip(indexer_params(model), before)) ** 0.5
        base = sum(float(b.norm()) ** 2 for b in before) ** 0.5
        model.eval()
        with torch.no_grad():
            _, _, m = model(*next(iter(iter_batches(valid[:EVAL_TOKENS], BLOCK, BATCH, device))))
        model.train()
        print("%-24s %12.3e %12.4f %12.4f %12.4f" % (
            name, sum(norms) / len(norms), moved / base,
            density(model, valid, device), float(m["routing_recall"])))


if __name__ == "__main__":
    main()
