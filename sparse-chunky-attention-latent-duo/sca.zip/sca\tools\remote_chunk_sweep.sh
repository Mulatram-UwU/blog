#!/usr/bin/env bash
# Full chunk_size sweep at the widest code spread.  chunk_size and code_std are
# the same knob (only code_std / chunk_size sets the density), so pinning code_std
# at 1.0 is what makes the four chunk sizes span the sparse-to-dense range.
set -u
cd /root/sca
PY=/root/miniconda3/bin/python
export PYTHONPATH=/root/sca

run_one () {
  local chunk="$1"
  local tag="$2"
  echo "== chunk_size=$chunk (code_std=1.0, distortion-only aux) =="
  "$PY" -m common.train --model sca_duo \
    --output-dir "result/final_$tag" \
    --tensorboard-dir "result/tensorboard/final_$tag" \
    --q-latent-dim 64 --sca-latent-dim 4 --chunk-size "$chunk" --code-std 1.0 \
    --aux-mode rate --aux-beta 0.0 --indexer-lr-scale 0.1 --detach-indexer \
    --tokenizer-path /root/sca/data/bpe/tokenizer.json \
    --train-tokens /root/sca/data/bpe/train.pt \
    --valid-tokens /root/sca/data/bpe/val.pt \
    --device cuda --block-size 256 --batch-size 32 --steps 7755 \
    --eval-every 50 --eval-tokens 262144 --save-every 50 --keep-checkpoints 6 \
    --emb-dim 512 --n-heads 8 --n-layer 6 --mla-latent-dim 64 --dropout 0.1 \
    --lr 3e-4 --warmup-steps 100 --weight-decay 0.1 --grad-clip 1.0 --seed 1337 --amp
}

run_one 0.5 chunk0p5
run_one 1 chunk1
run_one 2 chunk2
run_one 4 chunk4
echo "== chunk sweep finished =="
