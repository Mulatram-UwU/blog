#!/usr/bin/env bash
# Density screen: short runs that keep the full-epoch learning-rate schedule, so
# their gap to the baseline at matched steps is directly comparable.  What matters
# is whether the gap is shrinking or growing, not its absolute size.
set -u
cd /root/sca
PY=/root/miniconda3/bin/python
export PYTHONPATH=/root/sca

run_one () {
  local cs="$1"
  local tag="$2"
  echo "== screen code_std=$cs (chunk 0.5) =="
  "$PY" -m common.train --model sca_duo \
    --output-dir "result/screen_$tag" \
    --tensorboard-dir "result/tensorboard/screen_$tag" \
    --q-latent-dim 64 --sca-latent-dim 4 --chunk-size 0.5 --code-std "$cs" \
    --aux-mode rate --aux-beta 0.0 --indexer-lr-scale 0.1 --detach-indexer \
    --tokenizer-path /root/sca/data/bpe/tokenizer.json \
    --train-tokens /root/sca/data/bpe/train.pt \
    --valid-tokens /root/sca/data/bpe/val.pt \
    --device cuda --block-size 256 --batch-size 32 --steps 7755 --stop-at 2400 \
    --eval-every 100 --eval-tokens 262144 --save-every 100000 --keep-checkpoints 0 \
    --emb-dim 512 --n-heads 8 --n-layer 6 --mla-latent-dim 64 --dropout 0.1 \
    --lr 3e-4 --warmup-steps 100 --weight-decay 0.1 --grad-clip 1.0 --seed 1337 --amp
}

run_one 0.65 s065
run_one 0.50 s050
run_one 0.40 s040
run_one 0.35 s035
run_one 0.30 s030
echo "== screen finished =="
