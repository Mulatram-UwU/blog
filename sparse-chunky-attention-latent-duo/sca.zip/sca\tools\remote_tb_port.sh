#!/usr/bin/env bash
cd /root/sca
PY="$(cat .python_path 2>/dev/null || echo /root/miniconda3/bin/python)"
pkill -f 'tensorboard.main' 2>/dev/null && echo "killed old tensorboard" || echo "no old tensorboard"
sleep 2
TB_LOG="result/logs/tensorboard.log"
: > "$TB_LOG"
nohup "$PY" -m tensorboard.main --logdir /root/sca/result/tensorboard --port 6007 --host 0.0.0.0 > "$TB_LOG" 2>&1 &
echo "TENSORBOARD pid=$! port=6007"
sleep 12
echo "### tb log"; tail -n 5 "$TB_LOG"
echo "### listening"; ( (ss -ltn 2>/dev/null || netstat -ltn 2>/dev/null) | grep -E '6007|6006' ) || echo "no 6006/6007 socket listed"
echo "### http probe"
curl -s -o /dev/null -w "127.0.0.1:6007 -> %{http_code}\n" http://127.0.0.1:6007/ || echo "curl failed"
curl -s -o /dev/null -w "127.0.0.1:6006 -> %{http_code}\n" http://127.0.0.1:6006/ || echo "6006 closed"
echo "### trainer still alive"; pgrep -af 'common.train' | sed 's/--data-path.*//' | head -2
