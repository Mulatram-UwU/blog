#!/usr/bin/env bash
# Push code_std higher: the trunk now trains properly, so the code distribution is
# far more concentrated than the initialisation-time calibration suggested and the
# densities all moved up.  Looking for the sparsest point that still converges.
set -u
cd /root/sca
PY=/root/miniconda3/bin/python
export PYTHONPATH=/root/sca

run_one () {
  local cs="$1"
  local tag="$2"
  echo "== screenC code_std=$cs =="
  "$PY" -m common.train --model sca_duo \
    --output-dir "result/screenc_$tag" \
    --tensorboard-dir "result/tensorboard/screenc_$tag" \
    --q-latent-dim 64 --sca-latent-dim 4 --chunk-size 0.5 --code-std "$cs" \
    --aux-mode rate --aux-beta 0.0 --indexer-lr-scale 0.1 --detach-indexer \
    --tokenizer-path /root/sca/data/bpe/tokenizer.json \
    --train-tokens /root/sca/data/bpe/train.pt \
    --valid-tokens /root/sca/data/bpe/val.pt \
    --device cuda --block-size 256 --batch-size 32 --steps 7755 --stop-at 2400 \
    --eval-every 100 --eval-tokens 262144 --save-every 100000 --keep-checkpoints 0 \
    --emb-dim 512 --n-heads 8 --n-layer 6 --mla-latent-dim 64 --dropout 0.1 \
    --lr 3e-4 --warmup-steps 100 --weight-decay 0.1 --grad-clip 1.0 --seed 1337 --amp
}

run_one 0.90 c090
run_one 1.20 c120
run_one 1.60 c160
run_one 2.20 c220
echo "== screenC finished =="
