#!/usr/bin/env bash
set -u
cd /root/sca
mkdir -p result/logs
LOG=result/logs/prepare_data.log
: > "$LOG"
nohup bash tools/prepare_data.sh > "$LOG" 2>&1 &
echo "PREPARE pid=$! log=/root/sca/$LOG"
