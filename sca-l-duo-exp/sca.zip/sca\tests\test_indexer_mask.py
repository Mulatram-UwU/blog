"""Regression tests for the SCA-L indexer routing mask.

Run either with pytest or directly:

    PYTHONPATH=. python tests/test_indexer_mask.py
"""

from __future__ import annotations

import torch

from sca_duo.indexer import SparseChunkyIndexer


def _causal(sequence: int) -> torch.Tensor:
    return torch.triu(torch.ones(sequence, sequence, dtype=torch.bool), diagonal=1)


def test_self_key_is_always_visible():
    """A disagreeing key projection must not route the token away from itself.

    This is the bug that produced NaN losses at step 146 of the chunk_size=0.5
    run: with q_index = +I and k_index = -I the query and its own key land in
    cells two apart on every axis, so the whole causal row was masked out.
    """

    torch.manual_seed(0)
    indexer = SparseChunkyIndexer(q_latent_dim=8, kv_latent_dim=8, latent_dim=4, chunk_size=0.5)
    with torch.no_grad():
        indexer.q_index.weight.copy_(torch.eye(4, 8))
        indexer.k_index.weight.copy_(-torch.eye(4, 8))
    c_q = torch.randn(2, 16, 8)
    c_kv = torch.randn(2, 16, 8)
    causal = _causal(16)
    z_q, z_k = indexer.encode(c_q, c_kv)
    candidate = indexer.candidate_mask(z_q, z_k, causal)

    counts = candidate.sum(dim=-1)
    assert int(counts.min()) >= 1, "empty candidate row -> softmax would be NaN"
    assert candidate.diagonal(dim1=-2, dim2=-1).all(), "the diagonal must stay visible"


def test_future_keys_stay_excluded():
    torch.manual_seed(1)
    indexer = SparseChunkyIndexer(q_latent_dim=8, kv_latent_dim=8, latent_dim=4, chunk_size=0.5)
    z_q = torch.randn(2, 24, 4) * 10.0
    z_k = torch.randn(2, 24, 4) * 10.0
    causal = _causal(24)
    candidate = indexer.candidate_mask(z_q, z_k, causal)

    assert not (candidate & causal).any(), "future keys must never be candidates"
    assert int(candidate.sum(dim=-1).min()) >= 1


def test_wide_latents_never_empty_a_row():
    torch.manual_seed(2)
    indexer = SparseChunkyIndexer(q_latent_dim=8, kv_latent_dim=8, latent_dim=4, chunk_size=0.5)
    for scale in (0.01, 1.0, 100.0):
        z_q = torch.randn(4, 32, 4) * scale
        z_k = torch.randn(4, 32, 4) * scale
        candidate = indexer.candidate_mask(z_q, z_k, _causal(32))
        assert int(candidate.sum(dim=-1).min()) >= 1, "empty row at scale %s" % scale


def main() -> int:
    test_self_key_is_always_visible()
    test_future_keys_stay_excluded()
    test_wide_latents_never_empty_a_row()
    print("all indexer mask tests passed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
