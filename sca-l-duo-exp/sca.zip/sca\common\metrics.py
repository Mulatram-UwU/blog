"""Raw per-step CSV metrics for one training run."""

from __future__ import annotations

import csv
from pathlib import Path

FIELDS = (
    "step",
    "epoch",
    "train_loss",
    "train_aux_loss",
    "val_loss",
    "val_accuracy",
    "val_aux_loss",
    "val_avg_candidates",
    "val_candidate_density",
    "val_routing_recall",
    "val_indexer_latent_norm",
    "val_density_ema",
    "val_density_gain",
    "learning_rate",
    "elapsed_seconds",
)


def _num(value) -> str:
    if value is None:
        return ""
    return repr(float(value))


class MetricsWriter:
    """Append one row per optimizer step; fill validation columns in place."""

    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.rows = []
        self._row_of_step = {}
        self._write_all()

    def _blank(self):
        return {field: "" for field in FIELDS}

    def _write_all(self):
        with self.path.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=FIELDS)
            writer.writeheader()
            writer.writerows(self.rows)

    def _append(self, row):
        with self.path.open("a", newline="", encoding="utf-8") as handle:
            csv.DictWriter(handle, fieldnames=FIELDS).writerow(row)

    def record_train(self, step, epoch, train_loss, train_aux_loss=None, learning_rate=None, elapsed_seconds=None):
        row = self._blank()
        row["step"] = str(step)
        row["epoch"] = str(epoch)
        row["train_loss"] = _num(train_loss)
        row["train_aux_loss"] = _num(train_aux_loss)
        row["learning_rate"] = _num(learning_rate)
        row["elapsed_seconds"] = _num(elapsed_seconds)
        index = self._row_of_step.get(step)
        if index is None:
            self._row_of_step[step] = len(self.rows)
            self.rows.append(row)
            self._append(row)
        else:
            self.rows[index] = row
            self._write_all()

    def record_eval(self, step, **values):
        index = self._row_of_step.get(step)
        if index is None:
            self._row_of_step[step] = len(self.rows)
            self.rows.append(self._blank())
            index = len(self.rows) - 1
        for key, value in values.items():
            if key not in FIELDS:
                raise KeyError("unknown metric column: " + key)
            self.rows[index][key] = _num(value)
        self._write_all()
