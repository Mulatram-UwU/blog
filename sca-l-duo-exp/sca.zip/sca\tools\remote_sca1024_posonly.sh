#!/usr/bin/env bash
# Window-only control, block 1024, density machinery off.
#
# The --pos-chunk run cut the sparse penalty from 5.60 to 2.56 accuracy points,
# but it did so by handing the indexer a hard window -- the mask is literally
# "content cells AND rel < 256", and the whole point of the exercise was that
# "the most recent C keys" is the optimal mask at density 0.5.  So the honest
# question is whether anything was learned at all, or whether the 3 points came
# purely from the prior.
#
# Substituting a pure window into the trained --pos-chunk checkpoint costs only
# 0.005 loss and 0.09 accuracy points (overlap 0.922), which says the content
# axis is worth about nothing -- but that substitution is out of distribution,
# so it is not proof.
#
# This run is the proof: --pos-only drops the content cells AND the density
# controller, so the mask is just "the last 2 * pos_chunk tokens".  Everything
# else is identical to sca1024_pos128 -- same seed, same 7755-step cosine, same
# block/batch -- so the two are matched by step and by batch order.
#
# One caveat to read off the result: a pure 256-token window keeps a larger
# share of the keys than content AND window does (window alone is about 43.7% of
# the visible keys, the indexer's mask about 37.5%), so if the window wins that
# is confounded by reading more.  The informative outcome is the other one:
# if the window does NOT beat 1.7861 despite reading more keys, the content axis
# is doing real work.
set -u
cd /root/sca
PY=/root/miniconda3/bin/python
export PYTHONPATH=/root/sca
TOTAL=7755
NAME=sca1024_posonly

train () {
  if grep -q "^${TOTAL}," "result/${NAME}/metrics.csv" 2>/dev/null; then
    echo "### skip ${NAME} (already complete)"; return 0
  fi
  echo "### train ${NAME} block=1024 batch=16 steps=${TOTAL} pos_chunk=128 pos_only"
  "$PY" -m common.train --model sca_duo \
    --output-dir "result/${NAME}" \
    --tensorboard-dir "result/tensorboard/${NAME}" \
    --q-latent-dim 64 --sca-latent-dim 4 --chunk-size 0.5 --code-std 0.30 \
    --target-density 0.50 --density-ctrl-rate 0.05 --pos-chunk 128 --pos-only \
    --aux-mode rate --aux-beta 0.0 --indexer-lr-scale 0.1 --detach-indexer \
    --tokenizer-path /root/sca/data/bpe/tokenizer.json \
    --train-tokens /root/sca/data/bpe/train.pt \
    --valid-tokens /root/sca/data/bpe/val.pt \
    --device cuda --block-size 1024 --batch-size 16 --steps "${TOTAL}" \
    --eval-every 50 --eval-tokens 262144 --save-every 500 --keep-checkpoints 3 \
    --emb-dim 512 --n-heads 8 --n-layer 6 --mla-latent-dim 64 --dropout 0.1 \
    --lr 3e-4 --warmup-steps 100 --weight-decay 0.1 --grad-clip 1.0 --seed 1337 --amp
  echo "### train ${NAME} exit=$?"
}

ablate () {
  [ -f "result/${NAME}/last.pt" ] || { echo "### ablation SKIPPED (no checkpoint)"; return 0; }
  for mode in indexer local random; do
    echo "### ablation ${mode}"
    "$PY" tools/eval_mask_ablation.py --mode "${mode}" \
      --checkpoint "result/${NAME}/last.pt" --valid-tokens data/bpe/val.pt 2>&1 \
      | grep -v -e FutureWarning -e weights_only -e recommend -e torch.load
  done
}

train
ablate
echo "### sca1024_posonly done"
