#!/usr/bin/env bash
# Full-epoch density frontier, resumable: a run that already logged a complete
# epoch is skipped, so a relaunch after a network blip continues instead of redoing
# everything.  The proxy has been dropping connections all night.
set -u
cd /root/sca
PY=/root/miniconda3/bin/python
export PYTHONPATH=/root/sca
TOTAL=7755

run_one () {
  local d="$1"
  local tag="$2"
  local dir="result/dens_$tag"
  if [ -f "$dir/metrics.csv" ]; then
    local rows
    rows=$(grep -c . "$dir/metrics.csv")
    if [ "$rows" -ge $((TOTAL + 1)) ]; then
      echo "== skip $tag: already complete ($rows rows) =="
      return 0
    fi
    echo "== resuming $tag: $rows rows so far =="
  fi
  echo "== full epoch target_density=$d =="
  "$PY" -m common.train --model sca_duo \
    --output-dir "$dir" \
    --tensorboard-dir "result/tensorboard/dens_$tag" \
    --q-latent-dim 64 --sca-latent-dim 4 --chunk-size 0.5 --code-std 0.30 \
    --target-density "$d" --density-ctrl-rate 0.05 \
    --aux-mode rate --aux-beta 0.0 --indexer-lr-scale 0.1 --detach-indexer \
    --tokenizer-path /root/sca/data/bpe/tokenizer.json \
    --train-tokens /root/sca/data/bpe/train.pt \
    --valid-tokens /root/sca/data/bpe/val.pt \
    --device cuda --block-size 256 --batch-size 32 --steps $TOTAL \
    --eval-every 50 --eval-tokens 262144 --save-every 50 --keep-checkpoints 2 \
    --emb-dim 512 --n-heads 8 --n-layer 6 --mla-latent-dim 64 --dropout 0.1 \
    --lr 3e-4 --warmup-steps 100 --weight-decay 0.1 --grad-clip 1.0 --seed 1337 --amp
}

run_one 0.10 t010
run_one 0.20 t020
run_one 0.35 t035
run_one 0.50 t050
run_one 0.70 t070
run_one 0.90 t090
echo "== density frontier finished =="
