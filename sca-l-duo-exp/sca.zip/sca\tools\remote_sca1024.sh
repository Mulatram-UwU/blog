#!/usr/bin/env bash
# Block-1024 SCA-L Duo -- the long-context run.
#
# Stage 1/2 settled the length question twice over.
#
#   Dense, matched tokens (63.5M):  block 256 -> 1.9546, block 1024 -> 1.6003... no:
#     block 256 1.6003 / 59.39%   block 1024 @3878 1.9546 / 53.94%   gap 0.354
#     block 256 1.6003            block 1024 @7755 1.6641 / 58.76%   gap 0.064
#   So 82% of the original deficit was undertraining, and the residual price of
#   1024 is 0.064 val loss.  (The 7755-step run also ate 2x the tokens.)
#
#   Oracle ceiling (top-C attention mass of the dense model):
#     absolute mass is *lower* at 1024 at every budget -- 0.9445 vs 0.9840 at C=128.
#     But per unit of candidate *share* it is much *higher*:
#       share ~6.2%  block 256 C=8  net 0.558   block 1024 C=32  net 0.764
#       share ~12.5% block 256 C=16 net 0.691   block 1024 C=64  net 0.861
#       share ~25%   block 256 C=32 net 0.796   block 1024 C=128 net 0.926
#     Reason is corpus shape: TinyStories is concatenated ~250-token stories, so a
#     256 window is about one story and holds almost nothing a router may throw
#     away, while a 1024 window straddles four and half its keys are provably
#     irrelevant.  Long context manufactures the irrelevance a router exploits.
#
# So the ceiling is higher at 1024.  The open question is whether the indexer can
# climb it.  At block 256 (t050, density 0.498) it recovers 17.5% against an 86.7%
# ceiling -- a 5x gap.  This run separates ceiling-limited from indexer-limited:
# same architecture, same schedule, same seed, same target density as t050, only
# the block size moved.
#
# Oracle budgets are extended first: they cost ~2 minutes and are needed to read
# the result, because t050's share of 0.498 becomes C=256 at block 1024 and
# stage 1/2 stopped measuring at 128.
#
# Live curves: result/tensorboard/sca1024_d050 -> /root/tf-logs -> board on 6007.
set -u
cd /root/sca
PY=/root/miniconda3/bin/python
export PYTHONPATH=/root/sca
TOTAL=7755
NAME=sca1024_d050

# --- 1. extend the block-1024 oracle frontier to the density t050 actually ran at
extend_oracle () {
  local ckpt="result/base1024b/last.pt"
  [ -f "$ckpt" ] || { echo "### oracle-ext SKIPPED (no $ckpt)"; return 0; }
  if [ -f result/base1024b/oracle_ext.csv ]; then
    echo "### oracle-ext already present, skipping"
    return 0
  fi
  echo "### oracle-ext base1024b budgets 160,192,224,256"
  "$PY" tools/measure_oracle.py \
    --checkpoint "$ckpt" --valid-tokens data/bpe/val.pt \
    --budgets 160,192,224,256 --batch-size 8 --device cuda \
    --out result/base1024b/oracle_ext.csv
  echo "### oracle-ext exit=$?"
}

# --- 2. the run itself
train () {
  if grep -q "^${TOTAL}," "result/${NAME}/metrics.csv" 2>/dev/null; then
    echo "### skip ${NAME} (already reached step ${TOTAL})"
    return 0
  fi
  echo "### train ${NAME} block=1024 batch=16 steps=${TOTAL} target_density=0.50"
  "$PY" -m common.train --model sca_duo \
    --output-dir "result/${NAME}" \
    --tensorboard-dir "result/tensorboard/${NAME}" \
    --q-latent-dim 64 --sca-latent-dim 4 --chunk-size 0.5 --code-std 0.30 \
    --target-density 0.50 --density-ctrl-rate 0.05 \
    --aux-mode rate --aux-beta 0.0 --indexer-lr-scale 0.1 --detach-indexer \
    --tokenizer-path /root/sca/data/bpe/tokenizer.json \
    --train-tokens /root/sca/data/bpe/train.pt \
    --valid-tokens /root/sca/data/bpe/val.pt \
    --device cuda --block-size 1024 --batch-size 16 --steps "${TOTAL}" \
    --eval-every 50 --eval-tokens 262144 --save-every 500 --keep-checkpoints 3 \
    --emb-dim 512 --n-heads 8 --n-layer 6 --mla-latent-dim 64 --dropout 0.1 \
    --lr 3e-4 --warmup-steps 100 --weight-decay 0.1 --grad-clip 1.0 --seed 1337 --amp
  echo "### train ${NAME} exit=$?"
}

extend_oracle
train
echo "### sca1024 done"
