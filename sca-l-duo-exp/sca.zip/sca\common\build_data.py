"""Train a byte-level BPE tokenizer and cache the corpus as token tensors.

    python -m common.build_data --text slice.txt --out-dir data/bpe

Writes tokenizer.json, train.pt and val.pt.  The validation split is the tail of
the slice, so the two halves never overlap.
"""

from __future__ import annotations

import argparse
from pathlib import Path

from .bpe import encode_text, save_tokens, train_byte_bpe


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--text", required=True, help="raw UTF-8 corpus slice")
    parser.add_argument("--out-dir", required=True)
    parser.add_argument("--vocab-size", type=int, default=8192)
    parser.add_argument("--valid-bytes", type=int, default=4_000_000)
    parser.add_argument("--tokenizer-bytes", type=int, default=50_000_000)
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args()

    out = Path(args.out_dir)
    out.mkdir(parents=True, exist_ok=True)
    if (out / "train.pt").exists() and not args.overwrite:
        print("already built: %s" % out)
        return

    text = Path(args.text).read_text(encoding="utf-8", errors="ignore")
    split_at = max(1, len(text) - args.valid_bytes)
    train_text, valid_text = text[:split_at], text[split_at:]
    print("chars: train=%d valid=%d" % (len(train_text), len(valid_text)), flush=True)

    sample = out / "tokenizer_sample.txt"
    sample.write_text(train_text[:args.tokenizer_bytes], encoding="utf-8")
    tokenizer = train_byte_bpe([sample], args.vocab_size, out / "tokenizer.json")
    print("vocab=%d" % tokenizer.get_vocab_size(), flush=True)

    train_ids = encode_text(tokenizer, train_text)
    print("train tokens=%d" % len(train_ids), flush=True)
    valid_ids = encode_text(tokenizer, valid_text)
    print("valid tokens=%d" % len(valid_ids), flush=True)

    save_tokens(train_ids, out / "train.pt")
    save_tokens(valid_ids, out / "val.pt")
    print("built %s" % out, flush=True)


if __name__ == "__main__":
    main()
