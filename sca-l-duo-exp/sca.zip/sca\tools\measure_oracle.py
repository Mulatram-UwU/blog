#!/usr/bin/env python3
"""Measure the oracle routing frontier of a trained checkpoint.

An indexer can never beat the best possible fixed-budget router, and that ceiling
is a property of the dense attention alone: rank each query's visible keys by
attention weight and add up the top C.  Printing that curve next to the indexer's
own recall separates "the router is weak" from "the context has nothing worth
selecting" -- a distinction a density sweep cannot make, because a density target
is length invariant by construction and the candidate count just grows with the
context.

Runs on any checkpoint written by common.train, baseline or sca_duo.  The dense
logits are captured by wrapping masked_scores, so no model code changes.

    PYTHONPATH=. python tools/measure_oracle.py --checkpoint result/b1024/best.pt \
        --valid-tokens data/bpe/val.pt --budgets 8,16,32,64,128 --batch-size 8 \
        --out result/oracle/b1024.csv
"""

from __future__ import annotations

import argparse
import csv
import types
from pathlib import Path

import torch
from torch import Tensor
from torch.nn import functional as F

from baseline.model import BaselineModel
from common.data import iter_batches, load_token_tensor
from sca_duo.model import SCADuoModel


def build_model(config) -> torch.nn.Module:
    common = dict(vocab_size=config["vocab_size"], block_size=config["block_size"],
                  emb_dim=config["emb_dim"], n_heads=config["n_heads"],
                  n_layer=config["n_layer"], dropout=config.get("dropout", 0.0),
                  q_latent_dim=config["q_latent_dim"], kv_latent_dim=config["kv_latent_dim"])
    if config["model"] == "baseline":
        return BaselineModel(**common)
    return SCADuoModel(**common, latent_dim=config["sca_latent_dim"],
                       chunk_size=config["chunk_size"],
                       detach_indexer=config.get("detach_indexer", True),
                       aux_mode=config.get("aux_mode", "kl"),
                       aux_beta=config.get("aux_beta", 1.0),
                       ste_mask=config.get("ste_mask", False),
                       code_std=config.get("code_std", 0.0),
                       target_density=config.get("target_density", 0.0),
                       target_candidates=config.get("target_candidates", 0.0),
                       density_ctrl_rate=0.0,
                       pos_chunk=config.get("pos_chunk", 0.0))


class Frontier:
    """Accumulate the top-C attention mass over a validation pass."""

    def __init__(self, budgets, row_chunk=2):
        self.budgets = list(budgets)
        self.widest = max(self.budgets)
        self.row_chunk = row_chunk
        self.mass = {budget: 0.0 for budget in self.budgets}
        self.queries = {budget: 0 for budget in self.budgets}
        self.causal = None
        self.visible = None

    def __call__(self, scores: Tensor):
        sequence = scores.shape[-1]
        if self.causal is None or self.causal.shape[0] != sequence:
            # True marks FUTURE positions, matching MLAAttention.causal_mask.
            self.causal = torch.triu(torch.ones(sequence, sequence, dtype=torch.bool,
                                                device=scores.device), diagonal=1)
            self.visible = torch.arange(1, sequence + 1, device=scores.device)
        width = min(self.widest, sequence)
        with torch.no_grad():
            for start in range(0, scores.shape[0], self.row_chunk):
                piece = scores[start:start + self.row_chunk].float()
                # Head-average first: the indexer routes once per token, not once per
                # head, and routing_recall is measured on the same head-averaged teacher.
                weights = F.softmax(piece, dim=-1).mean(dim=1)
                weights = weights.masked_fill(self.causal, 0.0)
                ranked = weights.topk(width, dim=-1).values.cumsum(dim=-1)
                for budget in self.budgets:
                    column = min(budget, width) - 1
                    seen = self.visible >= budget
                    # Count ROWS, not queries: the sum below runs over every row of
                    # the chunk, so dividing by the query count alone inflated the
                    # whole frontier by the chunk size.
                    selected = ranked[..., column][:, seen]
                    self.mass[budget] += float(selected.sum())
                    self.queries[budget] += int(selected.numel())

    def rows(self):
        out = []
        for budget in self.budgets:
            count = max(1, self.queries[budget])
            out.append({"budget": budget, "oracle_recall": self.mass[budget] / count,
                        "queries": self.queries[budget]})
        return out


def wrap(module):
    original = type(module).masked_scores

    def wrapped(self, q, k, candidate=None):
        scores = original(self, q, k, candidate)
        if candidate is None and not self.training:
            self._oracle_sink(scores)
        return scores

    module.masked_scores = types.MethodType(wrapped, module)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--valid-tokens", required=True)
    parser.add_argument("--budgets", default="8,16,32,64,128")
    parser.add_argument("--batch-size", type=int, default=8)
    parser.add_argument("--max-batches", type=int, default=0)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--out", default=None)
    args = parser.parse_args()

    budgets = sorted({int(item) for item in args.budgets.split(",") if item.strip()})
    if not budgets or budgets[0] < 1:
        raise SystemExit("--budgets must be positive integers")

    device = torch.device(args.device)
    payload = torch.load(args.checkpoint, map_location="cpu", weights_only=False)
    config = payload["config"]
    model = build_model(config)
    model.load_state_dict(payload["model"])
    model = model.to(device).eval()

    sink = Frontier(budgets)
    for block in model.blocks:
        block.attention._oracle_sink = sink
        wrap(block.attention)

    tokens = load_token_tensor(args.valid_tokens)
    batches = 0
    with torch.no_grad():
        for batch_tokens, batch_targets in iter_batches(tokens, config["block_size"],
                                                        args.batch_size, device):
            model(batch_tokens, batch_targets)
            batches += 1
            if args.max_batches and batches >= args.max_batches:
                break

    rows = sink.rows()
    print("checkpoint=%s model=%s step=%s block=%s batches=%d"
          % (args.checkpoint, config["model"], payload.get("step"), config["block_size"], batches))
    print("%8s %14s %10s" % ("budget", "oracle_recall", "queries"))
    for row in rows:
        print("%8d %14.4f %10d" % (row["budget"], row["oracle_recall"], row["queries"]))

    if args.out:
        path = Path(args.out)
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=("budget", "oracle_recall", "queries"))
            writer.writeheader()
            writer.writerows(rows)
        print("wrote %s" % path)


if __name__ == "__main__":
    main()
