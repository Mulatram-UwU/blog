"""Character-level Tiny Shakespeare loading and language-model batching."""

from __future__ import annotations

from pathlib import Path
from urllib.request import urlopen

import torch
from torch import Tensor

DATA_URL = "https://raw.githubusercontent.com/karpathy/char-rnn/master/data/tinyshakespeare/input.txt"


def load_tiny_shakespeare(data_path, download_url: str = DATA_URL):
    """Download once and return a deterministic 90/10 character-level split."""

    path = Path(data_path)
    if not path.exists():
        path.parent.mkdir(parents=True, exist_ok=True)
        with urlopen(download_url) as response:
            text = response.read().decode("utf-8")
        path.write_text(text, encoding="utf-8")
    else:
        text = path.read_text(encoding="utf-8")
    if not text:
        raise ValueError("dataset is empty: " + str(path))

    characters = sorted(set(text))
    stoi = {character: index for index, character in enumerate(characters)}
    encoded = torch.tensor([stoi[character] for character in text], dtype=torch.long)
    split_at = int(0.9 * len(encoded))
    if split_at == 0 or split_at == len(encoded):
        raise ValueError("dataset is too small for a train/validation split")
    return encoded[:split_at], encoded[split_at:], stoi, characters


def load_token_tensor(path) -> Tensor:
    """Load a cached int32 token tensor produced by common.build_data."""

    tokens = torch.load(path, map_location="cpu")
    if not isinstance(tokens, Tensor) or tokens.ndim != 1:
        raise ValueError("cached token file must hold a one-dimensional tensor: " + str(path))
    return tokens


def get_batch(data: Tensor, block_size: int, batch_size: int, device, generator=None):
    if data.ndim != 1:
        raise ValueError("data must be a one-dimensional token tensor")
    if block_size <= 0 or batch_size <= 0:
        raise ValueError("block_size and batch_size must be positive")
    if len(data) <= block_size + 1:
        raise ValueError("dataset must contain more than block_size + 1 tokens")
    starts = torch.randint(len(data) - block_size - 1, (batch_size,), device=data.device, generator=generator)
    offsets = torch.arange(block_size, device=data.device)
    positions = starts[:, None] + offsets[None, :]
    return data[positions].to(device).long(), data[positions + 1].to(device).long()


def iter_batches(data: Tensor, block_size: int, batch_size: int, device):
    """Yield deterministic, non-overlapping validation batches."""

    if data.ndim != 1:
        raise ValueError("data must be a one-dimensional token tensor")
    if block_size <= 0 or batch_size <= 0:
        raise ValueError("block_size and batch_size must be positive")
    if len(data) <= block_size + 1:
        raise ValueError("dataset must contain more than block_size + 1 tokens")
    offsets = torch.arange(block_size, device=data.device)
    max_start = len(data) - block_size - 1
    # Advance by a whole batch of non-overlapping windows, not by batch_size.
    for start in range(0, max_start + 1, batch_size * block_size):
        starts = torch.arange(start, min(start + batch_size, max_start + 1), device=data.device)
        positions = starts[:, None] + offsets[None, :]
        yield data[positions].to(device).long(), data[positions + 1].to(device).long()
