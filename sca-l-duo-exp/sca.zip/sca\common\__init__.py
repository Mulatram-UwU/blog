"""Shared data, metrics, training and plotting utilities."""
