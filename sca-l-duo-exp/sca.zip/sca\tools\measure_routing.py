#!/usr/bin/env python3
"""Measure the SCA-L routing partition.

tanh now bounds the code to [-1, 1] ** latent_dim, so chunk_size fixes the number
of cells (the 'expert count') and the density should sit near 81 / that count as
long as the codes fill the box.  This prints the static partition per chunk size,
then optionally follows it during training.

    PYTHONPATH=. python tools/measure_routing.py --steps 600
"""

from __future__ import annotations

import argparse

import torch

from common.data import get_batch, iter_batches, load_token_tensor
from sca_duo.model import SCADuoModel

BLOCK, BATCH, EVAL_TOKENS = 256, 32, 262144
CHUNKS = (0.2, 0.25, 0.35, 0.5, 0.7, 1.0, 2.0)


def build(chunk_size, device, dropout=0.0, aux_mode="kl"):
    return SCADuoModel(vocab_size=8192, block_size=BLOCK, emb_dim=512, n_heads=8, n_layer=6,
                       dropout=dropout, q_latent_dim=64, kv_latent_dim=64, latent_dim=4,
                       chunk_size=chunk_size, detach_indexer=True, aux_mode=aux_mode).to(device)


def probe(model, tokens, targets):
    _, _, metrics = model(tokens, targets)
    indexer = model.blocks[0].attention.indexer
    hidden = model.blocks[0].ln1(model.embed(tokens))
    z_q, z_k = indexer.encode(model.blocks[0].attention.q_down(hidden),
                              model.blocks[0].attention.kv_down(hidden))
    occupied = torch.unique(indexer.chunk_coordinates(z_k).reshape(-1, indexer.latent_dim), dim=0)
    return {
        "occupied": int(occupied.shape[0]),
        "fixed": indexer.cell_count(),
        "avg_cand": float(metrics["avg_candidates"]),
        "density": float(metrics["candidate_density"]),
        "recall": float(metrics["routing_recall"]),
        "latent_norm": float(metrics["indexer_latent_norm"]),
        "code_std": float(indexer.cell_coordinates(z_k).std()),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--steps", type=int, default=0, help="also train chunk_size 0.5 this long")
    parser.add_argument("--dynamic-chunk", type=float, default=0.5)
    parser.add_argument("--indexer-lr-scale", type=float, default=0.1)
    parser.add_argument("--train-tokens", default="data/bpe/train.pt")
    parser.add_argument("--valid-tokens", default="data/bpe/val.pt")
    args = parser.parse_args()

    torch.manual_seed(1337)
    device = torch.device("cuda")
    valid = load_token_tensor(args.valid_tokens).to(device)

    print("=== static partition at initialisation (dropout off) ===")
    print("%8s %9s %9s %10s %9s %9s %9s %10s" % (
        "chunk", "cells(C)", "occupied", "81/C", "avg_cand", "density", "recall", "code_std"))
    for chunk_size in CHUNKS:
        model = build(chunk_size, device).eval()
        tokens, targets = get_batch(valid, BLOCK, BATCH, device,
                                    torch.Generator(device=device).manual_seed(7))
        with torch.no_grad():
            row = probe(model, tokens, targets)
        print("%8.2f %9d %9d %10.3f %9.2f %9.4f %9.4f %10.4f" % (
            chunk_size, row["fixed"], row["occupied"], 81.0 / max(1, row["fixed"]),
            row["avg_cand"], row["density"], row["recall"], row["code_std"]))

    if args.steps <= 0:
        return

    print()
    print("=== training chunk_size=%g for %d steps (kl aux, indexer lr x%g) ===" % (
        args.dynamic_chunk, args.steps, args.indexer_lr_scale))
    train = load_token_tensor(args.train_tokens).to(device)
    tokens, targets = get_batch(valid, BLOCK, BATCH, device,
                                torch.Generator(device=device).manual_seed(7))
    model = build(args.dynamic_chunk, device, dropout=0.1).train()
    named = [(n, p) for n, p in model.named_parameters() if ".indexer." in n]
    ids = {id(p) for _, p in named}
    optimizer = torch.optim.AdamW(
        [{"params": [p for p in model.parameters() if id(p) not in ids], "lr": 3e-4, "lr_scale": 1.0},
         {"params": [p for _, p in named], "lr": 3e-4 * args.indexer_lr_scale,
          "lr_scale": args.indexer_lr_scale}], lr=3e-4, weight_decay=0.1)
    scaler = torch.amp.GradScaler("cuda", enabled=True)
    generator = torch.Generator(device=device).manual_seed(1337)
    total_loss = 0.0
    print("%8s %11s %10s %9s %9s %9s %9s" % (
        "step", "train_loss", "occupied", "avg_cand", "density", "recall", "code_std"))
    for step in range(1, args.steps + 1):
        lr = 3e-4 * min(float(step) / 100.0, 1.0)
        for group in optimizer.param_groups:
            group["lr"] = lr * group.get("lr_scale", 1.0)
        batch_tokens, batch_targets = get_batch(train, BLOCK, BATCH, device, generator)
        optimizer.zero_grad(set_to_none=True)
        with torch.autocast(device_type="cuda", dtype=torch.float16, enabled=True):
            _, loss, metrics = model(batch_tokens, batch_targets)
            total = loss + metrics["aux_loss"]
        scaler.scale(total).backward()
        scaler.unscale_(optimizer)
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        scaler.step(optimizer)
        scaler.update()
        total_loss = float(loss.detach().float())
        if step % 50 == 0 or step == 1:
            model.eval()
            with torch.no_grad():
                row = probe(model, tokens, targets)
            model.train()
            print("%8d %11.4f %10d %9.2f %9.4f %9.4f %9.4f" % (
                step, total_loss, row["occupied"], row["avg_cand"], row["density"],
                row["recall"], row["code_std"]))


if __name__ == "__main__":
    main()
