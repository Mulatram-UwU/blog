#!/usr/bin/env bash
# Tiny smoke run: checks shapes, causality, routing, aux loss, CSV and checkpoints.
set -euo pipefail
cd "$(dirname "$0")/.."
export PYTHONPATH="$PWD${PYTHONPATH:+:$PYTHONPATH}"

PYTHON_BIN="${PYTHON_BIN:-python}"
OUT="${OUT:-result/smoke}"
STEPS="${STEPS:-20}"
BLOCK="${BLOCK:-64}"
DEVICE="${DEVICE:-cpu}"

extra=()
if [[ "$DEVICE" == "cpu" ]]; then
  extra+=(--allow-cpu)
else
  extra+=(--amp)
fi

run_one() {
  local model="$1"; shift
  "$PYTHON_BIN" -m common.train --model "$model" --device "$DEVICE" \
    --output-dir "$OUT/$model" --block-size "$BLOCK" --batch-size 8 \
    --steps "$STEPS" --eval-every 10 --save-every 10 --log-every 5 \
    --emb-dim 64 --n-heads 4 --n-layer 2 --mla-latent-dim 16 --q-latent-dim 16 \
    --dropout 0.0 "${extra[@]}" "$@"
}

run_one baseline
run_one sca_duo --sca-latent-dim 4 --chunk-size 1.0 --aux-weight 1.0

echo "smoke run finished -> $OUT"
