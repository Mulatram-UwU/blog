"""Indexer-free MLA baseline."""
