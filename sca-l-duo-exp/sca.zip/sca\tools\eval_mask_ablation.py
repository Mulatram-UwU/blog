#!/usr/bin/env python3
"""Ablate the candidate *choice* while holding the candidate *count* fixed.

The indexer is the only part of SCA-L that decides which keys a query may read.
To price its mistakes, keep every query's budget exactly as the indexer set it --
its own per-query candidate count -- and change only which keys fill that budget:

    indexer     the trained router (sanity: must reproduce the logged val_loss)
    oracle      top-C of the model's own dense attention, head averaged
    random      C keys drawn uniformly from the visible ones -- zero routing skill
    local       the most recent C keys -- free structure, the baseline the
                learned router must beat to justify its cost
    sink_local  key 0 plus the most recent C-1 keys

Dense attention is the fourth point, budget = every key.  That four point line
says how much of the sparse/dense loss gap is selection error and how much is
simply the price of reading fewer keys.

Caveat this tool cannot remove: the oracle ranks by the *sparse model's own*
dense attention -- the same self-referential teacher that routing_recall uses.  So
it cross-checks the reported mask overlap.  If the oracle and indexer masks are
nearly identical, the model has collapsed its attention onto what it can already
read and the oracle column is not an independent ceiling.

    PYTHONPATH=. python tools/eval_mask_ablation.py --mode oracle \
        --checkpoint result/sca1024_d050/last.pt --valid-tokens data/bpe/val.pt
"""

from __future__ import annotations

import argparse
import types
from types import SimpleNamespace

import torch
from torch.nn import functional as F

from common.data import load_token_tensor
from common.train import evaluate
from baseline.model import BaselineModel
from sca_duo.model import SCADuoModel


def build_model(config) -> torch.nn.Module:
    common = dict(vocab_size=config["vocab_size"], block_size=config["block_size"],
                  emb_dim=config["emb_dim"], n_heads=config["n_heads"],
                  n_layer=config["n_layer"], dropout=config.get("dropout", 0.0),
                  q_latent_dim=config["q_latent_dim"], kv_latent_dim=config["kv_latent_dim"])
    if config["model"] == "baseline":
        return BaselineModel(**common)
    return SCADuoModel(**common, latent_dim=config["sca_latent_dim"],
                       chunk_size=config["chunk_size"],
                       detach_indexer=config.get("detach_indexer", True),
                       aux_mode=config.get("aux_mode", "kl"),
                       aux_beta=config.get("aux_beta", 1.0),
                       ste_mask=config.get("ste_mask", False),
                       code_std=config.get("code_std", 0.0),
                       target_density=config.get("target_density", 0.0),
                       target_candidates=config.get("target_candidates", 0.0),
                       density_ctrl_rate=0.0,
                       pos_chunk=config.get("pos_chunk", 0.0),
                       pos_only=config.get("pos_only", False))


class Sink:
    """Mask bookkeeping: overlap with the indexer's set and the real density."""

    def __init__(self):
        self.inter = 0.0
        self.indexer_total = 0.0
        self.sub_total = 0.0
        self.visible_total = 0.0
        self.calls = 0

    def report(self) -> dict:
        return {
            "mask_overlap_with_indexer": self.inter / max(1.0, self.indexer_total),
            # Ratio of totals, not the model's mean-of-per-query-ratios.  The two
            # differ because early queries see almost no history and the indexer
            # still fills them; this one is only used to show that the substituted
            # budgets really are the indexer's.
            "substituted_density_totalratio": self.sub_total / max(1.0, self.visible_total),
            "calls": self.calls,
        }


def install(module, mode: str, sink: Sink, generator) -> None:
    original = type(module).masked_scores

    def wrapped(self, q, k, candidate=None):
        if self.training or candidate is None:
            scores = original(self, q, k, candidate)
            if (not self.training) and candidate is None:
                # This is the teacher call inside SCADuoAttention.forward.
                self._ablation_teacher = F.softmax(scores.float(), dim=-1).mean(dim=1)
            return scores

        counts = candidate.sum(dim=-1)                          # [B, T]
        sequence = candidate.shape[-1]
        if mode == "indexer":
            chosen = candidate
        elif mode in ("local", "sink_local"):
            # Sliding window: the most recent counts[b, i] keys.  Zero training,
            # zero indexer -- the structural baseline the learned router has to
            # beat to justify its existence.  sink_local additionally pins key 0,
            # which is the standard StreamingLLM recipe when the window cannot
            # reach the start of the sequence.
            index = torch.arange(sequence, device=candidate.device)
            delta = index.view(1, -1, 1) - index.view(1, 1, -1)  # i - j
            width = counts.unsqueeze(-1) - (1 if mode == "sink_local" else 0)
            chosen = (delta >= 0) & (delta < width.clamp_min(0))
            if mode == "sink_local":
                chosen |= (index.view(1, 1, -1) == 0)
        else:
            teacher = self._ablation_teacher
            diagonal = torch.eye(sequence, dtype=torch.bool, device=candidate.device).unsqueeze(0)
            if mode == "oracle":
                ranked = teacher.topk(int(counts.max().item()), dim=-1).indices
            elif mode == "random":
                noise = torch.rand(candidate.shape, generator=generator, device=candidate.device)
                noise = noise.masked_fill(self.causal(sequence, candidate.device).unsqueeze(0),
                                          float("-inf"))
                ranked = noise.topk(int(counts.max().item()), dim=-1).indices
            else:
                raise ValueError(mode)
            chosen = torch.zeros_like(candidate)
            # Keep only the first counts[b, i] entries of each ranked row.  The
            # keep mask is [B, T, kmax] and must be scattered in, not AND-ed
            # against the [B, T, T] mask, because kmax is the *widest* budget in
            # the batch and the two shapes do not line up otherwise.
            ranks = torch.arange(ranked.shape[-1], device=candidate.device).view(1, 1, -1)
            keep = ranks < counts.unsqueeze(-1)
            chosen.scatter_(-1, ranked, keep)
            chosen |= diagonal

        sink.inter += float((chosen & candidate).sum())
        sink.indexer_total += float(candidate.sum())
        sink.sub_total += float(chosen.sum())
        sink.visible_total += float(sum(range(1, candidate.shape[-1] + 1))
                                    * candidate.shape[0])
        sink.calls += 1
        self._ablation_teacher = None
        return original(self, q, k, chosen)

    module.masked_scores = types.MethodType(wrapped, module)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--valid-tokens", required=True)
    parser.add_argument("--mode",
                        choices=("indexer", "oracle", "random", "local", "sink_local"),
                        required=True)
    parser.add_argument("--eval-tokens", type=int, default=262144)
    parser.add_argument("--batch-size", type=int, default=16)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--seed", type=int, default=1234)
    args = parser.parse_args()

    device = torch.device(args.device)
    payload = torch.load(args.checkpoint, map_location="cpu", weights_only=False)
    config = payload["config"]
    model = build_model(config)
    model.load_state_dict(payload["model"])
    model = model.to(device).eval()

    sink = Sink()
    generator = torch.Generator(device=device).manual_seed(args.seed)
    if config["model"] != "sca_duo":
        raise SystemExit("mask ablation only applies to sca_duo")
    for block in model.blocks:
        install(block.attention, args.mode, sink, generator)

    tokens = load_token_tensor(args.valid_tokens)
    eval_args = SimpleNamespace(eval_tokens=args.eval_tokens, block_size=config["block_size"],
                                batch_size=args.batch_size)
    result = evaluate(model, tokens, eval_args, device, True)

    print("checkpoint=%s mode=%s step=%s block=%s"
          % (args.checkpoint, args.mode, payload.get("step"), config["block_size"]))
    print("  val_loss=%.4f val_accuracy=%.4f" % (result["val_loss"], result["val_accuracy"]))
    for key in ("val_candidate_density", "val_routing_recall", "val_avg_candidates"):
        if key in result:
            print("  %s=%.4f" % (key, result[key]))
    for key, value in sink.report().items():
        print("  %s=%.4f" % (key, value))


if __name__ == "__main__":
    main()
