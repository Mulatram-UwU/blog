#!/usr/bin/env python3
"""Plot the sparsity frontier: what the modelling loss costs at each retention level.

Each point is one full-epoch run, summarised by the mean of its last ten evals.
The dense baseline is drawn as a horizontal reference line.

    PYTHONPATH=. python tools/plot_frontier.py --run "0.12=result/dens_t010/metrics.csv" ...
"""

from __future__ import annotations

import argparse
import csv
import statistics
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

TAIL = 10


def settle(path):
    rows = []
    with Path(path).open(newline="", encoding="utf-8") as handle:
        for row in csv.DictReader(handle):
            if not row.get("val_loss"):
                continue
            rows.append(row)
    if not rows:
        return None
    tail = rows[-TAIL:]

    def mean(key):
        vals = []
        for row in tail:
            raw = row.get(key, "")
            try:
                vals.append(float(raw))
            except (TypeError, ValueError):
                pass
        return statistics.mean(vals) if vals else float("nan")

    return {
        "loss": mean("val_loss"),
        "acc": mean("val_accuracy"),
        "density": mean("val_candidate_density"),
        "cand": mean("val_avg_candidates"),
        "recall": mean("val_routing_recall"),
        "steps": int(rows[-1]["step"]),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run", action="append", required=True, help="LABEL=path")
    parser.add_argument("--baseline", default=None, help="path to the dense baseline metrics")
    parser.add_argument("--output-dir", default="result/plots")
    args = parser.parse_args()

    points = []
    for spec in args.run:
        label, _, path = spec.partition("=")
        row = settle(path)
        if row is None:
            continue
        points.append((label, row))
    points.sort(key=lambda item: item[1]["density"])

    base = settle(args.baseline) if args.baseline else None
    out = Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)

    dens = [r["density"] for _, r in points]
    cand = [r["cand"] for _, r in points]
    loss = [r["loss"] for _, r in points]
    rec = [r["recall"] for _, r in points]

    fig, axes = plt.subplots(1, 3, figsize=(16.5, 4.6))

    def decorate(ax, xlabel):
        if base:
            ax.axhline(base["loss"], color="crimson", ls="--", lw=1.2,
                       label="dense MLA baseline (%.4f)" % base["loss"])
        ax.set_xlabel(xlabel)
        ax.set_ylabel("validation loss (last %d evals)" % TAIL)
        ax.grid(alpha=0.25)
        ax.legend(fontsize=8)

    decorate(axes[0], "candidate density (fraction of visible keys kept)")
    axes[0].plot(dens, loss, "o-", color="#1f77b4")
    for label, r in points:
        axes[0].annotate(label, (r["density"], r["loss"]), textcoords="offset points",
                         xytext=(4, 5), fontsize=7)
    axes[0].set_title("loss vs retained context")

    decorate(axes[1], "average candidate keys per query")
    axes[1].plot(cand, loss, "o-", color="#2ca02c")
    for label, r in points:
        axes[1].annotate(label, (r["cand"], r["loss"]), textcoords="offset points",
                         xytext=(4, 5), fontsize=7)
    axes[1].set_title("loss vs candidate count")

    axes[2].plot(dens, rec, "o-", color="#ff7f0e", label="retained attention mass (recall)")
    axes[2].plot([0, 1], [0, 1], ":", color="gray", lw=1.0, label="random routing")
    axes[2].set_xlabel("candidate density")
    axes[2].set_ylabel("routing recall")
    axes[2].grid(alpha=0.25)
    axes[2].legend(fontsize=8)
    axes[2].set_title("routing quality (recall > density => the indexer selects)")

    fig.tight_layout()
    for name in ("frontier.png", "frontier.pdf"):
        fig.savefig(out / name, dpi=150)
    print("wrote %s" % (out / "frontier.png"))
    print()
    print("%-10s %9s %9s %9s %9s" % ("label", "density", "avg_cand", "recall", "val_loss"))
    for label, r in points:
        print("%-10s %9.4f %9.2f %9.4f %9.4f" % (label, r["density"], r["cand"], r["recall"], r["loss"]))
    if base:
        print("%-10s %9.4f %9.2f %9s %9.4f" % ("baseline", base["density"], base["cand"], "-", base["loss"]))


if __name__ == "__main__":
    main()
