"""Train the indexer-free MLA baseline or SCA-L Duo on character-level Tiny Shakespeare."""

from __future__ import annotations

import argparse
import math
import time
from pathlib import Path

import torch

from baseline.model import BaselineModel
from sca_duo.model import SCADuoModel
from .data import get_batch, iter_batches, load_tiny_shakespeare, load_token_tensor
from .metrics import MetricsWriter


def build_model(args, vocab_size: int):
    common = dict(vocab_size=vocab_size, block_size=args.block_size, emb_dim=args.emb_dim,
                  n_heads=args.n_heads, n_layer=args.n_layer, dropout=args.dropout,
                  q_latent_dim=args.q_latent_dim, kv_latent_dim=args.mla_latent_dim)
    if args.model == "baseline":
        return BaselineModel(**common)
    return SCADuoModel(**common, latent_dim=args.sca_latent_dim, chunk_size=args.chunk_size,
                       detach_indexer=args.detach_indexer,
                       aux_mode=args.aux_mode, aux_beta=args.aux_beta,
                       ste_mask=args.ste_mask, code_std=args.code_std,
                       target_density=args.target_density,
                       target_candidates=args.target_candidates,
                       density_ctrl_rate=args.density_ctrl_rate,
                       pos_chunk=args.pos_chunk)


def learning_rate(step: int, args) -> float:
    """Linear warmup followed by cosine decay to min_lr_ratio * lr."""

    minimum = args.lr * args.min_lr_ratio
    if args.warmup_steps > 0 and step < args.warmup_steps:
        return args.lr * float(step + 1) / float(args.warmup_steps)
    total = max(1, args.steps - args.warmup_steps)
    progress = min(max((step - args.warmup_steps) / total, 0.0), 1.0)
    return minimum + 0.5 * (args.lr - minimum) * (1.0 + math.cos(math.pi * progress))


def evaluate(model, validation_data, args, device, amp: bool):
    model.eval()
    totals: dict[str, float] = {}
    tokens_seen = 0
    stream = validation_data if args.eval_tokens <= 0 else validation_data[:args.eval_tokens]
    with torch.no_grad():
        for tokens, targets in iter_batches(stream, args.block_size, args.batch_size, device):
            with torch.autocast(device_type=device.type, dtype=torch.float16, enabled=amp):
                logits, loss, metrics = model(tokens, targets)
            count = targets.numel()
            tokens_seen += count
            totals["val_loss"] = totals.get("val_loss", 0.0) + float(loss.detach().float()) * count
            correct = (logits.detach().argmax(dim=-1) == targets).sum().item()
            totals["val_accuracy"] = totals.get("val_accuracy", 0.0) + correct
            for key, value in metrics.items():
                column = "val_" + key
                totals[column] = totals.get(column, 0.0) + float(value.detach().float()) * count
    result = {"val_loss": totals["val_loss"] / tokens_seen,
              "val_accuracy": totals["val_accuracy"] / tokens_seen}
    for key, value in totals.items():
        if key not in result:
            result[key] = value / tokens_seen
    model.train()
    return result


def save_checkpoint(path, model, optimizer, step, args, vocab_meta, with_optimizer=True):
    payload = {
        "model": model.state_dict(),
        "step": step,
        "config": model.config(),
        "vocab_meta": vocab_meta,
        "args": vars(args),
    }
    if with_optimizer:
        payload["optimizer"] = optimizer.state_dict()
    torch.save(payload, path)


def prune_checkpoints(directory: Path, keep: int) -> None:
    if keep <= 0:
        return
    saved = sorted(directory.glob("step_*.pt"))
    for path in saved[:-keep]:
        path.unlink()


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", choices=("baseline", "sca_duo"), required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--data-path", default="data/tinyshakespeare.txt")
    parser.add_argument("--data-url", default=None)
    parser.add_argument("--tokenizer-path", default=None,
                        help="byte-level BPE tokenizer.json; selects the BPE corpus instead of char-level data")
    parser.add_argument("--train-tokens", default=None, help="cached train token tensor for the BPE corpus")
    parser.add_argument("--valid-tokens", default=None, help="cached validation token tensor for the BPE corpus")
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--allow-cpu", action="store_true")
    parser.add_argument("--amp", action="store_true")
    parser.add_argument("--seed", type=int, default=1337)

    parser.add_argument("--block-size", type=int, default=256)
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--steps", type=int, default=3000)
    parser.add_argument("--stop-at", type=int, default=0,
                        help="stop after this many steps while keeping the --steps learning-rate "
                             "schedule, so a short screening run stays comparable to the full one")
    parser.add_argument("--eval-every", type=int, default=50)
    parser.add_argument("--save-every", type=int, default=50)
    parser.add_argument("--keep-checkpoints", type=int, default=0,
                        help="0 keeps every checkpoint; N keeps the newest N step_*.pt files")
    parser.add_argument("--log-every", type=int, default=50)
    parser.add_argument("--eval-tokens", type=int, default=0,
                        help="cap the validation stream at this many tokens (0 uses the whole split)")
    parser.add_argument("--tensorboard-dir", default=None,
                        help="if set, mirror every metric into this TensorBoard logdir")

    parser.add_argument("--emb-dim", type=int, default=512)
    parser.add_argument("--n-heads", type=int, default=8)
    parser.add_argument("--n-layer", type=int, default=6)
    parser.add_argument("--q-latent-dim", type=int, default=64)
    parser.add_argument("--mla-latent-dim", type=int, default=64)
    parser.add_argument("--dropout", type=float, default=0.1)

    parser.add_argument("--sca-latent-dim", type=int, default=4)
    parser.add_argument("--chunk-size", type=float, default=1.0)
    parser.add_argument("--aux-weight", type=float, default=1.0)
    parser.add_argument("--detach-indexer", action="store_true",
                        help="stop the distillation term from reaching W_q_down / W_kv_down")
    parser.add_argument("--ste-mask", action="store_true",
                        help="straight-through mask: the hard neighbourhood is exact in the "
                             "forward pass, the backward pass flows as if it were the soft "
                             "one, so the LM loss itself trains the routing")
    parser.add_argument("--target-density", type=float, default=0.0,
                        help="feedback setpoint for the candidate density (0 disables). Pinning "
                             "the code spread instead only sets how fast the routing relaxes to "
                             "fully dense")
    parser.add_argument("--target-candidates", type=float, default=0.0,
                        help="feedback setpoint for the mean candidate count (0 disables). "
                             "Unlike --target-density this is length independent, so the same "
                             "budget at a longer context is a smaller fraction of the work")
    parser.add_argument("--pos-chunk", type=float, default=0.0,
                        help="fixed cell width in tokens of an extra relative-distance "
                             "axis; 0 disables it.  The content axes get their width from "
                             "chunk_size * density_gain, i.e. from the density controller, "
                             "which coarsens them until the density target is met -- measured "
                             "2 to 9 cells per axis over a 1024 block, so no content axis can "
                             "resolve a recency window.  This axis is fixed instead.")
    parser.add_argument("--density-ctrl-rate", type=float, default=0.0,
                        help="integral gain of the density controller, per step")
    parser.add_argument("--code-std", type=float, default=0.0,
                        help="pin the code spread to this standard deviation (0 disables). "
                             "Sparsity is a constraint, not something a loss will choose")
    parser.add_argument("--aux-mode", choices=("kl", "recall", "rate", "none"), default="kl",
                        help="kl: distil the indexer score against dense attention. "
                             "recall: train the projection to keep the attention mass inside "
                             "the neighbourhood, paying --aux-beta per unit of density")
    parser.add_argument("--aux-beta", type=float, default=1.0,
                        help="recall mode only: keep a key when its attention exceeds beta "
                             "times the mean.  beta=1 is roughly 50%% density")
    parser.add_argument("--indexer-grad-clip", type=float, default=1.0,
                        help="separate clip for the indexer parameters; sharing one clip with "
                             "the trunk let the auxiliary gradient starve the trunk")
    parser.add_argument("--indexer-lr-scale", type=float, default=1.0,
                        help="learning-rate multiplier for the indexer parameters.  Adam is "
                             "scale invariant, so --aux-weight cannot slow the indexer down; "
                             "only its own learning rate can")

    parser.add_argument("--lr", type=float, default=3e-4)
    parser.add_argument("--min-lr-ratio", type=float, default=0.1)
    parser.add_argument("--warmup-steps", type=int, default=100)
    parser.add_argument("--weight-decay", type=float, default=0.1)
    parser.add_argument("--grad-clip", type=float, default=1.0)
    return parser.parse_args()


def main():
    args = parse_args()
    device = torch.device(args.device)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA was requested but is not available")
    if device.type != "cuda" and not args.allow_cpu:
        raise RuntimeError("CPU training is disabled by default; pass --allow-cpu for a smoke run")
    if device.type == "cpu" and args.amp:
        raise ValueError("--amp is only supported on CUDA")

    torch.manual_seed(args.seed)
    if device.type == "cuda":
        torch.cuda.manual_seed_all(args.seed)
    if hasattr(torch, "set_float32_matmul_precision"):
        torch.set_float32_matmul_precision("high")

    output_dir = Path(args.output_dir)
    checkpoint_dir = output_dir / "checkpoints"
    checkpoint_dir.mkdir(parents=True, exist_ok=True)
    metrics_path = output_dir / "metrics.csv"

    if args.tokenizer_path:
        if not (args.train_tokens and args.valid_tokens):
            raise SystemExit("--tokenizer-path needs --train-tokens and --valid-tokens")
        from tokenizers import Tokenizer

        tokenizer = Tokenizer.from_file(args.tokenizer_path)
        vocab_size = tokenizer.get_vocab_size()
        vocab_meta = {"type": "bpe", "tokenizer": args.tokenizer_path, "vocab_size": vocab_size}
        train_data = load_token_tensor(args.train_tokens)
        validation_data = load_token_tensor(args.valid_tokens)
    else:
        load_kwargs = {}
        if args.data_url is not None:
            load_kwargs["download_url"] = args.data_url
        train_data, validation_data, stoi, _ = load_tiny_shakespeare(args.data_path, **load_kwargs)
        vocab_size = len(stoi)
        vocab_meta = {"type": "char", "stoi": stoi, "vocab_size": vocab_size}
    train_data = train_data.to(device)
    validation_data = validation_data.to(device)
    print("tokens: train=%d valid=%d vocab=%d" % (len(train_data), len(validation_data), vocab_size))

    model = build_model(args, vocab_size).to(device)
    indexer_named = [(name, param) for name, param in model.named_parameters() if ".indexer." in name]
    indexer_ids = {id(param) for _, param in indexer_named}
    groups = [{"params": [p for p in model.parameters() if id(p) not in indexer_ids],
               "lr": args.lr, "lr_scale": 1.0}]
    if indexer_ids and args.indexer_lr_scale != 1.0:
        groups.insert(0, {"params": [p for _, p in indexer_named],
                          "lr": args.lr * args.indexer_lr_scale,
                          "lr_scale": args.indexer_lr_scale})
    optimizer = torch.optim.AdamW(groups, lr=args.lr, weight_decay=args.weight_decay)
    # The auxiliary objective only touches the indexer, so clipping the two sets
    # together let an indexer gradient 10-65x larger than the trunk's shrink every
    # trunk update by the same factor, i.e. train the trunk at a fraction of the
    # configured learning rate.  They are clipped separately.
    trunk_params = [p for p in model.parameters() if id(p) not in indexer_ids]
    indexer_params = [p for _, p in indexer_named]
    use_amp = args.amp and device.type == "cuda"
    scaler = torch.amp.GradScaler("cuda", enabled=use_amp)
    generator = torch.Generator(device=device).manual_seed(args.seed)
    writer = MetricsWriter(metrics_path)
    tb_writer = None
    if args.tensorboard_dir:
        try:
            from torch.utils.tensorboard import SummaryWriter
        except ImportError as exc:
            raise SystemExit("--tensorboard-dir requires the tensorboard package: " + str(exc))
        tb_writer = SummaryWriter(args.tensorboard_dir)
        tb_writer.add_text("config", "%s %s" % (model.config(), vars(args)))

    neighbourhood = ""
    if args.model == "sca_duo":
        cells = model.neighbourhood_size()
        neighbourhood = " sca_latent_dim=%d chunk_size=%g neighbourhood=%d cells" % (
            args.sca_latent_dim, args.chunk_size, cells)
    print("model=%s params=%d steps=%d block=%d batch=%d%s" % (
        model.model_name, model.parameter_count(), args.steps, args.block_size, args.batch_size, neighbourhood))
    print("config=%s" % (model.config(),))
    steps_per_epoch = max(1, len(train_data) // (args.batch_size * args.block_size))
    print("steps_per_epoch=%d" % steps_per_epoch)

    model.train()
    best_validation = float("inf")
    started = time.time()
    final_step = args.steps if args.stop_at <= 0 else min(args.steps, args.stop_at)
    for step in range(1, final_step + 1):
        lr = learning_rate(step - 1, args)
        for group in optimizer.param_groups:
            group["lr"] = lr * group.get("lr_scale", 1.0)
        tokens, targets = get_batch(train_data, args.block_size, args.batch_size, device, generator)
        optimizer.zero_grad(set_to_none=True)
        with torch.autocast(device_type=device.type, dtype=torch.float16, enabled=use_amp):
            _, loss, metrics = model(tokens, targets)
            aux_loss = metrics.get("aux_loss")
            if aux_loss is None:
                total_loss = loss
            else:
                total_loss = loss + args.aux_weight * aux_loss
        scaler.scale(total_loss).backward()
        scaler.unscale_(optimizer)
        if args.grad_clip:
            torch.nn.utils.clip_grad_norm_(trunk_params, args.grad_clip)
        if indexer_params:
            torch.nn.utils.clip_grad_norm_(indexer_params, args.indexer_grad_clip)
        scaler.step(optimizer)
        scaler.update()

        epoch = 1 + (step - 1) // steps_per_epoch
        elapsed = time.time() - started
        writer.record_train(
            step=step,
            epoch=epoch,
            train_loss=float(loss.detach().float()),
            train_aux_loss=None if aux_loss is None else float(aux_loss.detach().float()),
            learning_rate=lr,
            elapsed_seconds=elapsed,
        )
        if tb_writer is not None:
            tb_writer.add_scalar("loss/train", float(loss.detach().float()), step)
            if aux_loss is not None:
                tb_writer.add_scalar("loss/train_aux", float(aux_loss.detach().float()), step)
            tb_writer.add_scalar("optim/learning_rate", lr, step)
            tb_writer.add_scalar("time/elapsed_seconds", elapsed, step)
            tb_writer.add_scalar("epoch", epoch, step)

        if step % args.eval_every == 0 or step == args.steps:
            values = evaluate(model, validation_data, args, device, use_amp)
            writer.record_eval(step=step, **values)
            if tb_writer is not None:
                for key, value in values.items():
                    tb_writer.add_scalar("val/" + key[len("val_"):], value, step)
            if values["val_loss"] < best_validation:
                best_validation = values["val_loss"]
                save_checkpoint(output_dir / "best.pt", model, optimizer, step, args, vocab_meta,
                                with_optimizer=False)
            if args.log_every and step % args.log_every == 0:
                extra = " ".join("%s=%.4f" % (key, value) for key, value in sorted(values.items()))
                print("step=%d train=%.4f %s" % (step, float(loss.detach().float()), extra), flush=True)

        if step % args.save_every == 0 or step == args.steps:
            # Periodic checkpoints carry weights only: the two AdamW moment
            # buffers triple the write volume and are only needed to resume.
            save_checkpoint(checkpoint_dir / ("step_%06d.pt" % step), model, optimizer, step, args,
                            vocab_meta, with_optimizer=False)
            if step % (args.save_every * 10) == 0 or step == args.steps:
                save_checkpoint(output_dir / "last.pt", model, optimizer, step, args, vocab_meta)
            prune_checkpoints(checkpoint_dir, args.keep_checkpoints)

    if tb_writer is not None:
        tb_writer.flush()
        tb_writer.close()
    print("saved metrics: %s" % metrics_path)
    print("saved checkpoints: %s" % checkpoint_dir)


if __name__ == "__main__":
    main()
