#!/usr/bin/env bash
# Block-1024 SCA-L Duo with a fixed-width relative-distance axis in the indexer.
#
# The mask ablation showed the trained indexer losing to a free sliding window
# (1.9546 vs 1.8786) while a cheating oracle beats that window by only 0.0069.  So
# at density 0.5 the routing problem is essentially "keep the recent keys", and the
# indexer was not solving it.
#
# The probe says why, and it is not the embedding.  Position is not missing: c_kv
# predicts position with R^2 0.97..0.99 and z_k still does at 0.81..0.94, with
# single axes correlating at 0.88..0.94.  What fails is *resolution* -- the
# quantised partition has only 2..9 cells per axis across a 1024 block, so
# Chebyshev <= 1 admits a +-1 cell band, i.e. about 250..530 tokens, while the
# budget asks for about 224.
#
# That is a structural conflict, not a tuning problem: the content axes take their
# width from chunk_size * density_gain, so the density controller coarsens them
# back to whatever hits the target.  --pos-chunk 128 adds one axis whose cell width
# is fixed in tokens, outside that controller, so Chebyshev <= 1 becomes a 256
# token recency window which content similarity then refines.
#
# Success criterion: indexer val_loss below the free window's 1.8786.  Tying it is
# a negative result -- it would mean the indexer is only a more expensive window.
#
# The ablation runs automatically on the finished checkpoint.
set -u
cd /root/sca
PY=/root/miniconda3/bin/python
export PYTHONPATH=/root/sca
TOTAL=7755
NAME=sca1024_pos128

train () {
  if grep -q "^${TOTAL}," "result/${NAME}/metrics.csv" 2>/dev/null; then
    echo "### skip ${NAME} (already complete)"; return 0
  fi
  echo "### train ${NAME} block=1024 batch=16 steps=${TOTAL} target_density=0.50 pos_chunk=128"
  "$PY" -m common.train --model sca_duo \
    --output-dir "result/${NAME}" \
    --tensorboard-dir "result/tensorboard/${NAME}" \
    --q-latent-dim 64 --sca-latent-dim 4 --chunk-size 0.5 --code-std 0.30 \
    --target-density 0.50 --density-ctrl-rate 0.05 --pos-chunk 128 \
    --aux-mode rate --aux-beta 0.0 --indexer-lr-scale 0.1 --detach-indexer \
    --tokenizer-path /root/sca/data/bpe/tokenizer.json \
    --train-tokens /root/sca/data/bpe/train.pt \
    --valid-tokens /root/sca/data/bpe/val.pt \
    --device cuda --block-size 1024 --batch-size 16 --steps "${TOTAL}" \
    --eval-every 50 --eval-tokens 262144 --save-every 500 --keep-checkpoints 3 \
    --emb-dim 512 --n-heads 8 --n-layer 6 --mla-latent-dim 64 --dropout 0.1 \
    --lr 3e-4 --warmup-steps 100 --weight-decay 0.1 --grad-clip 1.0 --seed 1337 --amp
  echo "### train ${NAME} exit=$?"
}

ablate () {
  [ -f "result/${NAME}/last.pt" ] || { echo "### ablation SKIPPED (no checkpoint)"; return 0; }
  for mode in indexer oracle local random sink_local; do
    echo "### ablation ${mode}"
    "$PY" tools/eval_mask_ablation.py --mode "${mode}" \
      --checkpoint "result/${NAME}/last.pt" --valid-tokens data/bpe/val.pt 2>&1 \
      | grep -v -e FutureWarning -e weights_only -e recommend -e torch.load
  done
}

train
ablate
echo "### sca1024_pos128 done"
