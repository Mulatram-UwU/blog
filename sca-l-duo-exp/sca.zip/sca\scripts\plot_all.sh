#!/usr/bin/env bash
# Draw one figure per metric across every trained run.
set -euo pipefail
cd "$(dirname "$0")/.."
export PYTHONPATH="$PWD${PYTHONPATH:+:$PYTHONPATH}"

PYTHON_BIN="${PYTHON_BIN:-python}"
RESULT_DIR="${RESULT_DIR:-result}"
CHUNK_SIZES="${CHUNK_SIZES:-0.5 1 2 4}"

args=(--run "baseline=$RESULT_DIR/baseline/metrics.csv")
for chunk in $CHUNK_SIZES; do
  tag="${chunk/./p}"
  args+=(--run "sca_duo chunk_size=$chunk=$RESULT_DIR/sca_duo_chunk$tag/metrics.csv")
done

"$PYTHON_BIN" -m common.plot "${args[@]}" --output-dir "$RESULT_DIR/plots"
