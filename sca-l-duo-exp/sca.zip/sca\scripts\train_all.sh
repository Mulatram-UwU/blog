#!/usr/bin/env bash
# Train the indexer-free MLA baseline and SCA-L Duo for every chunk size.
set -euo pipefail
cd "$(dirname "$0")/.."
export PYTHONPATH="$PWD${PYTHONPATH:+:$PYTHONPATH}"

PYTHON_BIN="${PYTHON_BIN:-python}"
DATA_PATH="${DATA_PATH:-data/tinyshakespeare.txt}"
RESULT_DIR="${RESULT_DIR:-result}"
CHUNK_SIZES="${CHUNK_SIZES:-0.5 1 2 4}"
STEPS="${STEPS:-3000}"
EVAL_EVERY="${EVAL_EVERY:-50}"
EVAL_TOKENS="${EVAL_TOKENS:-0}"
SAVE_EVERY="${SAVE_EVERY:-50}"
KEEP_CHECKPOINTS="${KEEP_CHECKPOINTS:-0}"
BATCH_SIZE="${BATCH_SIZE:-32}"
BLOCK_SIZE="${BLOCK_SIZE:-256}"
EMB_DIM="${EMB_DIM:-512}"
N_HEADS="${N_HEADS:-8}"
N_LAYER="${N_LAYER:-6}"
MLA_LATENT_DIM="${MLA_LATENT_DIM:-64}"
SCA_LATENT_DIM="${SCA_LATENT_DIM:-4}"
AUX_WEIGHT="${AUX_WEIGHT:-1.0}"
LR="${LR:-3e-4}"
SEED="${SEED:-1337}"
DEVICE="${DEVICE:-cuda}"
AMP_FLAG="${AMP:-1}"

TOKENIZER_PATH="${TOKENIZER_PATH:-}"
TRAIN_TOKENS="${TRAIN_TOKENS:-}"
VALID_TOKENS="${VALID_TOKENS:-}"
INDEXER_LR_SCALE="${INDEXER_LR_SCALE:-1.0}"
DETACH_INDEXER="${DETACH_INDEXER:-0}"

token_args=()
data_args=(--data-path "$DATA_PATH")
if [[ -n "$TOKENIZER_PATH" ]]; then
  token_args=(--tokenizer-path "$TOKENIZER_PATH" --train-tokens "$TRAIN_TOKENS" --valid-tokens "$VALID_TOKENS")
  data_args=()
fi

common=(
  "${data_args[@]}"
  --device "$DEVICE"
  --block-size "$BLOCK_SIZE"
  --batch-size "$BATCH_SIZE"
  --steps "$STEPS"
  --eval-every "$EVAL_EVERY"
  --eval-tokens "$EVAL_TOKENS"
  --save-every "$SAVE_EVERY"
  --keep-checkpoints "$KEEP_CHECKPOINTS"
  --emb-dim "$EMB_DIM"
  --n-heads "$N_HEADS"
  --n-layer "$N_LAYER"
  --mla-latent-dim "$MLA_LATENT_DIM"
  --dropout "${DROPOUT:-0.1}"
  --lr "$LR"
  --warmup-steps "${WARMUP_STEPS:-100}"
  --weight-decay "${WEIGHT_DECAY:-0.1}"
  --grad-clip "${GRAD_CLIP:-1.0}"
  --seed "$SEED"
)

amp_args=()
if [[ "$AMP_FLAG" == "1" ]]; then
  amp_args+=(--amp)
fi

indexer_args=(--indexer-lr-scale "$INDEXER_LR_SCALE")
if [[ "$DETACH_INDEXER" == "1" ]]; then
  indexer_args+=(--detach-indexer)
fi

if [[ "${RUN_BASELINE:-1}" == "1" ]]; then
  echo "== baseline (indexer-free MLA) =="
  "$PYTHON_BIN" -m common.train --model baseline \
    --output-dir "$RESULT_DIR/baseline" \
    --tensorboard-dir "$RESULT_DIR/tensorboard/baseline" \
    "${token_args[@]}" "${common[@]}" "${amp_args[@]}"
else
  echo "== baseline skipped (RUN_BASELINE=0) =="
fi

for chunk in $CHUNK_SIZES; do
  tag="${chunk/./p}"
  echo "== sca_duo chunk_size=$chunk =="
  "$PYTHON_BIN" -m common.train --model sca_duo \
    --output-dir "$RESULT_DIR/sca_duo_chunk$tag" \
    --tensorboard-dir "$RESULT_DIR/tensorboard/sca_duo_chunk$tag" \
    --q-latent-dim "$MLA_LATENT_DIM" \
    --sca-latent-dim "$SCA_LATENT_DIM" \
    --chunk-size "$chunk" \
    --aux-weight "$AUX_WEIGHT" \
    "${indexer_args[@]}" \
    "${token_args[@]}" "${common[@]}" "${amp_args[@]}"
done
echo "== all runs finished =="
