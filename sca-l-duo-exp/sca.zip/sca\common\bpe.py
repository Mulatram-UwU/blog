"""Byte-level BPE tokenizer helpers and corpus encoding."""

from __future__ import annotations

import numpy as np
import torch
from tokenizers import Tokenizer, decoders, models, pre_tokenizers, trainers


def train_byte_bpe(sample_paths, vocab_size: int, output_path) -> Tokenizer:
    tokenizer = Tokenizer(models.BPE())
    tokenizer.pre_tokenizer = pre_tokenizers.ByteLevel(add_prefix_space=False)
    tokenizer.decoder = decoders.ByteLevel()
    trainer = trainers.BpeTrainer(
        vocab_size=vocab_size,
        initial_alphabet=pre_tokenizers.ByteLevel.alphabet(),
        show_progress=False,
    )
    tokenizer.train([str(path) for path in sample_paths], trainer)
    tokenizer.save(str(output_path))
    return tokenizer


def encode_text(tokenizer: Tokenizer, text: str, chunk_chars: int = 1 << 20) -> np.ndarray:
    """Encode a long string in chunks so peak memory stays bounded."""

    chunks = []
    for start in range(0, len(text), chunk_chars):
        ids = tokenizer.encode(text[start:start + chunk_chars]).ids
        if ids:
            chunks.append(np.asarray(ids, dtype=np.int32))
    if not chunks:
        return np.zeros(0, dtype=np.int32)
    return np.concatenate(chunks)


def save_tokens(array: np.ndarray, path) -> None:
    torch.save(torch.from_numpy(np.ascontiguousarray(array)), path)
