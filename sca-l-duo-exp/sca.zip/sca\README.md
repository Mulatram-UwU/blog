# SCA-L Duo

SCA-L Duo = **MLA attention + a SCA-L latent indexer that reads the compressed
KV cache**.  The indexer attaches to `c_kv` -- the tensor that is actually kept
in the cache -- not to the raw embedding `h`, which is gone by decode time.
Both models are trained from scratch on a TinyStories slice with a byte-level
BPE (vocab 8192) and compared on validation loss / accuracy, with routing quality
instrumented.

## What the two models are

**baseline/ -- indexer-free MLA.**  Both the query and the KV path are compressed
through a low-rank latent, which is what MLA actually caches:

    c_q  = W_q_down h          # query latent
    c_kv = W_kv_down h         # KV cache, mla_latent_dim wide
    q = W_q_up c_q,  k = W_k_up c_kv,  v = W_v_up c_kv

Attention is the ordinary causal softmax over every visible key.

**sca_duo/ -- MLA + SCA-L indexer.**  Identical MLA, plus an indexer that
projects the *already compressed* latents (`c_kv` from the KV cache, `c_q` from
the query path) into sca_latent_dim dimensions.  The code is squashed into the
bounded box `tanh(z) / (chunk_size * density_gain)` and floored; a query visits
every cell within Chebyshev distance one of its own cell, i.e. the full
{-1, 0, +1} block, which is 3 ** sca_latent_dim = 81 cells at sca_latent_dim = 4.
Attention is then computed only over those keys, but the logits still come from
MLA -- the indexer chooses, it never scores.  The diagonal is forced on, because
`z_q` and `z_k` come from different projections and a query could otherwise
route away every causal key and softmax an all `-inf` row into NaN.

## How the indexer is trained

It never scores, so the language modelling loss gives it nothing.

Sparsity cannot come from the objective either.  Every auxiliary term we tried --
KL distillation, budgeted recall, a rate penalty -- prefers a denser partition,
so density is an attractor at 1.0 and no loss weight moves it (pinning the code
spread with `--code-std` only buys time before the routing collapses).  Two
things replace it:

- **Distortion**, the only term the indexer's projection learns.  The
  head-averaged dense attention is the teacher and
  `sum_t P(t) * relu(|u_q - u_k| - 1)` pulls the key pairs that carry attention
  into adjacent cells.  Run with `--aux-mode rate --aux-beta 0.0`, i.e. the rate
  half is switched off and only the distortion half is left.
- **A density controller.**  `density_gain` scales the effective cell width and
  is driven by integral control on the EMA of the measured quantity,
  `gain *= exp(-rate * (ema - target))`.  It is a buffer, so the converged value
  travels with the checkpoint and inference is a fixed partition.  Without the
  EMA the loop integrates its own mini-batch noise and settles into a period-two
  limit cycle.  The gain is clamped to [1e-3, 1e3]: the codes are divided by it,
  so an unbounded shrink eventually overflows half precision.

The setpoint is either `--target-density` (candidates/visible, per query,
averaged over positions) or `--target-candidates` (the mean candidate count
itself).  They are not interchangeable.  The candidate set is a fixed 81-cell
neighbourhood, so it keeps a fixed *fraction* of the keys however long the
context is: a density target makes the compute fraction length invariant by
construction and the candidate count simply grows with the context.  Only an
absolute budget turns a longer context into a smaller share of the work.

`--detach-indexer` keeps the auxiliary term off `W_q_down` / `W_kv_down`, so the
trunk is trained on the LM loss alone and stays comparable with the baseline.

The trunk and the indexer are clipped separately.  Sharing one
`clip_grad_norm_` let an indexer gradient 10-65x larger than the trunk's shrink
every trunk update by the same factor.

## Diagnostics written to every CSV

  - val_avg_candidates      average number of candidate keys per query
                            (dense MLA averages 128.5 at block_size 256)
  - val_candidate_density   per-query candidates/visible, averaged over positions
                            (1.0 means fully dense)
  - val_routing_recall      share of the dense attention mass that lands inside
                            the candidate set; recall/density is 1 under random
                            routing and >1 when the indexer actually selects
  - val_density_ema         the controller's smoothed measurement, i.e. what it
                            thinks it is getting; compare with the setpoint
  - val_density_gain        the converged cell width, averaged over layers; a
                            value pinned near a clamp means the controller is
                            saturated and the setpoint is not actually reachable
  - train_aux_loss / val_aux_loss   the auxiliary term itself

If a run is already fully dense, density sits at 1.0, sparsity claims are
meaningless for it, and any "matching the baseline" result is vacuous.

## Layout

    baseline/          indexer-free MLA (model.py)
    sca_duo/           SCA-L Duo: indexer.py + model.py
    common/            bpe.py, build_data.py, data.py, metrics.py, train.py, plot.py
    scripts/           train_all.sh, plot_all.sh, smoke_cpu.sh
    tools/remote.py    SSH/SFTP helper for the AutoDL box
    tools/plot_frontier.py    the density-frontier figure
    tools/measure_oracle.py   the oracle routing frontier of a checkpoint
    result/            every artefact: metrics.csv, checkpoints/, plots/

## Local smoke test (CPU, no GPU needed)

    bash scripts/smoke_cpu.sh

## Data

    bash tools/prepare_data.sh

Downloads a ~250 MB slice of TinyStoriesV2-GPT4-train, trains the byte-level BPE
(vocab 8192, `common/build_data.py`) and caches `data/bpe/{tokenizer.json,train.pt,val.pt}`.
The validation split is the tail of the slice, so the two halves never overlap.
The corpus itself is not shipped in the archive.

## One frontier point

    python -m common.train --model sca_duo \
      --output-dir result/dens_t050 \
      --q-latent-dim 64 --sca-latent-dim 4 --chunk-size 0.5 --code-std 0.30 \
      --target-density 0.50 --density-ctrl-rate 0.05 \
      --aux-mode rate --aux-beta 0.0 --indexer-lr-scale 0.1 --detach-indexer \
      --tokenizer-path data/bpe/tokenizer.json \
      --train-tokens data/bpe/train.pt --valid-tokens data/bpe/val.pt \
      --device cuda --block-size 256 --batch-size 32 --steps 7755 \
      --eval-every 50 --eval-tokens 262144 --save-every 50 --keep-checkpoints 2 \
      --emb-dim 512 --n-heads 8 --n-layer 6 --mla-latent-dim 64 --dropout 0.1 \
      --lr 3e-4 --warmup-steps 100 --weight-decay 0.1 --grad-clip 1.0 --seed 1337 --amp

The baseline is the same command with `--model baseline` and no indexer flags.
`--target-density 0` disables the controller; `--stop-at N` runs N steps on the
full `--steps` learning-rate schedule.

## Oracle routing frontier

A density sweep cannot tell a weak router from a context with nothing worth
selecting.  `tools/measure_oracle.py` supplies the missing ceiling: rank each
query's visible keys by the dense head-averaged attention and add up the top C.
That is the best any fixed-budget router can do on this model, and it costs one
validation pass on a checkpoint.

    PYTHONPATH=. python tools/measure_oracle.py \
      --checkpoint result/base1024/last.pt --valid-tokens data/bpe/val.pt \
      --budgets 8,16,32,48,64,96,128 --batch-size 8 --out result/base1024/oracle.csv

Read it against `val_routing_recall` from the matching sparse run: the gap
between the two is what the indexer is leaving on the table.  If the ceiling
itself barely rises when the context grows, longer sequences cannot make sparse
attention pay here and no amount of indexer training will change that.

## Plotting

    python -m common.plot --run baseline=result/baseline --run d0.50=result/dens_t050 \
      --output-dir result/plots
    python tools/plot_frontier.py --baseline result/baseline \
      --run d0.50=result/dens_t050 --output-dir result/plots
