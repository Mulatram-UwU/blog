#!/usr/bin/env bash
# Download a TinyStories slice, train a byte-level BPE, cache token tensors.
set -u
cd /root/sca
PY="$(cat .python_path 2>/dev/null || echo /root/miniconda3/bin/python)"
mkdir -p /root/autodl-tmp/data result/logs
SLICE=/root/autodl-tmp/data/tinystories-slice.txt

echo "### tokenizers"
if ! "$PY" -c 'import tokenizers' >/dev/null 2>&1; then
  "$PY" -m pip install -q tokenizers 2>&1 | tail -3
fi
"$PY" -c 'import tokenizers;print("tokenizers", tokenizers.__version__)' || exit 1

echo "### download ~250MB slice of TinyStoriesV2-GPT4-train"
if [ ! -s "$SLICE" ]; then
  if [ -f /etc/network_turbo ]; then source /etc/network_turbo >/dev/null 2>&1 || true; fi
  curl -sL --retry 3 --max-time 2400 \
    https://huggingface.co/datasets/roneneldan/TinyStories/resolve/main/TinyStoriesV2-GPT4-train.txt \
    | head -c 262144000 > "$SLICE"
fi
echo "slice bytes: $(wc -c < "$SLICE")"
echo "--- head ---"; head -c 220 "$SLICE"; echo; echo "--- end ---"; tail -c 120 "$SLICE"; echo

echo "### build BPE corpus"
PYTHONPATH=/root/sca "$PY" -m common.build_data \
  --text "$SLICE" --out-dir /root/sca/data/bpe \
  --vocab-size 8192 --valid-bytes 4000000 --tokenizer-bytes 50000000
echo "### prepare done"
