#!/usr/bin/env python3
"""Did the token's position survive into the indexer's 4 latent coordinates?

The indexer decides with max_a |u_q[a] - u_k[a]| <= 1 -- a symmetric,
content-similarity style test with no distance term anywhere.  To express "keep
the most recent K keys" it therefore needs one axis on which the key coordinate
is monotone in sequence position, so that a fixed cell width becomes a fixed
window.  Whether such an axis exists is an empirical question about what the
projection kept, and the projection is trained only by the rate/distortion
auxiliary (--detach-indexer), never by the LM loss.

So measure, per layer:

  R2(c_kv -> pos)   how much position was available to the indexer at all
  R2(z_k  -> pos)   how much of it the projection kept
  corr(u_k[a], pos) whether any single axis is usable as a position axis

R2 is from a linear readout (least squares), so it is an upper bound on what the
cell partition could be doing with that axis.

    PYTHONPATH=. python tools/probe_indexer_position.py \
        --checkpoint result/sca1024_d050/last.pt --valid-tokens data/bpe/val.pt
"""

from __future__ import annotations

import argparse
import types

import torch

from common.data import iter_batches, load_token_tensor
from baseline.model import BaselineModel
from sca_duo.model import SCADuoModel


def build_model(config) -> torch.nn.Module:
    common = dict(vocab_size=config["vocab_size"], block_size=config["block_size"],
                  emb_dim=config["emb_dim"], n_heads=config["n_heads"],
                  n_layer=config["n_layer"], dropout=config.get("dropout", 0.0),
                  q_latent_dim=config["q_latent_dim"], kv_latent_dim=config["kv_latent_dim"])
    if config["model"] == "baseline":
        return BaselineModel(**common)
    return SCADuoModel(**common, latent_dim=config["sca_latent_dim"],
                       chunk_size=config["chunk_size"],
                       detach_indexer=config.get("detach_indexer", True),
                       aux_mode=config.get("aux_mode", "kl"),
                       aux_beta=config.get("aux_beta", 1.0),
                       ste_mask=config.get("ste_mask", False),
                       code_std=config.get("code_std", 0.0),
                       target_density=config.get("target_density", 0.0),
                       target_candidates=config.get("target_candidates", 0.0),
                       density_ctrl_rate=0.0,
                       pos_chunk=config.get("pos_chunk", 0.0),
                       pos_only=config.get("pos_only", False))


class Sink:
    def __init__(self, keep: int):
        self.keep = keep
        self.rows = 0
        self.z_k: list = []
        self.z_q: list = []
        self.u_k: list = []
        self.u_q: list = []
        self.c_kv: list = []
        self.pos: list = []

    def __call__(self, z_q, z_k, u_q, u_k, c_q, c_kv):
        if self.rows >= self.keep:
            return
        batch, sequence = z_k.shape[0], z_k.shape[1]
        position = torch.arange(sequence, device=z_k.device).float()
        position = (position / max(1, sequence - 1)).expand(batch, sequence)
        self.z_k.append(z_k.detach().float().reshape(-1, z_k.shape[-1]))
        self.z_q.append(z_q.detach().float().reshape(-1, z_q.shape[-1]))
        # u is the *continuous cell coordinate the model actually uses*, including
        # the code_std rescaling.  Recomputing it by hand gets the scale wrong.
        self.u_k.append(u_k.detach().float().reshape(-1, u_k.shape[-1]))
        self.u_q.append(u_q.detach().float().reshape(-1, u_q.shape[-1]))
        self.c_kv.append(c_kv.detach().float().reshape(-1, c_kv.shape[-1]))
        self.pos.append(position.reshape(-1))
        self.rows += batch * sequence


def r2(features: torch.Tensor, target: torch.Tensor) -> float:
    design = torch.cat([features.double(), torch.ones(features.shape[0], 1,
                      dtype=torch.float64, device=features.device)], dim=1)
    solution = torch.linalg.lstsq(design, target.double().unsqueeze(1)).solution
    residual = target.double() - (design @ solution).squeeze(1)
    total = target.double() - target.double().mean()
    return float(1.0 - (residual ** 2).sum() / (target.double() ** 2 - total * 0).sum()) if False else \
        float(1.0 - (residual ** 2).sum() / ((target.double() - target.double().mean()) ** 2).sum())


def correlation(axis: torch.Tensor, target: torch.Tensor) -> float:
    a = axis.double() - axis.double().mean()
    b = target.double() - target.double().mean()
    return float((a * b).sum() / (a.norm() * b.norm()).clamp_min(1e-12))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--valid-tokens", required=True)
    parser.add_argument("--batches", type=int, default=4)
    parser.add_argument("--batch-size", type=int, default=4)
    parser.add_argument("--device", default="cuda")
    args = parser.parse_args()

    device = torch.device(args.device)
    payload = torch.load(args.checkpoint, map_location="cpu", weights_only=False)
    config = payload["config"]
    model = build_model(config)
    model.load_state_dict(payload["model"])
    model = model.to(device).eval()
    if config["model"] != "sca_duo":
        raise SystemExit("only sca_duo has an indexer")

    sinks = []
    gains = []
    for block in model.blocks:
        sink = Sink(keep=args.batches * args.batch_size * config["block_size"])
        sinks.append(sink)
        gains.append(float(block.attention.indexer.density_gain))
        original = type(block.attention.indexer).encode

        def make(original, sink):
            def wrapped(self, c_q, c_kv):
                z_q, z_k = original(self, c_q, c_kv)
                sink(z_q, z_k, self.cell_coordinates(z_q), self.cell_coordinates(z_k),
                     c_q, c_kv)
                return z_q, z_k
            return wrapped

        block.attention.indexer.encode = types.MethodType(make(original, sink),
                                                           block.attention.indexer)

    tokens = load_token_tensor(args.valid_tokens)
    done = 0
    with torch.no_grad():
        for batch_tokens, _ in iter_batches(tokens, config["block_size"], args.batch_size, device):
            model(batch_tokens, None)
            done += 1
            if done >= args.batches:
                break

    chunk = config["chunk_size"]
    print("checkpoint=%s step=%s block=%s chunk_size=%s latent=%d rows=%d"
          % (args.checkpoint, payload.get("step"), config["block_size"], chunk,
             config["sca_latent_dim"], sinks[0].rows))
    print("\nR2 of a linear readout to token position (0 = position absent, 1 = fully linear in position)")
    print("%5s %10s %14s %14s %14s" % ("layer", "gain", "c_kv(64d)", "z_k(latent)", "z_q(latent)"))
    for index, sink in enumerate(sinks):
        z_k = torch.cat(sink.z_k)
        z_q = torch.cat(sink.z_q)
        c_kv = torch.cat(sink.c_kv)
        pos = torch.cat(sink.pos)
        print("%5d %10.4f %14.4f %14.4f %14.4f"
              % (index, gains[index], r2(c_kv, pos), r2(z_k, pos), r2(z_q, pos)))

    print("\nCan an axis turn into a recency window?")
    print("A Chebyshev test on one axis admits keys whose u differs by less than 2, so an")
    print("axis carrying position at slope du/dtoken admits a window of 2/|du/dtoken| tokens.")
    print("If that is far longer than the sequence, the axis cannot resolve recency at all.")
    print("%5s %4s %14s %7s %16s %12s" % ("layer", "axis", "corr(u_k,pos)", "cells", "u_range", "window_tok"))
    for index, sink in enumerate(sinks):
        u_k = torch.cat(sink.u_k)
        pos = torch.cat(sink.pos)
        sequence = config["block_size"]
        for axis in range(u_k.shape[-1]):
            column = u_k[:, axis]
            cells = int(column.floor().max().item() - column.floor().min().item()) + 1
            x = pos.double() - pos.double().mean()
            y = column.double() - column.double().mean()
            slope = float((x * y).sum() / (x * x).sum().clamp_min(1e-12))
            per_token = abs(slope) / max(1, sequence - 1)
            window = (2.0 / per_token) if per_token > 0 else float("inf")
            print("%5d %4d %14.4f %7d [%+7.2f,%+7.2f] %12.1f"
                  % (index, axis, correlation(column, pos), cells,
                     column.min(), column.max(), window))


if __name__ == "__main__":
    main()
