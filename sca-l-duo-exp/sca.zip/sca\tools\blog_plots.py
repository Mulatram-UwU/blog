#!/usr/bin/env python3
"""Plots for the SCA-L Duo end-to-end experiment report."""

import csv
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path("/root/sca/result")
OUT = Path("/root/sca/result/blog_plots")
OUT.mkdir(parents=True, exist_ok=True)
plt.rcParams.update({"figure.dpi": 150, "font.size": 10, "axes.grid": True,
                     "grid.alpha": 0.3, "axes.spines.top": False,
                     "axes.spines.right": False})


def metrics(name):
    rows = []
    with (ROOT / name / "metrics.csv").open() as handle:
        for row in csv.DictReader(handle):
            if not row.get("val_loss"):
                continue
            def num(key):
                value = row.get(key) or ""
                return float(value) if value else None
            rows.append({"step": int(row["step"]), "vl": float(row["val_loss"]),
                         "va": float(row["val_accuracy"]), "dens": num("val_candidate_density"),
                         "rec": num("val_routing_recall")})
    return rows


def oracle(name):
    out = {}
    for extra in ("oracle_final.csv", "oracle_ext.csv"):
        path = ROOT / name / extra
        if not path.exists():
            continue
        with path.open() as handle:
            for row in csv.DictReader(handle):
                out[int(row["budget"])] = float(row["oracle_recall"])
    return out


def save(fig, name):
    fig.tight_layout()
    fig.savefig(OUT / name, bbox_inches="tight")
    plt.close(fig)
    print("wrote", OUT / name)


b256, b1024, b1024b = metrics("base256"), metrics("base1024"), metrics("base1024b")
old_r, new_r = metrics("sca1024_d050"), metrics("sca1024_pos128")

# 1-2. the long-context runs
for key, label, ylabel in (("vl", "validation_loss", "validation loss"),
                           ("va", "validation_accuracy", "validation accuracy")):
    fig, axes = plt.subplots(figsize=(7, 4.2))
    scale = 1.0 if key == "vl" else 100.0
    for rows, name, style in ((b256, "block 256, 7755 steps", "-"),
                              (b1024, "block 1024, 3878 steps (one epoch)", "--"),
                              (b1024b, "block 1024, 7755 steps (two epochs)", "-")):
        axes.plot([r["step"] for r in rows], [r[key] * scale for r in rows], style, label=name)
    axes.set_xlabel("step")
    axes.set_ylabel(ylabel)
    axes.legend(fontsize=8)
    save(fig, label + ".png")

# 3. oracle frontier, against the budget and against the share of keys
f256, f1024 = oracle("base256"), oracle("base1024b")
fig, axes = plt.subplots(1, 2, figsize=(9.5, 4))
for frame, name, style in ((f256, "block 256", "-"), (f1024, "block 1024", "-")):
    budgets = sorted(frame)
    axes[0].plot(budgets, [frame[b] for b in budgets], style + "o", ms=3, label=name)
axes[0].set_xlabel("budget C (keys per query)")
axes[0].set_ylabel("attention mass inside top-C")
axes[0].legend(fontsize=8)
for frame, avg, name, style in ((f256, 128.5, "block 256", "-"), (f1024, 512.5, "block 1024", "-")):
    budgets = sorted(frame)
    axes[1].plot([b / avg for b in budgets], [frame[b] for b in budgets], style + "o", ms=3, label=name)
axes[1].set_xlabel("share of visible keys kept")
axes[1].set_ylabel("attention mass inside the kept set")
axes[1].legend(fontsize=8)
save(fig, "oracle_frontier.png")

# 4. mask ablation bars
dense = 1.6641
old = [("oracle", 1.8717), ("local", 1.8786), ("sink_local", None), ("indexer", 1.9546), ("random", 2.1314)]
new = [("oracle", 1.8786), ("local", 1.7911), ("sink_local", 1.8448), ("indexer", 1.7861), ("random", 2.3481)]
old_lookup = dict(old)
new_lookup = dict(new)
keys = ["oracle", "local", "sink_local", "indexer", "random"]
fig, axes = plt.subplots(figsize=(7.6, 4.2))
width = 0.38
positions = range(len(keys))
left = [old_lookup[k] if old_lookup.get(k) else 0 for k in keys]
right = [new_lookup[k] for k in keys]
axes.bar([p - width / 2 for p in positions], left, width, label="4-D cell indexer", color="#9aa4b2")
axes.bar([p + width / 2 for p in positions], right, width, label="+ fixed-width time axis", color="#2f6fd0")
for p, k in zip(positions, keys):
    if old_lookup.get(k):
        axes.text(p - width / 2, old_lookup[k] + 0.012, "%.3f" % old_lookup[k], ha="center", fontsize=7)
    axes.text(p + width / 2, new_lookup[k] + 0.012, "%.3f" % new_lookup[k], ha="center", fontsize=7)
axes.axhline(dense, ls="--", c="k", lw=1)
axes.text(len(keys) - 0.5, dense + 0.012, "dense %.4f" % dense, ha="right", fontsize=8)
axes.set_xticks(list(positions))
axes.set_xticklabels(keys)
axes.set_ylabel("validation loss (lower is better)")
axes.set_ylim(1.6, 2.45)
axes.legend(fontsize=8)
save(fig, "mask_ablation.png")

# 5. the sparse penalty, matched by step
def gap(sparse, dense_rows):
    lookup = {r["step"]: r for r in dense_rows}
    xs, ys = [], []
    for r in sparse:
        if r["step"] in lookup:
            xs.append(r["step"])
            ys.append(r["vl"] - lookup[r["step"]]["vl"])
    return xs, ys

fig, axes = plt.subplots(figsize=(7.4, 4.2))
for rows, name, style in ((old_r, "4-D cell indexer", "-"), (new_r, "+ fixed-width time axis", "-")):
    xs, ys = gap(rows, b1024b)
    axes.plot(xs, ys, style, label=name)
axes.axhline(0.0, ls="--", c="k", lw=1)
axes.set_xlabel("step")
axes.set_ylabel("validation loss minus dense")
axes.legend(fontsize=8)
save(fig, "sparse_gap.png")

# 6. net recovery
fig, axes = plt.subplots(figsize=(7.4, 4.2))
for rows, name, style in ((old_r, "4-D cell indexer", "-"), (new_r, "+ fixed-width time axis", "-")):
    xs = [r["step"] for r in rows if r["dens"] and r["rec"]]
    ys = [(r["rec"] - r["dens"]) / (1.0 - r["dens"]) for r in rows if r["dens"] and r["rec"]]
    axes.plot(xs, ys, style, label=name)
axes.set_xlabel("step")
axes.set_ylabel("net recovery")
axes.legend(fontsize=8)
save(fig, "net_recovery.png")
