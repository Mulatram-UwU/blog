"""Indexer-free MLA (multi-head latent attention).

Both the query and the key/value paths are compressed through a low-rank
latent, which is what MLA actually caches:

    c_q  = W_q_down h        # query latent,     dim q_latent_dim
    c_kv = W_kv_down h       # KV latent (the KV cache), dim kv_latent_dim
    q = W_q_up c_q,  k = W_k_up c_kv,  v = W_v_up c_kv

Attention is the usual causal softmax over every visible key; there is no
routing and no sparsity.  The sca_duo package subclasses MLAAttention and adds
an indexer on exactly these tensors, so the two models differ only by the
indexer.
"""

from __future__ import annotations

import math
from typing import Any

import torch
from torch import Tensor, nn
from torch.nn import functional as F


class MLAAttention(nn.Module):
    def __init__(self, emb_dim, n_heads, q_latent_dim, kv_latent_dim, block_size, dropout):
        super().__init__()
        if emb_dim <= 0 or n_heads <= 0 or emb_dim % n_heads != 0:
            raise ValueError("emb_dim must be positive and divisible by n_heads")
        if q_latent_dim <= 0 or kv_latent_dim <= 0:
            raise ValueError("latent dimensions must be positive")
        if not 0.0 <= dropout < 1.0:
            raise ValueError("dropout must be in [0, 1)")
        self.emb_dim = emb_dim
        self.n_heads = n_heads
        self.head_dim = emb_dim // n_heads
        self.q_latent_dim = q_latent_dim
        self.kv_latent_dim = kv_latent_dim
        self.scale = 1.0 / math.sqrt(self.head_dim)
        self.dropout_p = dropout

        self.q_down = nn.Linear(emb_dim, q_latent_dim, bias=False)
        self.q_up = nn.Linear(q_latent_dim, emb_dim, bias=False)
        self.kv_down = nn.Linear(emb_dim, kv_latent_dim, bias=False)
        self.k_up = nn.Linear(kv_latent_dim, emb_dim, bias=False)
        self.v_up = nn.Linear(kv_latent_dim, emb_dim, bias=False)
        self.out_proj = nn.Linear(emb_dim, emb_dim, bias=False)
        self.resid_dropout = nn.Dropout(dropout)
        self.register_buffer(
            "causal_mask",
            torch.triu(torch.ones(block_size, block_size, dtype=torch.bool), diagonal=1),
            persistent=False,
        )

    def project(self, x: Tensor):
        batch, sequence, _ = x.shape
        if sequence > self.causal_mask.shape[0]:
            raise ValueError("sequence length exceeds block_size")
        c_q = self.q_down(x)
        c_kv = self.kv_down(x)
        q = self.q_up(c_q).view(batch, sequence, self.n_heads, self.head_dim).transpose(1, 2)
        k = self.k_up(c_kv).view(batch, sequence, self.n_heads, self.head_dim).transpose(1, 2)
        v = self.v_up(c_kv).view(batch, sequence, self.n_heads, self.head_dim).transpose(1, 2)
        return q, k, v, c_q, c_kv

    def causal(self, sequence: int, device) -> Tensor:
        return self.causal_mask[:sequence, :sequence].to(device)

    def masked_scores(self, q: Tensor, k: Tensor, candidate: Tensor | None = None) -> Tensor:
        """Masked attention logits with shape [B, H, T, T]."""

        sequence = q.shape[-2]
        scores = (q @ k.transpose(-2, -1)) * self.scale
        scores = scores.masked_fill(self.causal(sequence, q.device), float("-inf"))
        if candidate is not None:
            if candidate.shape[-2:] != (sequence, sequence):
                raise ValueError("candidate mask must have shape [B, T, T]")
            scores = scores.masked_fill(~candidate.unsqueeze(1), float("-inf"))
        return scores

    def forward(self, x: Tensor) -> Tensor:
        q, k, v, _, _ = self.project(x)
        weights = F.softmax(self.masked_scores(q, k), dim=-1)
        weights = F.dropout(weights, p=self.dropout_p, training=self.training)
        batch, _, sequence, _ = q.shape
        attended = (weights @ v).transpose(1, 2).contiguous().view(batch, sequence, self.emb_dim)
        return self.resid_dropout(self.out_proj(attended))


class MLABlock(nn.Module):
    def __init__(self, emb_dim, n_heads, q_latent_dim, kv_latent_dim, block_size, dropout):
        super().__init__()
        self.ln1 = nn.LayerNorm(emb_dim)
        self.attention = MLAAttention(emb_dim, n_heads, q_latent_dim, kv_latent_dim, block_size, dropout)
        self.ln2 = nn.LayerNorm(emb_dim)
        self.mlp = nn.Sequential(
            nn.Linear(emb_dim, 4 * emb_dim),
            nn.GELU(),
            nn.Linear(4 * emb_dim, emb_dim),
            nn.Dropout(dropout),
        )

    def forward(self, x: Tensor):
        x = x + self.attention(self.ln1(x))
        return x + self.mlp(self.ln2(x)), {}


class DecoderLM(nn.Module):
    """Token/position embedding plus an LM head over a stack of blocks."""

    def __init__(self, vocab_size, block_size, emb_dim, n_layer, dropout, blocks, name):
        super().__init__()
        if vocab_size <= 0 or block_size <= 0 or emb_dim <= 0 or n_layer <= 0:
            raise ValueError("model dimensions must be positive")
        self.vocab_size = vocab_size
        self.block_size = block_size
        self.emb_dim = emb_dim
        self.n_layer = n_layer
        self.dropout = dropout
        self.model_name = name
        self.token_embedding = nn.Embedding(vocab_size, emb_dim)
        self.position_embedding = nn.Embedding(block_size, emb_dim)
        self.blocks = blocks
        self.ln_f = nn.LayerNorm(emb_dim)
        self.lm_head = nn.Linear(emb_dim, vocab_size, bias=False)
        self.apply(self._init_weights)

    @staticmethod
    def _init_weights(module: nn.Module) -> None:
        if isinstance(module, nn.Linear):
            nn.init.normal_(module.weight, mean=0.0, std=0.02)
            if module.bias is not None:
                nn.init.zeros_(module.bias)
        elif isinstance(module, nn.Embedding):
            nn.init.normal_(module.weight, mean=0.0, std=0.02)

    def embed(self, tokens: Tensor) -> Tensor:
        if tokens.ndim != 2:
            raise ValueError("tokens must have shape [batch, sequence]")
        batch, sequence = tokens.shape
        if sequence == 0 or sequence > self.block_size:
            raise ValueError("sequence length must be in [1, block_size]")
        positions = torch.arange(sequence, device=tokens.device)
        return self.token_embedding(tokens) + self.position_embedding(positions)[None, :, :]

    def parameter_count(self) -> int:
        return sum(parameter.numel() for parameter in self.parameters())

    def config(self):
        return {
            "model": self.model_name,
            "vocab_size": self.vocab_size,
            "block_size": self.block_size,
            "emb_dim": self.emb_dim,
            "n_layer": self.n_layer,
            "dropout": self.dropout,
        }


class BaselineModel(DecoderLM):
    """Dense MLA with no indexer."""

    def __init__(self, vocab_size, block_size, emb_dim=512, n_heads=8, n_layer=6, dropout=0.1,
                 q_latent_dim=64, kv_latent_dim=64):
        blocks = nn.ModuleList(
            [MLABlock(emb_dim, n_heads, q_latent_dim, kv_latent_dim, block_size, dropout) for _ in range(n_layer)]
        )
        super().__init__(vocab_size, block_size, emb_dim, n_layer, dropout, blocks, "baseline")
        self.n_heads = n_heads
        self.q_latent_dim = q_latent_dim
        self.kv_latent_dim = kv_latent_dim

    def config(self):
        return {**super().config(), "n_heads": self.n_heads,
                "q_latent_dim": self.q_latent_dim, "kv_latent_dim": self.kv_latent_dim}

    def forward(self, tokens: Tensor, targets: Tensor | None = None):
        x = self.embed(tokens)
        for block in self.blocks:
            x, _ = block(x)
        logits = self.lm_head(self.ln_f(x))
        if targets is None:
            return logits, None, {}
        if targets.shape != tokens.shape:
            raise ValueError("targets must have the same shape as tokens")
        loss = F.cross_entropy(logits.reshape(-1, self.vocab_size), targets.reshape(-1))
        return logits, loss, {}
