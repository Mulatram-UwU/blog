"""SCA-L Duo: MLA attention restricted to the SCA-L indexer neighbourhood."""

from __future__ import annotations

import math
from typing import Any

import torch
from torch import Tensor, nn
from torch.nn import functional as F

from baseline.model import DecoderLM, MLAAttention
from .indexer import SparseChunkyIndexer

# smoothing applied to the density measurement before the control loop sees it
DENSITY_CTRL_EMA = 0.02


class SCADuoAttention(MLAAttention):
    """MLA attention whose visible keys are the indexer's chunky neighbourhood."""

    def __init__(self, emb_dim, n_heads, block_size, dropout, q_latent_dim, kv_latent_dim,
                 latent_dim=4, chunk_size=1.0, detach_indexer=False,
                 aux_mode="kl", aux_beta=1.0, ste_mask=False, code_std=0.0,
                 target_density=0.0, target_candidates=0.0, density_ctrl_rate=0.0,
                 pos_chunk=0.0, pos_only=False):
        super().__init__(emb_dim, n_heads, q_latent_dim, kv_latent_dim, block_size, dropout)
        self.indexer = SparseChunkyIndexer(q_latent_dim, kv_latent_dim, latent_dim, chunk_size,
                                           code_std, pos_chunk, pos_only)
        # With the trunk attached the distillation term also reshapes W_q_down and
        # W_kv_down, which the baseline trains on the LM loss alone, so the two
        # models stop being comparable.  Detaching confines the aux term to the
        # indexer.
        self.detach_indexer = bool(detach_indexer)
        if aux_mode not in ("kl", "recall", "rate", "none"):
            raise ValueError("aux_mode must be 'kl', 'recall', 'rate' or 'none'")
        self.aux_mode = aux_mode
        self.aux_beta = float(aux_beta)
        self.ste_mask = bool(ste_mask)
        self.target_density = float(target_density)
        self.target_candidates = float(target_candidates)
        self.density_ctrl_rate = float(density_ctrl_rate)
        # start the smoothed measurement on the setpoint so the loop does not lurch
        self.indexer.density_ema.fill_(
            self.target_candidates if self.target_candidates > 0.0 else self.target_density)

    def forward(self, x: Tensor, collect_stats: bool = False):
        q, k, v, c_q, c_kv = self.project(x)
        batch, _, sequence, _ = q.shape
        causal = self.causal(sequence, x.device)
        if self.detach_indexer:
            z_q, z_k = self.indexer.encode(c_q.detach(), c_kv.detach())
        else:
            z_q, z_k = self.indexer.encode(c_q, c_kv)
        candidate = self.indexer.candidate_mask(z_q, z_k, causal)

        # Sparsity is a constraint, and the constraint has to sit on the density
        # itself.  Pinning the code spread only changes how fast the partition
        # relaxes back to fully dense, because the spread is not what sets the
        # candidate count.  Slow integral control on the effective cell width,
        # active only while training; density_gain is a buffer, so the converged
        # value travels with the checkpoint and inference stays a fixed partition.
        # A pos_only mask is a fixed window that density_gain cannot move, so the
        # loop would integrate against a measurement it has no authority over and
        # walk the gain into its clamp.  Skip it.
        if (self.training and self.density_ctrl_rate > 0.0 and not self.indexer.pos_only
                and (self.target_candidates > 0.0 or self.target_density > 0.0)):
            with torch.no_grad():
                counts = candidate.sum(dim=-1).to(torch.float32)
                if self.target_candidates > 0.0:
                    # Absolute setpoint.  A density setpoint is length invariant by
                    # construction: the neighbourhood holds a fixed fraction of the
                    # keys, so the candidate count just grows with the context and the
                    # compute fraction never moves.  Only an absolute budget lets a
                    # longer context turn into a smaller fraction of the work.
                    measured = counts.mean()
                    setpoint = self.target_candidates
                else:
                    visible = causal.logical_not().sum(dim=-1).clamp_min(1).to(torch.float32)
                    measured = (counts / visible).mean()
                    setpoint = self.target_density
                # Feed the loop a smoothed density.  Reacting to a single mini-batch
                # makes the controller integrate its own measurement noise, which
                # shows up as a period-two limit cycle in the logged density.
                ema = self.indexer.density_ema
                ema.mul_(1.0 - DENSITY_CTRL_EMA).add_(measured, alpha=DENSITY_CTRL_EMA)
                error = float(ema) - setpoint
                self.indexer.density_gain.mul_(math.exp(-self.density_ctrl_rate * error))
                # The cell width is the gain and the codes are divided by it, so an
                # unbounded shrink (or blow-up) eventually overflows half precision.
                self.indexer.density_gain.clamp_(min=1e-3, max=1e3)

        # Teacher: the dense causal attention of the same head set, averaged over
        # heads because the indexer routes once per token, not once per head.
        dense_weights = F.softmax(self.masked_scores(q, k), dim=-1)
        teacher = dense_weights.detach().mean(dim=1)

        if self.aux_mode == "none":
            aux_loss = torch.zeros((), device=x.device, dtype=q.dtype)
        elif self.aux_mode == "rate":
            # Rate-distortion on the cell partition.  Distortion pulls the key
            # pairs that carry attention into adjacent cells, which is what stops
            # the codes from scattering into isolated cells; the rate term keeps
            # the codes compact and is the knob that sets the routing density.
            # Both terms have long-range, non-saturating gradients.
            u_q = self.indexer.cell_coordinates(z_q)
            u_k = self.indexer.cell_coordinates(z_k)
            excess = F.relu((u_q.unsqueeze(2) - u_k.unsqueeze(1)).abs() - 1.0).sum(dim=-1)
            distortion = (teacher * excess).sum(dim=-1).mean()
            rate = torch.tanh(z_k).float().std(dim=(0, 1)).mean()
            aux_loss = distortion + self.aux_beta * rate
        elif self.aux_mode == "kl":
            # Student: the same keys, scored by the indexer in latent space.
            log_index = F.log_softmax(self.indexer.logits(z_q, z_k, causal), dim=-1).clamp_min(-1e30)
            aux_loss = (teacher * (teacher.clamp_min(1e-12).log() - log_index)).sum(dim=-1).mean()
        else:
            # Budgeted recall.  The model only ever reads the neighbourhood, so the
            # projection is trained to put the attention mass inside it and pays
            # beta per unit of density.  A key is worth keeping exactly when its
            # attention exceeds beta times the mean, which makes beta the knob that
            # sets avg_candidates instead of leaving it to drift.  Straight-through
            # keeps the forward pass on the hard mask.
            soft = self.indexer.soft_neighbourhood(z_q, z_k)
            mask = candidate.to(soft.dtype) + (soft - soft.detach())
            visible = causal.logical_not().sum(dim=-1).clamp_min(1).to(soft.dtype)
            recall = (teacher * mask).sum(dim=-1)
            aux_loss = (1.0 - recall).mean() + self.aux_beta * (mask.sum(dim=-1) / visible).mean()

        # The model itself only ever reads the neighbourhood.  With ste_mask the
        # hard mask stays exact in the forward pass, while the backward pass flows
        # as if the neighbourhood had been the soft one -- in log space, so that
        # the -inf entries keep the forward exact.  That lets the LM loss itself
        # train the routing instead of an external distillation target.
        scores = self.masked_scores(q, k, candidate)
        if self.ste_mask:
            soft = self.indexer.soft_neighbourhood(z_q, z_k).float().clamp_min(1e-4)
            log_keep = soft.log()
            ste = (log_keep - log_keep.detach()).unsqueeze(1).to(scores.dtype)
            scores = scores + ste
        sparse_weights = F.softmax(scores, dim=-1)
        sparse_weights = F.dropout(sparse_weights, p=self.dropout_p, training=self.training)
        attended = (sparse_weights @ v).transpose(1, 2).contiguous().view(batch, sequence, self.emb_dim)
        output = self.resid_dropout(self.out_proj(attended))

        stats: dict[str, Tensor] = {}
        if collect_stats:
            visible = causal.logical_not().sum(dim=-1).clamp_min(1).to(torch.float32)
            counts = candidate.sum(dim=-1).to(torch.float32)
            recall = (teacher * candidate).sum(dim=-1)
            stats = {
                "avg_candidates": counts.mean(),
                "candidate_density": (counts / visible).mean(),
                "routing_recall": recall.mean(),
                "indexer_latent_norm": z_q.detach().norm(dim=-1).mean(),
                "density_ema": self.indexer.density_ema.detach(),
                "density_gain": self.indexer.density_gain.detach(),
            }
        return output, aux_loss, stats


class SCADuoBlock(nn.Module):
    def __init__(self, emb_dim, n_heads, block_size, dropout, q_latent_dim, kv_latent_dim,
                 latent_dim=4, chunk_size=1.0, detach_indexer=False,
                 aux_mode="kl", aux_beta=1.0, ste_mask=False, code_std=0.0,
                 target_density=0.0, target_candidates=0.0, density_ctrl_rate=0.0,
                 pos_chunk=0.0, pos_only=False):
        super().__init__()
        self.ln1 = nn.LayerNorm(emb_dim)
        self.attention = SCADuoAttention(emb_dim, n_heads, block_size, dropout,
                                         q_latent_dim, kv_latent_dim, latent_dim, chunk_size,
                                         detach_indexer, aux_mode, aux_beta, ste_mask, code_std,
                                         target_density, target_candidates, density_ctrl_rate,
                                         pos_chunk, pos_only)
        self.ln2 = nn.LayerNorm(emb_dim)
        self.mlp = nn.Sequential(
            nn.Linear(emb_dim, 4 * emb_dim),
            nn.GELU(),
            nn.Linear(4 * emb_dim, emb_dim),
            nn.Dropout(dropout),
        )

    def forward(self, x: Tensor, collect_stats: bool = False):
        attended, aux_loss, stats = self.attention(self.ln1(x), collect_stats=collect_stats)
        x = x + attended
        return x + self.mlp(self.ln2(x)), aux_loss, stats


class SCADuoModel(DecoderLM):
    """MLA with a SCA-L latent indexer over the compressed KV cache."""

    def __init__(self, vocab_size, block_size, emb_dim=512, n_heads=8, n_layer=6, dropout=0.1,
                 q_latent_dim=64, kv_latent_dim=64, latent_dim=4, chunk_size=1.0,
                 detach_indexer=False, aux_mode="kl", aux_beta=1.0, ste_mask=False, code_std=0.0,
                 target_density=0.0, target_candidates=0.0, density_ctrl_rate=0.0,
                 pos_chunk=0.0, pos_only=False):
        blocks = nn.ModuleList(
            [SCADuoBlock(emb_dim, n_heads, block_size, dropout, q_latent_dim, kv_latent_dim,
                         latent_dim, chunk_size, detach_indexer, aux_mode, aux_beta, ste_mask,
                         code_std, target_density, target_candidates, density_ctrl_rate,
                         pos_chunk, pos_only)
             for _ in range(n_layer)]
        )
        super().__init__(vocab_size, block_size, emb_dim, n_layer, dropout, blocks, "sca_duo")
        self.n_heads = n_heads
        self.q_latent_dim = q_latent_dim
        self.kv_latent_dim = kv_latent_dim
        self.latent_dim = latent_dim
        self.chunk_size = chunk_size
        self.detach_indexer = bool(detach_indexer)
        self.aux_mode = aux_mode
        self.aux_beta = float(aux_beta)
        self.ste_mask = bool(ste_mask)
        self.code_std = float(code_std)
        self.target_density = float(target_density)
        self.target_candidates = float(target_candidates)
        self.density_ctrl_rate = float(density_ctrl_rate)
        self.pos_chunk = float(pos_chunk)
        self.pos_only = bool(pos_only)

    def config(self):
        return {**super().config(), "n_heads": self.n_heads,
                "q_latent_dim": self.q_latent_dim, "kv_latent_dim": self.kv_latent_dim,
                "sca_latent_dim": self.latent_dim, "chunk_size": self.chunk_size,
                "detach_indexer": self.detach_indexer,
                "aux_mode": self.aux_mode, "aux_beta": self.aux_beta,
                "ste_mask": self.ste_mask, "code_std": self.code_std,
                "target_density": self.target_density,
                "target_candidates": self.target_candidates,
                "density_ctrl_rate": self.density_ctrl_rate,
                "pos_chunk": self.pos_chunk, "pos_only": self.pos_only}

    def neighbourhood_size(self) -> int:
        return self.blocks[0].attention.indexer.neighbourhood_size()

    def forward(self, tokens: Tensor, targets: Tensor | None = None):
        x = self.embed(tokens)
        collect = targets is not None
        totals: dict[str, Tensor] = {}
        for block in self.blocks:
            x, aux_loss, stats = block(x, collect_stats=collect)
            totals["aux_loss"] = totals.get("aux_loss", 0) + aux_loss
            for key, value in stats.items():
                totals[key] = totals.get(key, 0) + value
        metrics = {key: value / len(self.blocks) for key, value in totals.items()}
        logits = self.lm_head(self.ln_f(x))
        if targets is None:
            return logits, None, metrics
        if targets.shape != tokens.shape:
            raise ValueError("targets must have the same shape as tokens")
        loss = F.cross_entropy(logits.reshape(-1, self.vocab_size), targets.reshape(-1))
        return logits, loss, metrics
