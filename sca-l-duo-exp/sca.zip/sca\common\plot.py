"""Plot the raw CSV metrics of several runs, one figure per metric."""

from __future__ import annotations

import argparse
import csv
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

PLOTS = (
    ("train_loss", "training_loss", "Training loss"),
    ("train_aux_loss", "training_aux_loss", "Training aux loss (KL)"),
    ("val_loss", "validation_loss", "Validation loss"),
    ("val_accuracy", "validation_accuracy", "Validation accuracy"),
    ("val_aux_loss", "validation_aux_loss", "Validation aux loss (KL)"),
    ("val_avg_candidates", "candidate_count", "Validation: candidate keys per query"),
    ("val_candidate_density", "candidate_density", "Validation: candidate density"),
    ("val_routing_recall", "routing_recall", "Validation: routing recall"),
)


def read_series(path, column):
    steps, values = [], []
    with Path(path).open(newline="", encoding="utf-8") as handle:
        for row in csv.DictReader(handle):
            raw = row.get(column, "")
            if raw in ("", None):
                continue
            steps.append(int(row["step"]))
            values.append(float(raw))
    return steps, values


def smooth(values, window):
    if window <= 1 or len(values) < window:
        return values
    out, running = [], 0.0
    for index, value in enumerate(values):
        running += value
        if index >= window:
            running -= values[index - window]
        out.append(running / min(index + 1, window))
    return out


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", action="append", required=True,
                        help="LABEL=path/to/metrics.csv, repeat once per run")
    parser.add_argument("--output-dir", default="result/plots")
    parser.add_argument("--smooth", type=int, default=1, help="moving-average window for training curves")
    args = parser.parse_args()

    runs = []
    for spec in args.run:
        label, _, path = spec.partition("=")
        if not path:
            raise ValueError("expected LABEL=metrics.csv, got " + spec)
        runs.append((label, path))

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    written = []
    for column, filename, title in PLOTS:
        figure, axes = plt.subplots(figsize=(10, 5.5))
        plotted = False
        for label, path in runs:
            steps, values = read_series(path, column)
            if not steps:
                continue
            if column.startswith("train"):
                values = smooth(values, args.smooth)
            axes.plot(steps, values, label=label, linewidth=1.4)
            plotted = True
        if not plotted:
            plt.close(figure)
            continue
        axes.set_xlabel("step")
        axes.set_title(title)
        axes.grid(alpha=0.3)
        axes.legend()
        figure.tight_layout()
        target = output_dir / (filename + ".png")
        figure.savefig(target, dpi=150)
        plt.close(figure)
        written.append(target)
    for target in written:
        print("wrote %s" % target)


if __name__ == "__main__":
    main()
